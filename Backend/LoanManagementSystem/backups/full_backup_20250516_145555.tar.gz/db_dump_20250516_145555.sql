/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.7.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ACCCLoanManagementSystem
-- ------------------------------------------------------
-- Server version	11.7.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `api_backuplog`
--

DROP TABLE IF EXISTS `api_backuplog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_backuplog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `backup_time` datetime(6) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_backuplog`
--

LOCK TABLES `api_backuplog` WRITE;
/*!40000 ALTER TABLE `api_backuplog` DISABLE KEYS */;
INSERT INTO `api_backuplog` VALUES
(1,'2025-05-16 06:26:14.389305','full_backup_20250516_142614.tar.gz'),
(2,'2025-05-16 06:26:14.963455','full_backup_20250516_142614.tar.gz'),
(3,'2025-05-16 06:31:43.777991','full_backup_20250516_143143.tar.gz');
/*!40000 ALTER TABLE `api_backuplog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditlog_logentry`
--

DROP TABLE IF EXISTS `auditlog_logentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditlog_logentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_pk` varchar(255) NOT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_repr` longtext NOT NULL,
  `action` smallint(5) unsigned NOT NULL CHECK (`action` >= 0),
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`changes`)),
  `timestamp` datetime(6) NOT NULL,
  `actor_id` bigint(20) DEFAULT NULL,
  `content_type_id` int(11) NOT NULL,
  `remote_addr` char(39) DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_data`)),
  `serialized_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`serialized_data`)),
  `cid` varchar(255) DEFAULT NULL,
  `changes_text` longtext NOT NULL,
  `remote_port` int(10) unsigned DEFAULT NULL CHECK (`remote_port` >= 0),
  `actor_email` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auditlog_logentry_actor_id_959271d2_fk_tblUser_id` (`actor_id`),
  KEY `auditlog_logentry_content_type_id_75830218_fk_django_co` (`content_type_id`),
  KEY `auditlog_logentry_object_id_09c2eee8` (`object_id`),
  KEY `auditlog_logentry_object_pk_6e3219c0` (`object_pk`),
  KEY `auditlog_logentry_action_229afe39` (`action`),
  KEY `auditlog_logentry_timestamp_37867bb0` (`timestamp`),
  KEY `auditlog_logentry_cid_9f467263` (`cid`),
  CONSTRAINT `auditlog_logentry_actor_id_959271d2_fk_tblUser_id` FOREIGN KEY (`actor_id`) REFERENCES `tbluser` (`id`),
  CONSTRAINT `auditlog_logentry_content_type_id_75830218_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog_logentry`
--

LOCK TABLES `auditlog_logentry` WRITE;
/*!40000 ALTER TABLE `auditlog_logentry` DISABLE KEYS */;
INSERT INTO `auditlog_logentry` VALUES
(1,'1',1,'Michael . Padua',0,'{\"lastname\": [\"None\", \"Padua\"], \"firstname\": [\"None\", \"Michael\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"True\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"mpadua\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Q1gO4tel2t4LNTxpWv0cXU$xFoWzavh19tNqUf3fiRDaFQggFahCidLQ0iWJz2UAdQ=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"True\"], \"id\": [\"None\", \"1\"]}','2025-05-12 22:40:28.555778',NULL,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(2,'1',1,'Michael . Padua',1,'{\"last_login\": [\"None\", \"2025-05-12 22:40:54.079624\"]}','2025-05-12 22:40:54.084634',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(3,'2',2,'John . Doe',0,'{\"lastname\": [\"None\", \"Doe\"], \"firstname\": [\"None\", \"John\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"jdoe\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$bN4T33a33wZeLtPe5j7CH4$lFmjV+C7wvRFUOt7GjWeMpTQmKObR1nZzys8EIxnhrk=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"2\"]}','2025-05-12 22:42:53.219270',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(4,'2',2,'John O. Doe',1,'{\"middleinitial\": [\"\", \"O\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 22:43:09.512140',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(5,'3',3,'Jane . Doe',0,'{\"lastname\": [\"None\", \"Doe\"], \"firstname\": [\"None\", \"Jane\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"janedoe\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$nod4CiLTi7q4JHGDBgAdpC$QJTa2vbd89jPx1z0lwNlsfjg2iuLPBhvBO37Vn58m5E=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"3\"]}','2025-05-12 23:06:17.999645',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(6,'4',4,'JWTLog . JWTLog',0,'{\"lastname\": [\"None\", \"JWTLog\"], \"firstname\": [\"None\", \"JWTLog\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"JWTLog\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$1Vga0T7F78nivS2dAdeUpC$h9I1yYwfQFeCRYe3BHra/xt3u+JXZOaU5w1k3zkFVv4=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"4\"]}','2025-05-12 23:29:07.239456',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(7,'4',4,'JWTLog J. JWTLog',1,'{\"middleinitial\": [\"\", \"J\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 23:29:14.911322',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(8,'1',1,'Michael O. Padua',1,'{\"middleinitial\": [\"\", \"O\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 23:34:13.056297',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(9,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-12 22:40:54.079624\", \"2025-05-14 09:01:24.280804\"]}','2025-05-14 09:01:24.321828',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(10,'1',1,'John, Doe',0,'{\"member_picture\": [\"None\", \"member_pictures/Screenshot_218.png\"], \"unit_assignment\": [\"None\", \"HQ\"], \"loans\": [\"None\", \"api.Loans.None\"], \"lastname\": [\"None\", \"John\"], \"firstname\": [\"None\", \"Doe\"], \"middlename\": [\"None\", \"J\"], \"id\": [\"None\", \"1\"], \"nationality\": [\"None\", \"Filipino\"], \"sex\": [\"None\", \"M\"], \"service_no\": [\"None\", \"1234\"], \"office_business_address\": [\"None\", \"SFC\"], \"branch_of_service\": [\"None\", \"Armed Forces\"], \"unit_office_telephone_no\": [\"None\", \"123456\"], \"occupation_designation\": [\"None\", \"Officer\"], \"source_of_income\": [\"None\", \"Salary\"], \"member_signature\": [\"None\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAHr0lEQVR4Xu2cd6gkRRDG78z5zFlvDZgVFQUD6oHp8BRzQFEORcGcxYCYFVHwDzErHGcWTJj+EAWziDlnnwFzzlm/H/TgvvW9Zdndmu7proKPng3T0139TXdVdZg4wcU1YKCBiQZ5epaugQlOLCeBiQacWCZq9UydWM4BEw04sUzU6pk6sZwDJhpwYpmo1TN1YjkHTDTgxDJRq2fqxHIOmGjAiWWiVs/UieUcMNGAE8tErZ6pE8s5YKIBJ5aJWj1TJ5ZzwEQDTiwTtXqmTizngIkGnFgmavVMnVjOARMNOLFM1OqZOrGcAyYacGKZqNUzdWI5B0w04MQyUatn6sRyDphowIllolbP1InlHDDRgBPLRK2eqRMrLQ7Mq+IsIiwY0j+VLiMsLCwqzC/w3R/CVwFfKH1S+C6lqjix6muN2fSopYTJwhLCykIrpMsqnUv4Sfhc+FD4RoA0/4TrH8M15FteWC7ktYbSuYWThIvrq073JzmxBmuJ2XU7vQuEoUdZPKRLBvIsFhqd75GfhY+E90M6Ekj0ntJv+yzKHLrvVmF7YQvh4T7zGeptTqz/1AlBlhYWEhhy5mtLJ4XP9Bb8h3Qegd7kh0CKL5XSwwCuPxXofT4RfhH+HmrLjc6MHo9e7irhIMPn9Jx1CcSqehRsFRqAFPIw9DAk/SosIPweSMEQBBh6IAQpQ1T1/We6TsqeUXloR8pPXeglSaNKLsTCfmkJqwurCdgdpCsJGL4MNS8IrwuvCm8LbwrfC5Y9SZ2Ne58eNlXYWbijzgeP9aymEYshCKN31UAc0rUDgRiasFOeE54XXhReCYTibc5d9lcFrxHuFabFrmxsYjEcYbNg/DJMcY09g+fE8ISdw1CGYUzKbwi2S3vvwzVkwq4pVdAl9hwvH/qiN44mdRMLD+aYQJhdlNLjzNKl9hjH7wqPC8Rq8Hj4jHfl8n8NzNRX+wqbCE/EVFDdxMLtfkQgBkPspV0wiLF7sIdeFp4JwFh26U0Dx+pvFwq8tLf3dovNv+omVlWLWXWBbcRQh2tOF56ap2Wjcdtcd1T2GO57CzfaPqp77rGIFbPOYz0bF72KYeFFEo5gGP5L4DfsF3S1YkixCYl1zSnQ+xKO6BR6ZIbsj0M+xJmIeX0gMB1TxbuwhX4Ln8lnkFDBprr/UeFQ4dKYSi6NWDgIhCHWEwhF0GsSmsAxaBcaHgeB0MTXAvNzDMk0Op4nROB74lzM2yEQqNP7hKCVwwHRCIvQS+PBck1+lAPiMk2Dw8I184UQm2eSL9F6yvKSgJkwnlAXPOFThbO7/M/8p5yIRe+Bm72KQL0gA70NXhJe5oZCNbWCYiEFjURDPCvgWQJ6llSE8hLQhXyQBrQESP2WQEiFHmpEgOzUk+sLhBNiViIHYvGGHyCcLDCcdQoEIxTxmkBglLeeRun25sdsk16fvY7+uHEgGy/TPgJzl4RcnFi9arHL/27Tb0SbkQcEQhJvCAwjeJhM+JYiK6iihGNOE86MWekceiwMZEi0ZVBqTH3GfvZGKgDxK2JZ18UsTA7EYljD2EappcvuUsAtwloCtmM0yYFY2Ey48USbS5fTpYBDhHYnJYpOciDWiDTHzP7BUTSY1kOvVXGIwxU/CT2MZsFQZ47snGFk1vA83lH5rxTOj12PHHqsM6TEvQRiPETKSxU8QsIpWwsPxlZCDsSi6yeoyVBIz1WqHKeK85IR7Y++/iwHYkEkFHqgwDIcDPnShKVHROGfFqanUPlciMV0Du71/aHnSkG3dZZhNz3sZoFpK6anoksuxEKRbH0i8r6TcHd0zdZbACaoHwu9dr1PHudpORGLKjKVcaSwvjCShIbtC8HaK7Z9tQSW4iQhuRGL+tBbseyEtUm5e4nYVqzIIH51VhKMCoXIjVhUC68Ie4sdK6xLylkOU+VOEdi5NNZiw2h1z5FYKHNbgTXfWwlsxMhRWJxIQJQzGwiKJiW5Egslc0DGdgKrRaNuhTJqcdZc7SCwLit63KqzjjkTiwWAuN5PCdONGjdWthuEnhgPmA2qyUnOxELZ6wq44exlvCI57fdXoOqFYUXsrv1lYX9X7sRCg3sITPVsIyRxxM+AzXq17mdRIy9NslvmSiAW7Uh8i7k0zpB6aMCGjXk7a63OFTYTWIeWrJRCLBoAtxzgMbIbu2kyRQW+M5Sf4waSlpKIRUOwBf08gc0X9yTdMqMLh+cHmThR5qYmlLs0YtEmnGtwg3C0cFkDGomd1jgglwsMg42QEolFw2wucG4nqyE4WpFT+1IUdkZTRgKh7Btkd3QjpFRi0TjsGmZHC41HOIJ18ykJRwFAfrbYEwgd5EyH2utVMrFQNud1HS6wuZPlvEcIbHKNKexmPl7A0WBvIGVi+3yjpHRiVY3F+QiEJPYUiHkxed3v8dj9EoC2IOBJOTjO+yjh+n4zi32fE2t0C7DRkzlGljiz64doPWc/WArPYmpmPwGCsyoDz5VzwxorTqyxm47Thy8RmNwlsDqs0ASnOk8RWgKLEdcUOGuL02NmCBcJHFnUeHFijd+EnGdFSOJEgZWZBCfvEti0wJb+TuEcLIhCeAACcUgbCw2Z22NoY3saCxDZ7MHkOFu1OB6ADRCct9A4O6ob+/8Foh9CWwjDx7wAAAAASUVORK5CYII=\"]}','2025-05-14 09:19:29.961926',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(11,'1',1,'Loans object (1)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"143567.00\"], \"interest\": [\"None\", \"0.20\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"1\"]}','2025-05-14 09:45:35.410288',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(12,'1',1,'Loans object (1)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 09:45:43.561577',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(13,'1',1,'Johnathan, Doe',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 09:48:55.799131',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(14,'2',2,'Gonzales, Maria',1,'{\"member_picture\": [\"member_pictures/sample_1x12.jpg\", \"Screenshot (753).png\"]}','2025-05-14 09:54:51.339423',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(15,'2',2,'Loans object (2)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1323343.00\"], \"interest\": [\"None\", \"0.10\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"2\"]}','2025-05-14 09:55:23.267080',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(16,'2',2,'Loans object (2)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 09:55:38.817676',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(17,'5',5,'Wickleston . Jonathan',0,'{\"lastname\": [\"None\", \"Jonathan\"], \"firstname\": [\"None\", \"Wickleston\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"jwick\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Ng2wGxjCfWS8QAlzVtXAjl$QW/vU9mtQ8I2DwoLFiciFHLI5hcx42T9SB/jIulXZ9s=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"5\"]}','2025-05-14 10:04:01.669266',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(18,'6',6,'Tester . Another',0,'{\"lastname\": [\"None\", \"Another\"], \"firstname\": [\"None\", \"Tester\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"atester\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$s2DmZr2Rlvpx52wPHx8FLa$2SID9anKcf3PwhQGMIAEGGY+gP0eMpznlwSRtK1ct1M=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"6\"]}','2025-05-14 10:04:47.356282',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(19,'7',7,'Tester A. Middle',0,'{\"lastname\": [\"None\", \"Middle\"], \"firstname\": [\"None\", \"Tester\"], \"middleinitial\": [\"None\", \"A\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"mtester\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$MK5oIZPfVbhC09atwTQSEE$3hdWaoJiikcqwCIUPFsyQEdmd6xbSzmPZGMUnoNgkqA=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"7\"]}','2025-05-14 10:06:29.721217',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(20,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Jonathan\", \"John\"], \"middleinitial\": [\"\", \"J\"]}','2025-05-14 10:09:30.793493',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(21,'3',3,'Jane J. Doe',1,'{\"middleinitial\": [\"\", \"J\"]}','2025-05-14 10:09:43.862290',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(22,'6',6,'Tester T. Another',1,'{\"middleinitial\": [\"\", \"T\"]}','2025-05-14 10:09:47.984221',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(23,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:20:45.583636',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(24,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:20:46.521101',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(25,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:20:51.005059',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(26,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:20:57.147465',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(27,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:22:51.564964',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(28,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:28:46.029180',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(29,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:28:46.902620',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(30,'6',6,'Tester T. Another',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:28:48.734516',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(31,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 10:48:17.914903',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(32,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 10:57:35.172771',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(33,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 10:59:32.576150',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(34,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 11:00:13.407329',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(35,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 11:02:21.552632',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(36,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 11:05:55.169441',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(37,'8',8,'Myko O. Padua',0,'{\"lastname\": [\"None\", \"Padua\"], \"firstname\": [\"None\", \"Myko\"], \"middleinitial\": [\"None\", \"O\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"myko\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$MJQnfrNq8pebwZuzqDiuFU$mLQS/oN8qhgMCMznMA+ZVy88EG0afVBB8d8A2ZpjwN8=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"8\"]}','2025-05-14 11:13:52.616939',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(38,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 11:14:25.879346',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(39,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-14 09:01:24.280804\", \"2025-05-14 11:18:15.226503\"]}','2025-05-14 11:18:15.228453',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(40,'3',3,'Loans object (3)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"salary\"], \"loan_amount\": [\"None\", \"112345.00\"], \"interest\": [\"None\", \"0.10\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"3\"]}','2025-05-14 11:27:33.812109',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(41,'3',3,'Loans object (3)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:28:53.085783',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(42,'4',4,'Loans object (4)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"emergency\"], \"loan_amount\": [\"None\", \"1235354.00\"], \"interest\": [\"None\", \"0.20\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"4\"]}','2025-05-14 11:37:44.903823',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(43,'4',4,'Loans object (4)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:37:48.612758',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(44,'5',5,'Loans object (5)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"emergency\"], \"loan_amount\": [\"None\", \"1455455.00\"], \"interest\": [\"None\", \"15.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"5\"]}','2025-05-14 11:46:58.203320',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(45,'5',5,'Loans object (5)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:47:02.320726',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(46,'6',6,'Loans object (6)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"234355.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"6\"]}','2025-05-14 11:51:12.841741',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(47,'6',6,'Loans object (6)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:51:16.778921',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(48,'7',7,'Loans object (7)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"2343355.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"7\"]}','2025-05-14 11:54:27.643554',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(49,'7',7,'Loans object (7)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:54:31.196821',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(50,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 05:12:33.877730',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(51,'1',1,'Johnathan, Doe',1,'{\"member_picture\": [\"member_pictures/Screenshot_218.png\", \"sample_1x1.jpg\"]}','2025-05-15 05:19:44.634092',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(52,'2',2,'Gonzales, Maria',1,'{\"member_picture\": [\"member_pictures/Screenshot_753.png\", \"sample_1x10.jpg\"]}','2025-05-15 05:19:58.710418',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(53,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 10:58:04.255393',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(54,'1',1,'Loans object (1)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"salary\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"10.00\"], \"term\": [\"None\", \"4\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-15\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"1\"]}','2025-05-15 11:15:21.870414',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(55,'1',1,'Loans object (1)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-15 11:15:26.128968',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(56,'2',2,'Loans object (2)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"300000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-15\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"2\"]}','2025-05-15 11:49:47.527783',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(57,'2',2,'Loans object (2)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-15 11:49:56.423322',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(58,'9',9,'Personal P. Personnel',0,'{\"lastname\": [\"None\", \"Personnel\"], \"firstname\": [\"None\", \"Personal\"], \"middleinitial\": [\"None\", \"P\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Personnel\"], \"username\": [\"None\", \"persona\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$dLqC1govxu4ApDIHseTSLd$5nXxkxskJpoI33KFbn3ptgoTKd7eaOvKHPtpbxLKJsI=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"9\"]}','2025-05-15 12:15:46.137115',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(59,'1',1,'Johnathan, Does',1,'{\"firstname\": [\"Doe\", \"Does\"]}','2025-05-15 12:16:26.999927',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(60,'1',1,'Johnathan, Doe',1,'{\"firstname\": [\"Does\", \"Doe\"]}','2025-05-15 12:18:18.983132',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(61,'1',1,'Johnathan, Does',1,'{\"firstname\": [\"Doe\", \"Does\"]}','2025-05-15 12:25:33.842324',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(62,'1',1,'Johnathan, Doe',1,'{\"firstname\": [\"Does\", \"Doe\"]}','2025-05-15 12:25:53.890594',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(63,'10',10,'User T. Test',0,'{\"lastname\": [\"None\", \"Test\"], \"firstname\": [\"None\", \"User\"], \"middleinitial\": [\"None\", \"T\"], \"is_superuser\": [\"None\", \"False\"], \"address\": [\"None\", \"SFC\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"tuser\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Pz366VwF8h166prjp1IMC1$y0zd4Yr0PoqCiIN+b/Zbnr019AdiXuAFidEce7tGsIU=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"10\"]}','2025-05-15 12:39:09.976093',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(64,'10',10,'User T. Test',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 12:39:12.774077',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(65,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 13:36:36.709230',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(66,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 13:37:40.669531',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(67,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 13:38:32.983070',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(68,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-14 11:18:15.226503\", \"2025-05-15 13:39:31.669736\"]}','2025-05-15 13:39:31.671473',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(69,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 13:40:16.788748',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(70,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 13:56:49.934112',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(71,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 13:56:55.273222',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(72,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 14:00:13.976564',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(73,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 14:01:11.176897',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(74,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 14:02:07.405618',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(75,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 14:02:42.425907',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(76,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:15:56.475064',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(77,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 00:21:09.114649',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(78,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:24:10.602394',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(79,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 00:31:31.070065',4,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(80,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:32:00.596179',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(81,'4',4,'JWTLog J. JWTLog',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-16 01:18:21.947127',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(82,'4',4,'JWTLog J. JWTLog',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-16 01:19:08.017895',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(83,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 01:19:22.521014',4,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(84,'3',3,'Loans object (3)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"20000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"3\"]}','2025-05-16 05:54:25.846684',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(85,'3',3,'Loans object (3)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 05:54:30.938455',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(86,'3',3,'Admestus, Rafe',0,'{\"member_picture\": [\"None\", \"member_pictures/sample_1x13.jpg\"], \"unit_assignment\": [\"None\", \"HQ\"], \"loans\": [\"None\", \"api.Loans.None\"], \"lastname\": [\"None\", \"Admestus\"], \"firstname\": [\"None\", \"Rafe\"], \"middlename\": [\"None\", \"A\"], \"id\": [\"None\", \"3\"], \"nationality\": [\"None\", \"Filipino\"], \"sex\": [\"None\", \"M\"], \"service_no\": [\"None\", \"PG-13234\"], \"office_business_address\": [\"None\", \"SFC\"], \"branch_of_service\": [\"None\", \"Philippine Coast Guard\"], \"unit_office_telephone_no\": [\"None\", \"124333\"], \"occupation_designation\": [\"None\", \"Officer\"], \"source_of_income\": [\"None\", \"Salary\"], \"member_signature\": [\"None\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAACxNJREFUeF7t3QWM7MgRBuD/wszMzMzMzHRhBRXmREGFL6wwMyvMzMxRmDkKMzP7U9q6uXmeHe94vG+gS1rNvrd2j131u7r676ryAalSNTCCBg4YYcw6ZNVAKrAqCEbRQAXWKGqtg1ZgVQyMooEKrG61HiHJzZK8P8k3RtH8hg9agdVtYKB6QfnTR5I8L8lLk/xrw/GwtNurwOpW5SmSvDPJqZP8MskJkvwhyeuTvKx4sn8uzQobOFAF1myjnjXJFwugLtV4rNMkOX+SAwvY7pfkHRuIiaXcUgXWzmp8XZJrJnlUkvtOHHqrJA9L8qUkt0vyraVYY4MGqcDa2Zi81ueS/DHJycpne8Yxkjy+AO9JSR6S5L8bhI1Bt1KBNV9970py2SQ3T/LCjsMvmeRZSf6R5DpJvj5/yM0/ogJrvo2vkuTNBTBnnHH4kZI8rcRfN0liCt1qqcCab/7DJflRkqMmOW35fdZZN03yhGYV+cwkD9xmeqICaz6wHIHTwm3dJ8mj55wiLntlkp+W+AtNsXVSgdXP5Jco3NVLkpjq5skxGw/3uOLhrprkd/NO2LS/rzKwTlSIyYsmuVCSbyd5VVni/2ePDXGYJL9pPNAXkrievoLrQk2cc9vAtcrAwnxfrsOCn0ry8iSvboz2474WXsJxaIdzNLTCbnUm5kKsXmmbwLVbJS3BPr2H4LEEzhdLcuUkeKMLliDaIH9rvMd7kxyU5JO9R138QGC+frNveNI5AXzXNyBXr9ZsaN+gidW+v/glrM+ZqwysWVq8cBJxyy2aJf5xy0HPTXK3JH8aUfWC9nuVafnjC3zPLcs13jjJ5xc4f61OWUdgTSqYNwOoayT5VZKnJ3lokn+PYAXAAGBT2tsXHB/R+trmWu+Y5MULjrEWp607sFolnyTJw8uK7fdJbl+yEJZphJYovV5ZRCw69hmaWO0NZZV5j8YL/mXRgVb5vE0BVqtjwfUTG6NdvEl56UsN9LWPGO+3ZU/wwX1PmnHcsZop1VYR0pUnlPO1UbJpwGqNc9eSfYAeEI+hCpYhXyvk51BguZYjJnlMkls3m9cPKr/vNY2yDJ10jrGpwHKzp0vy4cZwPymbyGKwoQIIcrPOM3SgifNNrc9pNrC/nOS6C6w4l3gpyxtqk4FFSycvgbZNYsTmDweqDu0h+EY5yCxdlpw9ybMLU3+XMo0va+z9Ms6mA4tSj9Mw328sIJPW8okBmhYT2fu7Q1mBDhhqn1NxdnK6BPTy632K6dZStgFYDHOUwtSfr9kSunaSDwywlsode38yS8eQy5TsCDn1CFlx4trJtgCLYQ5fAu9LN17rCk3c9dEFrYXKQG3YaB5LjlaSB8VcvBhubq1km4DFMDaTX1HoCDHXItmecrK+2exXnr58jmlw20CmRd93wz34vqXdy7YBi+LEMgLwM5esA4TqbsVKkyeRkjy22LayT8nTPrJ4L/ukKy3bCCwGOXJhvn9eeK7dGulDST7YbB09YLcnDjj+nkn8WDzYwkJPrKxsK7AYRPaEFByby0/ZpYXwWYpaxUB7Kb7zsWUB4prvX4C2l9fQ67u2GVgUxFDoBx5gNzSEAF7Vznl7aXn5B4m38F6yOW5b9h6X/y0DRtx2YFGdHC857TIP+hKoNqSf33BZxxug+6GnWkRIdkSuyraQqbqXiY87Xn8F1v/VI42F15ISoz5wnrTl9zamFwn+543f9+92FKQNifX+WrI6gG2/Ny+pwDrYhJp98Fj37mHVoxeS1Mryqz2OH/sQ1/HUhvhV9GF/FGv/6bG/dKfxK7AO1g6wtBvB8zJE6e3PZUUpPXpVRMk/D0YkJSrmWOaeZu/7rMA6pKquVaaVc/Xow8C7Sc/Bia2S8FoKOOSmIVZvM3ALa6F7q8DaV222ekwrSMmd5LPlOEH8qsmxS47XncqF3XkBSmXQPVVg7as++VYY9TMl2am5mt5Y7y6FqYOMMOLJaBE9JYjfnzHidx1i6Aqsbk1rAgI4rVG6jtJ5xlTziL0y1oLf04LLQ6JOc0hmR+9LqMDqVpVV1lubLjPnTvLrGdrUeM2+o5KwVReBvNx6KThir9GlAmu2inWMoR/Bb5fwBErnEZOrLvg23tWGtgzVJ499wRVYszWMVReg2w/8WMdhVl9Ap7p5HaSti1RzqbEJ3m40qcDaWbVaF2Hlu4onzlJWWjr6rYtYlKgKIqqX3jLWhVdg7axZU4j0GM1tp+kHhKr0GXt16yT6SFhwYOhVko8iFVjz1aorsumwyzPJfQe+dRGpQhYb4izTvMXJKFKBNV+tgGM/UHX1dNttfeD9/6pW0wCOLAjTttI1K0Kb1bIhkKcyYUeRCqx+an1N4X8w8pOCIDVNjr1fKONV5TR6Q96+H7lYvygXc6hmG8fUfNgkKpFuVNKAMPDSmL9SNtjfl+RFe5EcOBRYblQFiaIEjS42tSWi1Z9AXu7WpMjilEUwtHPMoRtW/PjFuyiGxaMp1uBp/D9gOWZSlOMDlFWe34FKtfffSwWSlSzAf3d/NB4ZCiwFnG9LcpFyx7ICuFlvbMBcr3zSfz+HFR1iBPGMPCl3L1mkNqK9EoU+T9hkFuh+I1fKvwEEKPwAgB8sOEB4y5gGIUS2hKnpe4Vzwjv9oPzb32QptO2ZnKNETDGumkk5ZB7uZfWo6KmW2YcNBVY7spcYSdNVUuWpBjSg8jQr8AS4z4ycwsHtMwCw85yLvERJreCJi9HwWAxPR1Z+8rS8gQJgxC3Ac8riNYBAl2Q/rsH3t0CZThz09grtvSUI8jDAsHGdlZcFrGnoCngBzYbu2ZJIQ/F0UaQniyEoFvB+Vpa+u31KvJlL3vnlGz4JqBi5Fa8o8T0654kvBN2eckWrpgwMNLA4z0MBUAADlF3iIQEy3tlqyn3wJo5XWGGMKhMaGAtYXUo2VYgZNOqwMlHIIJ4wzQCiJ5fRgEF67U5unZF1UeZdhgiA8DL6gvo+YJHW61O+leDYpwdDvAKAk3EkgIphPDRimypFA3sJrJ2U3jaxVaQg2Q5gxBuqlr0jcHpLxTSlcMDqiMd7T0lhMe0AApDISwdm0wwPhsMxPcoS5YGc3/etXbyvUjFxjbEmxUMCeHpnVVkxYE0bxDtrGFN3GNUzwIFLEkBLxBO3ISxtpvJ408LTaGZmI3kZoshCtoOpc9qT6tisQtmquMqKA2vSQJbaSEgLgyuWmA2H853ipZCTOinjecRRptiWDefpUAGIzHl57DuBAv9jddc19fJU+itoFFJljYA1bSxAE6tp8XOqEoRboZkCTYuoDjyQ4NyxrVjmi914sd0ku/GazlOYwDNNiz038dcy2kduDDBXJcYaqlBTFE+F5rBtIU9KjIVA7BJvmbAHOP3iAenIpuHW41l18obiK96ya0GBfcc9tVkDQ+9lI87fFGB1GQN9IP4CFp88mOkMB9WK2M1Uhvi0EOD5JkWgrvsybzSrjMqrWSw0gLBK0cAmA2uWkU2PptGrFw7MinRSeB8LBGy6tJh5bDZOzvEVWBNa3EZgTQOOt7pA6fInK3RylYnf8sYxwbnYrUsQsBqKyNCsssUea57xrSy9KfXAkinQbv4iTTUPeVMhcttxELqoEB1gqlRg9cIAglVOu2lucsvI6hNvJXCXkem4MXuS9rrYVTqoToX9raFVo64uOLVpsc1TgVVjrP5o6jhSDCZXHKVhhenh1BXQu3Gq1KmwYmBMDdSpcEztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHY/wPq8N5bopF06gAAAABJRU5ErkJggg==\"]}','2025-05-16 05:56:20.609499',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(87,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 06:55:46.897437',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `auditlog_logentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add log entry',6,'add_logentry'),
(22,'Can change log entry',6,'change_logentry'),
(23,'Can delete log entry',6,'delete_logentry'),
(24,'Can view log entry',6,'view_logentry'),
(25,'Can add user',7,'add_user'),
(26,'Can change user',7,'change_user'),
(27,'Can delete user',7,'delete_user'),
(28,'Can view user',7,'view_user'),
(29,'Can add loans',8,'add_loans'),
(30,'Can change loans',8,'change_loans'),
(31,'Can delete loans',8,'delete_loans'),
(32,'Can view loans',8,'view_loans'),
(33,'Can add amortization',9,'add_amortization'),
(34,'Can change amortization',9,'change_amortization'),
(35,'Can delete amortization',9,'delete_amortization'),
(36,'Can view amortization',9,'view_amortization'),
(37,'Can add member',10,'add_member'),
(38,'Can change member',10,'change_member'),
(39,'Can delete member',10,'delete_member'),
(40,'Can view member',10,'view_member'),
(41,'Can add backup log',11,'add_backuplog'),
(42,'Can change backup log',11,'change_backuplog'),
(43,'Can delete backup log',11,'delete_backuplog'),
(44,'Can view backup log',11,'view_backuplog');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_tblUser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES
(1,'2025-05-12 22:42:53.228817','2','John . Doe',1,'[{\"added\": {}}]',7,1),
(2,'2025-05-12 22:43:09.516543','2','John O. Doe',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(3,'2025-05-12 23:29:07.248768','4','JWTLog . JWTLog',1,'[{\"added\": {}}]',7,1),
(4,'2025-05-12 23:29:14.915766','4','JWTLog J. JWTLog',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(5,'2025-05-12 23:34:13.061070','1','Michael O. Padua',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(6,'2025-05-15 13:36:36.713820','2','Johnathan O. Doe',2,'[{\"changed\": {\"fields\": [\"Firstname\"]}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES
(1,'admin','logentry'),
(9,'api','amortization'),
(11,'api','backuplog'),
(8,'api','loans'),
(10,'api','member'),
(7,'api','user'),
(6,'auditlog','logentry'),
(3,'auth','group'),
(2,'auth','permission'),
(4,'contenttypes','contenttype'),
(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES
(1,'contenttypes','0001_initial','2025-05-12 22:38:58.849213'),
(2,'contenttypes','0002_remove_content_type_name','2025-05-12 22:39:00.006073'),
(3,'auth','0001_initial','2025-05-12 22:39:03.345559'),
(4,'auth','0002_alter_permission_name_max_length','2025-05-12 22:39:03.914384'),
(5,'auth','0003_alter_user_email_max_length','2025-05-12 22:39:03.960370'),
(6,'auth','0004_alter_user_username_opts','2025-05-12 22:39:03.983444'),
(7,'auth','0005_alter_user_last_login_null','2025-05-12 22:39:04.021373'),
(8,'auth','0006_require_contenttypes_0002','2025-05-12 22:39:04.037021'),
(9,'auth','0007_alter_validators_add_error_messages','2025-05-12 22:39:04.073182'),
(10,'auth','0008_alter_user_username_max_length','2025-05-12 22:39:04.100447'),
(11,'auth','0009_alter_user_last_name_max_length','2025-05-12 22:39:04.117752'),
(12,'auth','0010_alter_group_name_max_length','2025-05-12 22:39:04.785661'),
(13,'auth','0011_update_proxy_permissions','2025-05-12 22:39:04.815744'),
(14,'auth','0012_alter_user_first_name_max_length','2025-05-12 22:39:04.849683'),
(15,'api','0001_initial','2025-05-12 22:39:09.413294'),
(16,'admin','0001_initial','2025-05-12 22:39:11.202804'),
(17,'admin','0002_logentry_remove_auto_add','2025-05-12 22:39:11.235602'),
(18,'admin','0003_logentry_add_action_flag_choices','2025-05-12 22:39:11.262914'),
(19,'auditlog','0001_initial','2025-05-12 22:39:13.124960'),
(20,'auditlog','0002_auto_support_long_primary_keys','2025-05-12 22:39:17.237237'),
(21,'auditlog','0003_logentry_remote_addr','2025-05-12 22:39:17.675895'),
(22,'auditlog','0004_logentry_detailed_object_repr','2025-05-12 22:39:18.276190'),
(23,'auditlog','0005_logentry_additional_data_verbose_name','2025-05-12 22:39:18.328474'),
(24,'auditlog','0006_object_pk_index','2025-05-12 22:39:19.899650'),
(25,'auditlog','0007_object_pk_type','2025-05-12 22:39:19.952982'),
(26,'auditlog','0008_action_index','2025-05-12 22:39:20.518539'),
(27,'auditlog','0009_alter_logentry_additional_data','2025-05-12 22:39:20.541727'),
(28,'auditlog','0010_alter_logentry_timestamp','2025-05-12 22:39:21.295629'),
(29,'auditlog','0011_logentry_serialized_data','2025-05-12 22:39:21.735008'),
(30,'auditlog','0012_add_logentry_action_access','2025-05-12 22:39:21.785807'),
(31,'auditlog','0013_alter_logentry_timestamp','2025-05-12 22:39:21.807031'),
(32,'auditlog','0014_logentry_cid','2025-05-12 22:39:22.675752'),
(33,'auditlog','0015_alter_logentry_changes','2025-05-12 22:39:24.554735'),
(34,'auditlog','0016_logentry_remote_port','2025-05-12 22:39:24.961486'),
(35,'auditlog','0017_add_actor_email','2025-05-12 22:39:25.379702'),
(36,'sessions','0001_initial','2025-05-12 22:39:26.102457'),
(37,'api','0002_loans_member_amortization_loans_member','2025-05-12 23:14:58.748573'),
(38,'api','0003_backuplog','2025-05-16 06:16:47.726098');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES
('7unvm665gmmbsyp0uz3nzn12ejpgh2vz','.eJxVjEEOwiAQRe_C2hCmpQVcuvcMZAZmpGpoUtqV8e7apAvd_vfef6mI21ri1niJU1ZnBer0uxGmB9cd5DvW26zTXNdlIr0r-qBNX-fMz8vh_h0UbOVbsxfTCXQkbgQ2hqzn5Nmb5G2gzvUjCbkw9CABENgC2mF01qBwEhD1_gDjKzgD:1uEbpO:6SzUrbtqbU_gRybT2uUSgfb1fFtXH6y9UVZPnbUuyPw','2025-05-26 22:40:54.135868'),
('xp3s50yoe34zykg7u3774eslckyza7mh','.eJxVjEEOwiAQRe_C2hCmpQVcuvcMZAZmpGpoUtqV8e7apAvd_vfef6mI21ri1niJU1ZnBer0uxGmB9cd5DvW26zTXNdlIr0r-qBNX-fMz8vh_h0UbOVbsxfTCXQkbgQ2hqzn5Nmb5G2gzvUjCbkw9CABENgC2mF01qBwEhD1_gDjKzgD:1uFA7r:tvaLWhtG1AOoG6wwIbgDT-M5rO6tWNDUP5o34-inMDE','2025-05-28 11:18:15.261041');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblamortization`
--

DROP TABLE IF EXISTS `tblamortization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblamortization` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `seq` int(10) unsigned NOT NULL CHECK (`seq` >= 0),
  `due_date` date NOT NULL,
  `amortization` decimal(12,2) NOT NULL,
  `principal` decimal(12,2) NOT NULL,
  `interest` decimal(12,2) NOT NULL,
  `remaining_balance` decimal(12,2) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tblAmortization_loan_id_17751303_fk_tblLoans_id` (`loan_id`),
  CONSTRAINT `tblAmortization_loan_id_17751303_fk_tblLoans_id` FOREIGN KEY (`loan_id`) REFERENCES `tblloans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblamortization`
--

LOCK TABLES `tblamortization` WRITE;
/*!40000 ALTER TABLE `tblamortization` DISABLE KEYS */;
INSERT INTO `tblamortization` VALUES
(1,1,'2025-05-15',12761.50,12344.83,416.67,37655.17,1),
(2,2,'2025-06-14',12761.50,12447.70,313.79,25207.47,1),
(3,3,'2025-07-14',12761.50,12551.44,210.06,12656.03,1),
(4,4,'2025-08-13',12761.50,12656.03,105.47,0.00,1),
(5,1,'2025-05-15',25682.24,24432.24,1250.00,275567.76,2),
(6,2,'2025-06-14',25682.24,24534.05,1148.20,251033.71,2),
(7,3,'2025-07-14',25682.24,24636.27,1045.97,226397.44,2),
(8,4,'2025-08-13',25682.24,24738.92,943.32,201658.52,2),
(9,5,'2025-09-12',25682.24,24842.00,840.24,176816.52,2),
(10,6,'2025-10-12',25682.24,24945.51,736.74,151871.01,2),
(11,7,'2025-11-11',25682.24,25049.45,632.80,126821.56,2),
(12,8,'2025-12-11',25682.24,25153.82,528.42,101667.74,2),
(13,9,'2026-01-10',25682.24,25258.63,423.62,76409.11,2),
(14,10,'2026-02-09',25682.24,25363.87,318.37,51045.24,2),
(15,11,'2026-03-11',25682.24,25469.56,212.69,25575.68,2),
(16,12,'2026-04-10',25682.24,25575.68,106.57,0.00,2),
(17,1,'2025-05-16',1712.15,1628.82,83.33,18371.18,3),
(18,2,'2025-06-15',1712.15,1635.60,76.55,16735.58,3),
(19,3,'2025-07-15',1712.15,1642.42,69.73,15093.16,3),
(20,4,'2025-08-14',1712.15,1649.26,62.89,13443.90,3),
(21,5,'2025-09-13',1712.15,1656.13,56.02,11787.77,3),
(22,6,'2025-10-13',1712.15,1663.03,49.12,10124.73,3),
(23,7,'2025-11-12',1712.15,1669.96,42.19,8454.77,3),
(24,8,'2025-12-12',1712.15,1676.92,35.23,6777.85,3),
(25,9,'2026-01-11',1712.15,1683.91,28.24,5093.94,3),
(26,10,'2026-02-10',1712.15,1690.92,21.22,3403.02,3),
(27,11,'2026-03-12',1712.15,1697.97,14.18,1705.05,3),
(28,12,'2026-04-11',1712.15,1705.05,7.10,0.00,3);
/*!40000 ALTER TABLE `tblamortization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloans`
--

DROP TABLE IF EXISTS `tblloans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `loan_type` varchar(20) NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `interest` decimal(5,2) NOT NULL,
  `term` int(11) NOT NULL,
  `grace` int(11) NOT NULL,
  `payment_start_date` date NOT NULL,
  `maturity_date` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tblLoans_member_id_2c49732e_fk_tblMember_id` (`member_id`),
  CONSTRAINT `tblLoans_member_id_2c49732e_fk_tblMember_id` FOREIGN KEY (`member_id`) REFERENCES `tblmember` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloans`
--

LOCK TABLES `tblloans` WRITE;
/*!40000 ALTER TABLE `tblloans` DISABLE KEYS */;
INSERT INTO `tblloans` VALUES
(1,'salary',50000.00,10.00,4,1,'2025-05-15','2025-06-15','released',1),
(2,'quick',300000.00,5.00,12,1,'2025-05-15','2025-06-15','released',2),
(3,'quick',20000.00,5.00,12,1,'2025-05-16','2025-06-16','released',1);
/*!40000 ALTER TABLE `tblloans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmember`
--

DROP TABLE IF EXISTS `tblmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmember` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `branch_of_service` varchar(100) NOT NULL,
  `service_no` varchar(50) NOT NULL,
  `office_business_address` longtext NOT NULL,
  `unit_assignment` varchar(255) NOT NULL,
  `unit_office_telephone_no` varchar(20) NOT NULL,
  `occupation_designation` varchar(100) NOT NULL,
  `source_of_income` varchar(100) NOT NULL,
  `member_signature` longtext DEFAULT NULL,
  `member_picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_no` (`service_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmember`
--

LOCK TABLES `tblmember` WRITE;
/*!40000 ALTER TABLE `tblmember` DISABLE KEYS */;
INSERT INTO `tblmember` VALUES
(1,'Johnathan','Doe','J','Filipino','M','Armed Forces','1234','SFC','HQ','123456','Officer','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAHr0lEQVR4Xu2cd6gkRRDG78z5zFlvDZgVFQUD6oHp8BRzQFEORcGcxYCYFVHwDzErHGcWTJj+EAWziDlnnwFzzlm/H/TgvvW9Zdndmu7proKPng3T0139TXdVdZg4wcU1YKCBiQZ5epaugQlOLCeBiQacWCZq9UydWM4BEw04sUzU6pk6sZwDJhpwYpmo1TN1YjkHTDTgxDJRq2fqxHIOmGjAiWWiVs/UieUcMNGAE8tErZ6pE8s5YKIBJ5aJWj1TJ5ZzwEQDTiwTtXqmTizngIkGnFgmavVMnVjOARMNOLFM1OqZOrGcAyYacGKZqNUzdWI5B0w04MQyUatn6sRyDphowIllolbP1InlHDDRgBPLRK2eqRMrLQ7Mq+IsIiwY0j+VLiMsLCwqzC/w3R/CVwFfKH1S+C6lqjix6muN2fSopYTJwhLCykIrpMsqnUv4Sfhc+FD4RoA0/4TrH8M15FteWC7ktYbSuYWThIvrq073JzmxBmuJ2XU7vQuEoUdZPKRLBvIsFhqd75GfhY+E90M6Ekj0ntJv+yzKHLrvVmF7YQvh4T7zGeptTqz/1AlBlhYWEhhy5mtLJ4XP9Bb8h3Qegd7kh0CKL5XSwwCuPxXofT4RfhH+HmrLjc6MHo9e7irhIMPn9Jx1CcSqehRsFRqAFPIw9DAk/SosIPweSMEQBBh6IAQpQ1T1/We6TsqeUXloR8pPXeglSaNKLsTCfmkJqwurCdgdpCsJGL4MNS8IrwuvCm8LbwrfC5Y9SZ2Ne58eNlXYWbijzgeP9aymEYshCKN31UAc0rUDgRiasFOeE54XXhReCYTibc5d9lcFrxHuFabFrmxsYjEcYbNg/DJMcY09g+fE8ISdw1CGYUzKbwi2S3vvwzVkwq4pVdAl9hwvH/qiN44mdRMLD+aYQJhdlNLjzNKl9hjH7wqPC8Rq8Hj4jHfl8n8NzNRX+wqbCE/EVFDdxMLtfkQgBkPspV0wiLF7sIdeFp4JwFh26U0Dx+pvFwq8tLf3dovNv+omVlWLWXWBbcRQh2tOF56ap2Wjcdtcd1T2GO57CzfaPqp77rGIFbPOYz0bF72KYeFFEo5gGP5L4DfsF3S1YkixCYl1zSnQ+xKO6BR6ZIbsj0M+xJmIeX0gMB1TxbuwhX4Ln8lnkFDBprr/UeFQ4dKYSi6NWDgIhCHWEwhF0GsSmsAxaBcaHgeB0MTXAvNzDMk0Op4nROB74lzM2yEQqNP7hKCVwwHRCIvQS+PBck1+lAPiMk2Dw8I184UQm2eSL9F6yvKSgJkwnlAXPOFThbO7/M/8p5yIRe+Bm72KQL0gA70NXhJe5oZCNbWCYiEFjURDPCvgWQJ6llSE8hLQhXyQBrQESP2WQEiFHmpEgOzUk+sLhBNiViIHYvGGHyCcLDCcdQoEIxTxmkBglLeeRun25sdsk16fvY7+uHEgGy/TPgJzl4RcnFi9arHL/27Tb0SbkQcEQhJvCAwjeJhM+JYiK6iihGNOE86MWekceiwMZEi0ZVBqTH3GfvZGKgDxK2JZ18UsTA7EYljD2EappcvuUsAtwloCtmM0yYFY2Ey48USbS5fTpYBDhHYnJYpOciDWiDTHzP7BUTSY1kOvVXGIwxU/CT2MZsFQZ47snGFk1vA83lH5rxTOj12PHHqsM6TEvQRiPETKSxU8QsIpWwsPxlZCDsSi6yeoyVBIz1WqHKeK85IR7Y++/iwHYkEkFHqgwDIcDPnShKVHROGfFqanUPlciMV0Du71/aHnSkG3dZZhNz3sZoFpK6anoksuxEKRbH0i8r6TcHd0zdZbACaoHwu9dr1PHudpORGLKjKVcaSwvjCShIbtC8HaK7Z9tQSW4iQhuRGL+tBbseyEtUm5e4nYVqzIIH51VhKMCoXIjVhUC68Ie4sdK6xLylkOU+VOEdi5NNZiw2h1z5FYKHNbgTXfWwlsxMhRWJxIQJQzGwiKJiW5Egslc0DGdgKrRaNuhTJqcdZc7SCwLit63KqzjjkTiwWAuN5PCdONGjdWthuEnhgPmA2qyUnOxELZ6wq44exlvCI57fdXoOqFYUXsrv1lYX9X7sRCg3sITPVsIyRxxM+AzXq17mdRIy9NslvmSiAW7Uh8i7k0zpB6aMCGjXk7a63OFTYTWIeWrJRCLBoAtxzgMbIbu2kyRQW+M5Sf4waSlpKIRUOwBf08gc0X9yTdMqMLh+cHmThR5qYmlLs0YtEmnGtwg3C0cFkDGomd1jgglwsMg42QEolFw2wucG4nqyE4WpFT+1IUdkZTRgKh7Btkd3QjpFRi0TjsGmZHC41HOIJ18ykJRwFAfrbYEwgd5EyH2utVMrFQNud1HS6wuZPlvEcIbHKNKexmPl7A0WBvIGVi+3yjpHRiVY3F+QiEJPYUiHkxed3v8dj9EoC2IOBJOTjO+yjh+n4zi32fE2t0C7DRkzlGljiz64doPWc/WArPYmpmPwGCsyoDz5VzwxorTqyxm47Thy8RmNwlsDqs0ASnOk8RWgKLEdcUOGuL02NmCBcJHFnUeHFijd+EnGdFSOJEgZWZBCfvEti0wJb+TuEcLIhCeAACcUgbCw2Z22NoY3saCxDZ7MHkOFu1OB6ADRCct9A4O6ob+/8Foh9CWwjDx7wAAAAASUVORK5CYII=','member_pictures/sample_1x1.jpg'),
(2,'Gonzales','Maria','Luna','Filipino','F','Philippine Coast Guard','PCG-234567','Port Area, Manila','Marine Environmental Protection Unit','2345678','Lieutenant','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAR/ElEQVR4Xu2dB4x1RRmGRcSuiCB2XUVFRRRjxYpIAtgVVOzEGmtiNMbE3o0tlojEBpYYjQ07iuVHUVFEFAuioItix4qiENv76Bk9bnb/vXv37rln7jyTvLnnnj1l5v3Offeb73wzs8OFLDIgAzJQCQM7VFJPqykDMiADF1KwfAhkQAaqYUDBqsZUVlQGZEDB8hmQARmohgEFqxpTWVEZkAEFy2dABmSgGgYUrGpMZUVlQAYULJ8BGZCBahhQsKoxlRWVARlQsHwGZEAGqmFAwarGVFZUBmRAwfIZkAEZqIYBBasaU1lRGZABBctnQAZkoBoGFKxqTGVFZUAGFCyfARmQgWoYULCqMZUVlQEZULB8BmRABqphQMGqxlRWVAZkQMHyGZABGaiGAQWrGlNZURmQAQXLZ0AGZKAaBhSsakxlRWVABhQsnwEZkIFqGFCwqjGVFZUBGVCwfAZkQAaqYUDBqsZUVlQGZEDB8hmQARmohgEFqxpTWVEZkAEFy2dABmSgGgYWUbAuEvYvF1wtuFJQvmOUv/ZwdrZ/Efy+GmtZURlonIFaBWupE6Xr5PMmwW6dQPEdobr0BuyKYJ3RiRcCdmbwvU7IEDuE7U/BxbttRM8iAzIwBwZqECxE40bBrYObBfcMrrDFXP0j17/wKvf4WydeiBYixncED/C9bLP/D9334sWVv5/T7d/iJnh5GVg8BsYqWHhJBwSHdEKFBzVEQYjwpJa7m9GlRHzYh3DOqiBe3Iv79Lump+c7AgfYj7hZZEAGOgbGJFjXT50ODRCpfTZpIUSGHzs/ekSBbfDT7nM1zwgBQZRKnKtUoXQvES+2ES9AnAwhZd+u3Sf7CthfwHGcs9FS2kCXFZwVIGZ0WUtXdaPX9HgZqJaBeQoWP+yDgtt2n8SfJi3n5cDTgp90P1ziTsVTWc42P/SxxZqKwPVFrYjgVVPfss0n4LjtiRyii4h9uxOx7+STtvMdLiwysHAMDC1YeFDEoeju4UWt1c1CbE7sfnyIET9Mfozs58c4NjHaigcD76yIXHnjyb49OkFbyieeG58rC/zAGVzx+c3gGwFdUT2zrbCW1xyEgSEFC5E6bjutQqA+GWwL2G5BlGZlZDwyhAtBKx7aztnGawUIGx4ZoOt9RHBBd+z7OyHjn0fpenKcRQZGx8CQgnXztP6kHgOIEuJ0fCdQ5kNt7eNRYm8I2D+DnQLeuJ4f4LVhH4St2KEE/pezDw+t/yJAW22trbz6GgwMKVhUgR8FXoAe1DgfydINxUujG3qroHhvfU+NGCFCBngRULbpdipm47TtQtRqaMFaCNIabgRe2lJAt5LPa3afpevJ3xGzfvyMGCSC9jXFrOEnZ0ZNV7BmRKSX+TcDeGWIF2K2Z0DCbxE3YmR0KxEv3mTSzUTY8MrYb5GBdRlQsNalyANmwABdTcQMAUPQSONgG/AmlBcs5JYhXsQ0EbDyZngGt/cSi8KAgrUolqy3HQT6i3jRxSxeGp4Z5ZiAVAxGAZwQOLSpXltvuuYK1qYp9AJbxABeWYmNIV6kaTCeFIHD+ypDm0iFQcTwziwLzoCCteAGXsDmEQvDC0PE8MyKkOGFERdD6IiRleC/8bEFeggUrAUypk3598gJPDBSMRA0ph76ZeeRlfGfiBneGMeS+W+piAEFqyJjWdWpGShDwJZyBXIByRXDE7tr8PruqmT3L3d/m/pGnri1DChYW8uvVx8/A2U2DoaO4YXRtcQ7K1n/vL0sEzo6XGzO9lSw5mwAbz9aBvDK8MgAwX+GL5XpgnhjSSJsSb1w7OVAZlSwBiLa2ywMA2XYEm8smRqpJMTyWbL6iZMhZgrZjM2uYM2YUC/XJAOI1e0C4mPkktG9JCG2rBfwlWyXSRcRM4P9Uz4mCtaUxHmaDKzDADEwYmHlbSUpGEsd3prPS3aChpiVecv41CvbDrEKlr87GRiWAbqS5I5dKziwEzBiZMTHCOqTN0baxXLATBh4ZnQv2d+8Z6ZgDfuwejcZWI2Bso4mXUoGjeOJMSNvGZ7EOUXMELIyi2zJKcMra0LMFCx/QDIwXgbKdD54YAjYXgEeGoH/Mt//j7NN9xLRYp45MvxLegZJs0Xo+Fv1Wf8K1ngfVmsmA2sxQJAfESPQX+YkI9BPIXZWEmVXnv+27Di8ZloVrJqtZ91l4P8ZKF7XUnYDhItu5mEBXU3KvgHeVpVFwarSbFZaBjbEwOty9BO6Mw7O57EbOntEBytYIzKGVZGBGTKAd3VQ8IKgLExMsH7voNohRgrWDJ8QLyUDc2agJLDevxOrpV59GEp032B5znXc1O0VrE3R58kyMHcGiif1iNRk/+CyK2pEusMrg1cH1a9opGDN/XmzAjKwIQYIrNPF4w3hnYP9ghJsX3mhV2THixZBqErDFKwNPSseLAODMkBCKXlXgLd8ZajPWgJF5YhPHRm8JlgetLYD3EzBGoBkbyEDG2CAfCo8p7t1ArVWTtXKSzIO8eiACQmrTxBdiy8FawNPkofKwBYx8NBcly4eKQfMVz9JIbOdoTkfDT4UMP5w4QdOK1iTPBoeIwOzZWD3XO5+AW/t7rDOpcsUNXhNbJ/ciRMCVX0QfaO0KlgbZczjZWA6Bi6W0x4fPCroD2ouVzs3G98KvtqJErM04EFVmzM1HU3bP0vB2gpWvaYM/IeBHYNDg/t0WC0edXT+9vGA9RX/KHEKls+ADAzNwC654T2Dhwe3X+XmDEI+KvhC8I+hK1fz/fSwaraedR8bAwTMn9R5VUzQ1y+fype3B8cEfx5bxWupj4JVi6Ws55gZQJyeHjx6RSXPy/f3B68KCJJbNsmAgrVJAj29aQYemdY/JFj5pu/U7HtT8Ibg700zNOPGK1gzJtTLLTwDZJ+T2PnE4I4rWvvGfKfL94mFZ2FODVSw5kS8t62OgaXU+DHBA4Nr9Gp/XLbfFRBI/2d1raqswgpWZQazuoMzwBCZlwQs09Uvr82X5wW/HbxGDd9QwWrY+DZ9TQYunL8Qn3py0E/yZA1BhsEwg2cTq9SM7RlRsMZmEeszTwYukZszXIaZDohVlXJKNngLSGqCZY4MKFhzJN9bj4YBFjZ9UED6AUNoKOcHHwmeEXx/NDVtvCIKVuMPQOPNZ32/lwUPCPrDZo7O95cH322cn9E1X8EanUms0AAM3DT3YBUZhs6UwmwI7+mE6qcD1MFbTMGAgjUFaZ5SLQOHp+ZMGXyVXgt+mG0mvXtH8OtqW9ZIxRWsRgzdcDOZGO8pwW2DK/R4+GwnVEyAd0HD/FTVdAWrKnNZ2QkZYBl3stBJ9LxF75wfZ5uYFdO5/GjCa3nYiBhQsEZkDKuyKQZ2y9n7BY/tRIogOmkKTIB3RMB8U6YlbIri+Z+sYM3fBtZgcwzcKqczi+e9gl27S/0gn3T5iEt9cXOX9+wxMaBgjcka1mUSBi6Tg24T3CVg7qlSmK1zW8CQmc9MciGPqY8BBas+m7VY40un0WXR0Ltne48eCXhQHwiYd+qsFslpqc0KVkvWrq+tLCDK4GNmSOjP4Pn5fP905039ob5mWeNpGVCwpmXO87aKAeZCBwhVPw2BfKk3B8SmGIRsaZABBatBo4+wyQjUIQGBc2JUpZyRjY8F5ErhUVkaZ0DBavwBmGPzCZqzBNa9g/7MCKzFx4R4HwxYm88iA/9lQMHyYRiSAcTpHh0u37sxg4xJQXhvcOaQFfJedTGgYE1vrxvm1L8FDKTlrdXFAyZ1Y4I3AsEMpm297BkCDggODHi71y+n5QuDjd8dnN46UbZ/MgYUrMl44ijeUj2uEyhesa9X/pIDyLI+J2AYCJnX/DDxII4MFnFtumunXbcMGBazf3C9HkkIOUNiWIrdJa/We3r8+6oMKFirPxjk/dwkIM5y1wBPAQ9qloWVVVgK6stBrd4YQ1+uGzDAmBWOD+sRRH7U8QHB8s/Nkjiv1S4DCtb/bH/lbJJBjReFdzBUYanyFwbPGeqGm7zPJXM+eVE36HjaJ58sGMqy618KTuy28TAtMjBTBloWLJYVf2r3o8ODuuiUzJ6b8xi7xo/1igFzLXHtqwb9WSzXuzyC9fz1DprD31mQYSm4U8AULZcNSEF4X4AHRXY5bf/NHOrmLRtjoCXB2im2Jd+HV+l8TtPFY4I3Xru/Lfhw8LsJnpcdcwxTnHA/fvh4JA8L+q/yuQwxrRsHJEjOszCn+X4Bcaibd0Ckfh68NCAGRbvJkbLIwKAM1CxYeC90S5hWZO+A74gCXg4BcuIrtI9saUbxs38jHg+G+E6AMDGY9oSAhQlmVVjn7sXBwb16vTrbLC01ZEEk4Y94Hd3i/Trezs4nGeWM0zspwIu0yMBcGahFsBCgZwZ4RgTESSe41IyZ+1Wux6KY2wLmTSJozL6tLnQFn9u7CSsJE9NivBwCe4eAgDae2u8D3rCxH9vRJeNN5GoFzjgHESLtAs+JFYuXArw8FmBA1AGFWBr3RqBoP16U4/TWINfd82FgzILFj+0hAevBEWMaqrDcOGLx94BAMt1APK1Tg61Y5ZcYEfcjPjRtYdEExIU8MLqf1J3CvjJHVLk2aRXsZzoWPEfiT+xzpoNp2fe8wRgYo2AhVLype3ZAd28rCt4EQrHRQoD96wHidUzws2AWw0eunuscFayX34WHBfAy1+OGt3XUFcFd7oA4OX/5Rq3u8aNhYEyCtRRWnhYwe+RGY0103cj3IXsaT4HcppVBYYSQ6UoIvv8kQCQo1wzIuUIEWJac1AaOnbSQFMr0u3hmeGTEurj+NIWsed7A8caSQDf5WSziSc7WJAH+ae7pOTJQDQNjESxe5z9rA6whRssBXRpAUHiWBcHcN2C8GyICT4jdUtDP3l7rnrxR420ib9QQUrpsBq1naSGv1SQDYxEsYkO7rGOBb+bvzIXEnEjzXpEXMWMICoJGUJwUgLW45M1iWf6cjG+6dHhPBPURNdpCjMwiAzKwDgNjESxenyMApdC9Wg7eGZCgSMyohkLCKEtMlU+SR8m34jse2vYK3hhiVuJkxJvggTgU+ywy0DwDYxGsnWOJtwRkieNBHR0QGF+0wgwPdClJK8BLo927B6QgbK8waJo4HUF+3ujhkeKZIXDE6ywy0AQDYxGsJshep5EIGEmc5E2RG4VHRndz0nJsDuSlAzYlUE8c7WsBCaAWGVgIBhSsOsyIZ7YU0G0m4ZO3meRXkS0/SeElBW9PScFguhtiZ3hrdDstMlANAwpWNaZas6IIF0NrGHrEUCWEDbCvP6vn9lp6Sv7IMu5k0Zf0DNI1XM69/udjoVqgYC2UOVdtDDEzYoPkl5HfxYBmcs54EdBf328tJoiVkTlP8J9tupvEzX65+NTZwrExoGCNzSLD14fJ98g7Y/gT8TMGi+8VMMSHua+2V7blj+SYESsjNYPteaecDM+gdxyMAQVrMKqrvRFeGKMCeKNJEi2CVlI1VnspwDhF3l4ykPrkgKA/XhmwyMCmGFCwNkWfJ4eBknNWup683aTLycwQZfhTIYrE3209ESO/zhwzH6OJGVCwJqbKA6dgAK+MrH5GApBQi4DhlbFNwRNjBAPDlphSGY+MKXOWp7iXpzTAgILVgJFH2kRmmyD3jJWeGZbFNvN+0eUkh4xhTMTF6FIS5DefbKSGHLJaCtaQbHuvSRkg6I9nRqoG84QhZKRekEvGuEzSL7YFzKqxFXOUTVpPjxuYAQVrYMK93dQMlJwyupXEyZiAEO+MLuaDp76qJ1bFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFwL8AKEiYtRbEYcwAAAAASUVORK5CYII=','member_pictures/sample_1x10.jpg'),
(3,'Admestus','Rafe','A','Filipino','M','Philippine Coast Guard','PG-13234','SFC','HQ','124333','Officer','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAACxNJREFUeF7t3QWM7MgRBuD/wszMzMzMzHRhBRXmREGFL6wwMyvMzMxRmDkKMzP7U9q6uXmeHe94vG+gS1rNvrd2j131u7r676ryAalSNTCCBg4YYcw6ZNVAKrAqCEbRQAXWKGqtg1ZgVQyMooEKrG61HiHJzZK8P8k3RtH8hg9agdVtYKB6QfnTR5I8L8lLk/xrw/GwtNurwOpW5SmSvDPJqZP8MskJkvwhyeuTvKx4sn8uzQobOFAF1myjnjXJFwugLtV4rNMkOX+SAwvY7pfkHRuIiaXcUgXWzmp8XZJrJnlUkvtOHHqrJA9L8qUkt0vyraVYY4MGqcDa2Zi81ueS/DHJycpne8Yxkjy+AO9JSR6S5L8bhI1Bt1KBNV9970py2SQ3T/LCjsMvmeRZSf6R5DpJvj5/yM0/ogJrvo2vkuTNBTBnnHH4kZI8rcRfN0liCt1qqcCab/7DJflRkqMmOW35fdZZN03yhGYV+cwkD9xmeqICaz6wHIHTwm3dJ8mj55wiLntlkp+W+AtNsXVSgdXP5Jco3NVLkpjq5skxGw/3uOLhrprkd/NO2LS/rzKwTlSIyYsmuVCSbyd5VVni/2ePDXGYJL9pPNAXkrievoLrQk2cc9vAtcrAwnxfrsOCn0ry8iSvboz2474WXsJxaIdzNLTCbnUm5kKsXmmbwLVbJS3BPr2H4LEEzhdLcuUkeKMLliDaIH9rvMd7kxyU5JO9R138QGC+frNveNI5AXzXNyBXr9ZsaN+gidW+v/glrM+ZqwysWVq8cBJxyy2aJf5xy0HPTXK3JH8aUfWC9nuVafnjC3zPLcs13jjJ5xc4f61OWUdgTSqYNwOoayT5VZKnJ3lokn+PYAXAAGBT2tsXHB/R+trmWu+Y5MULjrEWp607sFolnyTJw8uK7fdJbl+yEJZphJYovV5ZRCw69hmaWO0NZZV5j8YL/mXRgVb5vE0BVqtjwfUTG6NdvEl56UsN9LWPGO+3ZU/wwX1PmnHcsZop1VYR0pUnlPO1UbJpwGqNc9eSfYAeEI+hCpYhXyvk51BguZYjJnlMkls3m9cPKr/vNY2yDJ10jrGpwHKzp0vy4cZwPymbyGKwoQIIcrPOM3SgifNNrc9pNrC/nOS6C6w4l3gpyxtqk4FFSycvgbZNYsTmDweqDu0h+EY5yCxdlpw9ybMLU3+XMo0va+z9Ms6mA4tSj9Mw328sIJPW8okBmhYT2fu7Q1mBDhhqn1NxdnK6BPTy632K6dZStgFYDHOUwtSfr9kSunaSDwywlsode38yS8eQy5TsCDn1CFlx4trJtgCLYQ5fAu9LN17rCk3c9dEFrYXKQG3YaB5LjlaSB8VcvBhubq1km4DFMDaTX1HoCDHXItmecrK+2exXnr58jmlw20CmRd93wz34vqXdy7YBi+LEMgLwM5esA4TqbsVKkyeRkjy22LayT8nTPrJ4L/ukKy3bCCwGOXJhvn9eeK7dGulDST7YbB09YLcnDjj+nkn8WDzYwkJPrKxsK7AYRPaEFByby0/ZpYXwWYpaxUB7Kb7zsWUB4prvX4C2l9fQ67u2GVgUxFDoBx5gNzSEAF7Vznl7aXn5B4m38F6yOW5b9h6X/y0DRtx2YFGdHC857TIP+hKoNqSf33BZxxug+6GnWkRIdkSuyraQqbqXiY87Xn8F1v/VI42F15ISoz5wnrTl9zamFwn+543f9+92FKQNifX+WrI6gG2/Ny+pwDrYhJp98Fj37mHVoxeS1Mryqz2OH/sQ1/HUhvhV9GF/FGv/6bG/dKfxK7AO1g6wtBvB8zJE6e3PZUUpPXpVRMk/D0YkJSrmWOaeZu/7rMA6pKquVaaVc/Xow8C7Sc/Bia2S8FoKOOSmIVZvM3ALa6F7q8DaV222ekwrSMmd5LPlOEH8qsmxS47XncqF3XkBSmXQPVVg7as++VYY9TMl2am5mt5Y7y6FqYOMMOLJaBE9JYjfnzHidx1i6Aqsbk1rAgI4rVG6jtJ5xlTziL0y1oLf04LLQ6JOc0hmR+9LqMDqVpVV1lubLjPnTvLrGdrUeM2+o5KwVReBvNx6KThir9GlAmu2inWMoR/Bb5fwBErnEZOrLvg23tWGtgzVJ499wRVYszWMVReg2w/8WMdhVl9Ap7p5HaSti1RzqbEJ3m40qcDaWbVaF2Hlu4onzlJWWjr6rYtYlKgKIqqX3jLWhVdg7axZU4j0GM1tp+kHhKr0GXt16yT6SFhwYOhVko8iFVjz1aorsumwyzPJfQe+dRGpQhYb4izTvMXJKFKBNV+tgGM/UHX1dNttfeD9/6pW0wCOLAjTttI1K0Kb1bIhkKcyYUeRCqx+an1N4X8w8pOCIDVNjr1fKONV5TR6Q96+H7lYvygXc6hmG8fUfNgkKpFuVNKAMPDSmL9SNtjfl+RFe5EcOBRYblQFiaIEjS42tSWi1Z9AXu7WpMjilEUwtHPMoRtW/PjFuyiGxaMp1uBp/D9gOWZSlOMDlFWe34FKtfffSwWSlSzAf3d/NB4ZCiwFnG9LcpFyx7ICuFlvbMBcr3zSfz+HFR1iBPGMPCl3L1mkNqK9EoU+T9hkFuh+I1fKvwEEKPwAgB8sOEB4y5gGIUS2hKnpe4Vzwjv9oPzb32QptO2ZnKNETDGumkk5ZB7uZfWo6KmW2YcNBVY7spcYSdNVUuWpBjSg8jQr8AS4z4ycwsHtMwCw85yLvERJreCJi9HwWAxPR1Z+8rS8gQJgxC3Ac8riNYBAl2Q/rsH3t0CZThz09grtvSUI8jDAsHGdlZcFrGnoCngBzYbu2ZJIQ/F0UaQniyEoFvB+Vpa+u31KvJlL3vnlGz4JqBi5Fa8o8T0654kvBN2eckWrpgwMNLA4z0MBUAADlF3iIQEy3tlqyn3wJo5XWGGMKhMaGAtYXUo2VYgZNOqwMlHIIJ4wzQCiJ5fRgEF67U5unZF1UeZdhgiA8DL6gvo+YJHW61O+leDYpwdDvAKAk3EkgIphPDRimypFA3sJrJ2U3jaxVaQg2Q5gxBuqlr0jcHpLxTSlcMDqiMd7T0lhMe0AApDISwdm0wwPhsMxPcoS5YGc3/etXbyvUjFxjbEmxUMCeHpnVVkxYE0bxDtrGFN3GNUzwIFLEkBLxBO3ISxtpvJ408LTaGZmI3kZoshCtoOpc9qT6tisQtmquMqKA2vSQJbaSEgLgyuWmA2H853ipZCTOinjecRRptiWDefpUAGIzHl57DuBAv9jddc19fJU+itoFFJljYA1bSxAE6tp8XOqEoRboZkCTYuoDjyQ4NyxrVjmi914sd0ku/GazlOYwDNNiz038dcy2kduDDBXJcYaqlBTFE+F5rBtIU9KjIVA7BJvmbAHOP3iAenIpuHW41l18obiK96ya0GBfcc9tVkDQ+9lI87fFGB1GQN9IP4CFp88mOkMB9WK2M1Uhvi0EOD5JkWgrvsybzSrjMqrWSw0gLBK0cAmA2uWkU2PptGrFw7MinRSeB8LBGy6tJh5bDZOzvEVWBNa3EZgTQOOt7pA6fInK3RylYnf8sYxwbnYrUsQsBqKyNCsssUea57xrSy9KfXAkinQbv4iTTUPeVMhcttxELqoEB1gqlRg9cIAglVOu2lucsvI6hNvJXCXkem4MXuS9rrYVTqoToX9raFVo64uOLVpsc1TgVVjrP5o6jhSDCZXHKVhhenh1BXQu3Gq1KmwYmBMDdSpcEztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHY/wPq8N5bopF06gAAAABJRU5ErkJggg==','member_pictures/sample_1x13.jpg');
/*!40000 ALTER TABLE `tblmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middleinitial` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser`
--

LOCK TABLES `tbluser` WRITE;
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` VALUES
(1,'2025-05-15 13:39:31.669736',1,'Padua','Michael','O','SFC','Admin','mpadua','pbkdf2_sha256$870000$Q1gO4tel2t4LNTxpWv0cXU$xFoWzavh19tNqUf3fiRDaFQggFahCidLQ0iWJz2UAdQ=',1,1),
(2,NULL,0,'Doe','Johnathan','O','SFC','Admin','jdoe','pbkdf2_sha256$870000$bN4T33a33wZeLtPe5j7CH4$lFmjV+C7wvRFUOt7GjWeMpTQmKObR1nZzys8EIxnhrk=',1,0),
(3,NULL,0,'Doe','Jane','J','SFC','Admin','janedoe','pbkdf2_sha256$870000$nod4CiLTi7q4JHGDBgAdpC$QJTa2vbd89jPx1z0lwNlsfjg2iuLPBhvBO37Vn58m5E=',1,0),
(4,NULL,0,'JWTLog','JWTLog','J','SFC','Admin','JWTLog','pbkdf2_sha256$870000$1Vga0T7F78nivS2dAdeUpC$h9I1yYwfQFeCRYe3BHra/xt3u+JXZOaU5w1k3zkFVv4=',1,0),
(5,NULL,0,'Johnathan','Wickleston','J','SFC','Admin','jwick','pbkdf2_sha256$870000$Ng2wGxjCfWS8QAlzVtXAjl$QW/vU9mtQ8I2DwoLFiciFHLI5hcx42T9SB/jIulXZ9s=',1,0),
(6,NULL,0,'Another','Tester','T','SFC','Admin','atester','pbkdf2_sha256$870000$s2DmZr2Rlvpx52wPHx8FLa$2SID9anKcf3PwhQGMIAEGGY+gP0eMpznlwSRtK1ct1M=',0,0),
(7,NULL,0,'Middle','Tester','A','SFC','Admin','mtester','pbkdf2_sha256$870000$MK5oIZPfVbhC09atwTQSEE$3hdWaoJiikcqwCIUPFsyQEdmd6xbSzmPZGMUnoNgkqA=',0,0),
(8,NULL,0,'Padua','Myko','O','SFC','Admin','myko','pbkdf2_sha256$870000$MJQnfrNq8pebwZuzqDiuFU$mLQS/oN8qhgMCMznMA+ZVy88EG0afVBB8d8A2ZpjwN8=',1,0),
(9,NULL,0,'Personnel','Personal','P','SFC','Personnel','persona','pbkdf2_sha256$870000$dLqC1govxu4ApDIHseTSLd$5nXxkxskJpoI33KFbn3ptgoTKd7eaOvKHPtpbxLKJsI=',1,0),
(10,NULL,0,'Test','User','T','SFC','Admin','tuser','pbkdf2_sha256$870000$Pz366VwF8h166prjp1IMC1$y0zd4Yr0PoqCiIN+b/Zbnr019AdiXuAFidEce7tGsIU=',0,0);
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_groups`
--

DROP TABLE IF EXISTS `tbluser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tblUser_groups_user_id_group_id_f8fbd21a_uniq` (`user_id`,`group_id`),
  KEY `tblUser_groups_group_id_1ded9716_fk_auth_group_id` (`group_id`),
  CONSTRAINT `tblUser_groups_group_id_1ded9716_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `tblUser_groups_user_id_503104bb_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_groups`
--

LOCK TABLES `tbluser_groups` WRITE;
/*!40000 ALTER TABLE `tbluser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbluser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_user_permissions`
--

DROP TABLE IF EXISTS `tbluser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tblUser_user_permissions_user_id_permission_id_4e213e2b_uniq` (`user_id`,`permission_id`),
  KEY `tblUser_user_permiss_permission_id_87cb63a0_fk_auth_perm` (`permission_id`),
  CONSTRAINT `tblUser_user_permiss_permission_id_87cb63a0_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `tblUser_user_permissions_user_id_0af774d9_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_user_permissions`
--

LOCK TABLES `tbluser_user_permissions` WRITE;
/*!40000 ALTER TABLE `tbluser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbluser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-05-16 14:55:55
