/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.7.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: ACCCLoanManagementSystem
-- ------------------------------------------------------
-- Server version	11.7.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `api_backuplog`
--

DROP TABLE IF EXISTS `api_backuplog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_backuplog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `backup_time` datetime(6) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_backuplog`
--

LOCK TABLES `api_backuplog` WRITE;
/*!40000 ALTER TABLE `api_backuplog` DISABLE KEYS */;
INSERT INTO `api_backuplog` VALUES
(1,'2025-05-16 06:26:14.389305','full_backup_20250516_142614.tar.gz'),
(2,'2025-05-16 06:26:14.963455','full_backup_20250516_142614.tar.gz'),
(3,'2025-05-16 06:31:43.777991','full_backup_20250516_143143.tar.gz'),
(4,'2025-05-16 09:20:33.291691','full_backup_20250516_172032.tar.gz');
/*!40000 ALTER TABLE `api_backuplog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_restorelog`
--

DROP TABLE IF EXISTS `api_restorelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `api_restorelog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_restorelog`
--

LOCK TABLES `api_restorelog` WRITE;
/*!40000 ALTER TABLE `api_restorelog` DISABLE KEYS */;
INSERT INTO `api_restorelog` VALUES
(1,'2025-05-16 07:42:45.280552'),
(2,'2025-05-16 07:43:51.372653');
/*!40000 ALTER TABLE `api_restorelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditlog_logentry`
--

DROP TABLE IF EXISTS `auditlog_logentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auditlog_logentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_pk` varchar(255) NOT NULL,
  `object_id` bigint(20) DEFAULT NULL,
  `object_repr` longtext NOT NULL,
  `action` smallint(5) unsigned NOT NULL CHECK (`action` >= 0),
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`changes`)),
  `timestamp` datetime(6) NOT NULL,
  `actor_id` bigint(20) DEFAULT NULL,
  `content_type_id` int(11) NOT NULL,
  `remote_addr` char(39) DEFAULT NULL,
  `additional_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_data`)),
  `serialized_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`serialized_data`)),
  `cid` varchar(255) DEFAULT NULL,
  `changes_text` longtext NOT NULL,
  `remote_port` int(10) unsigned DEFAULT NULL CHECK (`remote_port` >= 0),
  `actor_email` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `auditlog_logentry_actor_id_959271d2_fk_tblUser_id` (`actor_id`),
  KEY `auditlog_logentry_content_type_id_75830218_fk_django_co` (`content_type_id`),
  KEY `auditlog_logentry_object_id_09c2eee8` (`object_id`),
  KEY `auditlog_logentry_object_pk_6e3219c0` (`object_pk`),
  KEY `auditlog_logentry_action_229afe39` (`action`),
  KEY `auditlog_logentry_timestamp_37867bb0` (`timestamp`),
  KEY `auditlog_logentry_cid_9f467263` (`cid`),
  CONSTRAINT `auditlog_logentry_actor_id_959271d2_fk_tblUser_id` FOREIGN KEY (`actor_id`) REFERENCES `tbluser` (`id`),
  CONSTRAINT `auditlog_logentry_content_type_id_75830218_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=147 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditlog_logentry`
--

LOCK TABLES `auditlog_logentry` WRITE;
/*!40000 ALTER TABLE `auditlog_logentry` DISABLE KEYS */;
INSERT INTO `auditlog_logentry` VALUES
(1,'1',1,'Michael . Padua',0,'{\"lastname\": [\"None\", \"Padua\"], \"firstname\": [\"None\", \"Michael\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"True\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"mpadua\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Q1gO4tel2t4LNTxpWv0cXU$xFoWzavh19tNqUf3fiRDaFQggFahCidLQ0iWJz2UAdQ=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"True\"], \"id\": [\"None\", \"1\"]}','2025-05-12 22:40:28.555778',NULL,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(2,'1',1,'Michael . Padua',1,'{\"last_login\": [\"None\", \"2025-05-12 22:40:54.079624\"]}','2025-05-12 22:40:54.084634',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(3,'2',2,'John . Doe',0,'{\"lastname\": [\"None\", \"Doe\"], \"firstname\": [\"None\", \"John\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"jdoe\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$bN4T33a33wZeLtPe5j7CH4$lFmjV+C7wvRFUOt7GjWeMpTQmKObR1nZzys8EIxnhrk=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"2\"]}','2025-05-12 22:42:53.219270',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(4,'2',2,'John O. Doe',1,'{\"middleinitial\": [\"\", \"O\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 22:43:09.512140',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(5,'3',3,'Jane . Doe',0,'{\"lastname\": [\"None\", \"Doe\"], \"firstname\": [\"None\", \"Jane\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"janedoe\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$nod4CiLTi7q4JHGDBgAdpC$QJTa2vbd89jPx1z0lwNlsfjg2iuLPBhvBO37Vn58m5E=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"3\"]}','2025-05-12 23:06:17.999645',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(6,'4',4,'JWTLog . JWTLog',0,'{\"lastname\": [\"None\", \"JWTLog\"], \"firstname\": [\"None\", \"JWTLog\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"JWTLog\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$1Vga0T7F78nivS2dAdeUpC$h9I1yYwfQFeCRYe3BHra/xt3u+JXZOaU5w1k3zkFVv4=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"4\"]}','2025-05-12 23:29:07.239456',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(7,'4',4,'JWTLog J. JWTLog',1,'{\"middleinitial\": [\"\", \"J\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 23:29:14.911322',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(8,'1',1,'Michael O. Padua',1,'{\"middleinitial\": [\"\", \"O\"], \"address\": [\"\", \"SFC\"]}','2025-05-12 23:34:13.056297',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(9,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-12 22:40:54.079624\", \"2025-05-14 09:01:24.280804\"]}','2025-05-14 09:01:24.321828',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(10,'1',1,'John, Doe',0,'{\"member_picture\": [\"None\", \"member_pictures/Screenshot_218.png\"], \"unit_assignment\": [\"None\", \"HQ\"], \"loans\": [\"None\", \"api.Loans.None\"], \"lastname\": [\"None\", \"John\"], \"firstname\": [\"None\", \"Doe\"], \"middlename\": [\"None\", \"J\"], \"id\": [\"None\", \"1\"], \"nationality\": [\"None\", \"Filipino\"], \"sex\": [\"None\", \"M\"], \"service_no\": [\"None\", \"1234\"], \"office_business_address\": [\"None\", \"SFC\"], \"branch_of_service\": [\"None\", \"Armed Forces\"], \"unit_office_telephone_no\": [\"None\", \"123456\"], \"occupation_designation\": [\"None\", \"Officer\"], \"source_of_income\": [\"None\", \"Salary\"], \"member_signature\": [\"None\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAHr0lEQVR4Xu2cd6gkRRDG78z5zFlvDZgVFQUD6oHp8BRzQFEORcGcxYCYFVHwDzErHGcWTJj+EAWziDlnnwFzzlm/H/TgvvW9Zdndmu7proKPng3T0139TXdVdZg4wcU1YKCBiQZ5epaugQlOLCeBiQacWCZq9UydWM4BEw04sUzU6pk6sZwDJhpwYpmo1TN1YjkHTDTgxDJRq2fqxHIOmGjAiWWiVs/UieUcMNGAE8tErZ6pE8s5YKIBJ5aJWj1TJ5ZzwEQDTiwTtXqmTizngIkGnFgmavVMnVjOARMNOLFM1OqZOrGcAyYacGKZqNUzdWI5B0w04MQyUatn6sRyDphowIllolbP1InlHDDRgBPLRK2eqRMrLQ7Mq+IsIiwY0j+VLiMsLCwqzC/w3R/CVwFfKH1S+C6lqjix6muN2fSopYTJwhLCykIrpMsqnUv4Sfhc+FD4RoA0/4TrH8M15FteWC7ktYbSuYWThIvrq073JzmxBmuJ2XU7vQuEoUdZPKRLBvIsFhqd75GfhY+E90M6Ekj0ntJv+yzKHLrvVmF7YQvh4T7zGeptTqz/1AlBlhYWEhhy5mtLJ4XP9Bb8h3Qegd7kh0CKL5XSwwCuPxXofT4RfhH+HmrLjc6MHo9e7irhIMPn9Jx1CcSqehRsFRqAFPIw9DAk/SosIPweSMEQBBh6IAQpQ1T1/We6TsqeUXloR8pPXeglSaNKLsTCfmkJqwurCdgdpCsJGL4MNS8IrwuvCm8LbwrfC5Y9SZ2Ne58eNlXYWbijzgeP9aymEYshCKN31UAc0rUDgRiasFOeE54XXhReCYTibc5d9lcFrxHuFabFrmxsYjEcYbNg/DJMcY09g+fE8ISdw1CGYUzKbwi2S3vvwzVkwq4pVdAl9hwvH/qiN44mdRMLD+aYQJhdlNLjzNKl9hjH7wqPC8Rq8Hj4jHfl8n8NzNRX+wqbCE/EVFDdxMLtfkQgBkPspV0wiLF7sIdeFp4JwFh26U0Dx+pvFwq8tLf3dovNv+omVlWLWXWBbcRQh2tOF56ap2Wjcdtcd1T2GO57CzfaPqp77rGIFbPOYz0bF72KYeFFEo5gGP5L4DfsF3S1YkixCYl1zSnQ+xKO6BR6ZIbsj0M+xJmIeX0gMB1TxbuwhX4Ln8lnkFDBprr/UeFQ4dKYSi6NWDgIhCHWEwhF0GsSmsAxaBcaHgeB0MTXAvNzDMk0Op4nROB74lzM2yEQqNP7hKCVwwHRCIvQS+PBck1+lAPiMk2Dw8I184UQm2eSL9F6yvKSgJkwnlAXPOFThbO7/M/8p5yIRe+Bm72KQL0gA70NXhJe5oZCNbWCYiEFjURDPCvgWQJ6llSE8hLQhXyQBrQESP2WQEiFHmpEgOzUk+sLhBNiViIHYvGGHyCcLDCcdQoEIxTxmkBglLeeRun25sdsk16fvY7+uHEgGy/TPgJzl4RcnFi9arHL/27Tb0SbkQcEQhJvCAwjeJhM+JYiK6iihGNOE86MWekceiwMZEi0ZVBqTH3GfvZGKgDxK2JZ18UsTA7EYljD2EappcvuUsAtwloCtmM0yYFY2Ey48USbS5fTpYBDhHYnJYpOciDWiDTHzP7BUTSY1kOvVXGIwxU/CT2MZsFQZ47snGFk1vA83lH5rxTOj12PHHqsM6TEvQRiPETKSxU8QsIpWwsPxlZCDsSi6yeoyVBIz1WqHKeK85IR7Y++/iwHYkEkFHqgwDIcDPnShKVHROGfFqanUPlciMV0Du71/aHnSkG3dZZhNz3sZoFpK6anoksuxEKRbH0i8r6TcHd0zdZbACaoHwu9dr1PHudpORGLKjKVcaSwvjCShIbtC8HaK7Z9tQSW4iQhuRGL+tBbseyEtUm5e4nYVqzIIH51VhKMCoXIjVhUC68Ie4sdK6xLylkOU+VOEdi5NNZiw2h1z5FYKHNbgTXfWwlsxMhRWJxIQJQzGwiKJiW5Egslc0DGdgKrRaNuhTJqcdZc7SCwLit63KqzjjkTiwWAuN5PCdONGjdWthuEnhgPmA2qyUnOxELZ6wq44exlvCI57fdXoOqFYUXsrv1lYX9X7sRCg3sITPVsIyRxxM+AzXq17mdRIy9NslvmSiAW7Uh8i7k0zpB6aMCGjXk7a63OFTYTWIeWrJRCLBoAtxzgMbIbu2kyRQW+M5Sf4waSlpKIRUOwBf08gc0X9yTdMqMLh+cHmThR5qYmlLs0YtEmnGtwg3C0cFkDGomd1jgglwsMg42QEolFw2wucG4nqyE4WpFT+1IUdkZTRgKh7Btkd3QjpFRi0TjsGmZHC41HOIJ18ykJRwFAfrbYEwgd5EyH2utVMrFQNud1HS6wuZPlvEcIbHKNKexmPl7A0WBvIGVi+3yjpHRiVY3F+QiEJPYUiHkxed3v8dj9EoC2IOBJOTjO+yjh+n4zi32fE2t0C7DRkzlGljiz64doPWc/WArPYmpmPwGCsyoDz5VzwxorTqyxm47Thy8RmNwlsDqs0ASnOk8RWgKLEdcUOGuL02NmCBcJHFnUeHFijd+EnGdFSOJEgZWZBCfvEti0wJb+TuEcLIhCeAACcUgbCw2Z22NoY3saCxDZ7MHkOFu1OB6ADRCct9A4O6ob+/8Foh9CWwjDx7wAAAAASUVORK5CYII=\"]}','2025-05-14 09:19:29.961926',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(11,'1',1,'Loans object (1)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"143567.00\"], \"interest\": [\"None\", \"0.20\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"1\"]}','2025-05-14 09:45:35.410288',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(12,'1',1,'Loans object (1)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 09:45:43.561577',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(13,'1',1,'Johnathan, Doe',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 09:48:55.799131',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(14,'2',2,'Gonzales, Maria',1,'{\"member_picture\": [\"member_pictures/sample_1x12.jpg\", \"Screenshot (753).png\"]}','2025-05-14 09:54:51.339423',NULL,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(15,'2',2,'Loans object (2)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1323343.00\"], \"interest\": [\"None\", \"0.10\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"2\"]}','2025-05-14 09:55:23.267080',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(16,'2',2,'Loans object (2)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 09:55:38.817676',NULL,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(17,'5',5,'Wickleston . Jonathan',0,'{\"lastname\": [\"None\", \"Jonathan\"], \"firstname\": [\"None\", \"Wickleston\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"jwick\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Ng2wGxjCfWS8QAlzVtXAjl$QW/vU9mtQ8I2DwoLFiciFHLI5hcx42T9SB/jIulXZ9s=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"5\"]}','2025-05-14 10:04:01.669266',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(18,'6',6,'Tester . Another',0,'{\"lastname\": [\"None\", \"Another\"], \"firstname\": [\"None\", \"Tester\"], \"middleinitial\": [\"None\", \"\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"atester\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$s2DmZr2Rlvpx52wPHx8FLa$2SID9anKcf3PwhQGMIAEGGY+gP0eMpznlwSRtK1ct1M=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"6\"]}','2025-05-14 10:04:47.356282',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(19,'7',7,'Tester A. Middle',0,'{\"lastname\": [\"None\", \"Middle\"], \"firstname\": [\"None\", \"Tester\"], \"middleinitial\": [\"None\", \"A\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"mtester\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$MK5oIZPfVbhC09atwTQSEE$3hdWaoJiikcqwCIUPFsyQEdmd6xbSzmPZGMUnoNgkqA=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"7\"]}','2025-05-14 10:06:29.721217',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(20,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Jonathan\", \"John\"], \"middleinitial\": [\"\", \"J\"]}','2025-05-14 10:09:30.793493',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(21,'3',3,'Jane J. Doe',1,'{\"middleinitial\": [\"\", \"J\"]}','2025-05-14 10:09:43.862290',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(22,'6',6,'Tester T. Another',1,'{\"middleinitial\": [\"\", \"T\"]}','2025-05-14 10:09:47.984221',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(23,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:20:45.583636',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(24,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:20:46.521101',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(25,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:20:51.005059',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(26,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:20:57.147465',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(27,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:22:51.564964',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(28,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-14 10:28:46.029180',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(29,'7',7,'Tester A. Middle',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:28:46.902620',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(30,'6',6,'Tester T. Another',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-14 10:28:48.734516',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(31,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 10:48:17.914903',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(32,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 10:57:35.172771',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(33,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 10:59:32.576150',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(34,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 11:00:13.407329',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(35,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 11:02:21.552632',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(36,'5',5,'Wickleston J. John',1,'{\"lastname\": [\"Johnathan\", \"John\"]}','2025-05-14 11:05:55.169441',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(37,'8',8,'Myko O. Padua',0,'{\"lastname\": [\"None\", \"Padua\"], \"firstname\": [\"None\", \"Myko\"], \"middleinitial\": [\"None\", \"O\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"myko\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$MJQnfrNq8pebwZuzqDiuFU$mLQS/oN8qhgMCMznMA+ZVy88EG0afVBB8d8A2ZpjwN8=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"8\"]}','2025-05-14 11:13:52.616939',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(38,'5',5,'Wickleston J. Johnathan',1,'{\"lastname\": [\"John\", \"Johnathan\"]}','2025-05-14 11:14:25.879346',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(39,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-14 09:01:24.280804\", \"2025-05-14 11:18:15.226503\"]}','2025-05-14 11:18:15.228453',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(40,'3',3,'Loans object (3)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"salary\"], \"loan_amount\": [\"None\", \"112345.00\"], \"interest\": [\"None\", \"0.10\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"3\"]}','2025-05-14 11:27:33.812109',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(41,'3',3,'Loans object (3)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:28:53.085783',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(42,'4',4,'Loans object (4)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"emergency\"], \"loan_amount\": [\"None\", \"1235354.00\"], \"interest\": [\"None\", \"0.20\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"4\"]}','2025-05-14 11:37:44.903823',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(43,'4',4,'Loans object (4)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:37:48.612758',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(44,'5',5,'Loans object (5)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"emergency\"], \"loan_amount\": [\"None\", \"1455455.00\"], \"interest\": [\"None\", \"15.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"5\"]}','2025-05-14 11:46:58.203320',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(45,'5',5,'Loans object (5)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:47:02.320726',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(46,'6',6,'Loans object (6)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"234355.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"6\"]}','2025-05-14 11:51:12.841741',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(47,'6',6,'Loans object (6)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:51:16.778921',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(48,'7',7,'Loans object (7)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"2343355.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-14\"], \"maturity_date\": [\"None\", \"2025-06-14\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"7\"]}','2025-05-14 11:54:27.643554',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(49,'7',7,'Loans object (7)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-14 11:54:31.196821',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(50,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 05:12:33.877730',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(51,'1',1,'Johnathan, Doe',1,'{\"member_picture\": [\"member_pictures/Screenshot_218.png\", \"sample_1x1.jpg\"]}','2025-05-15 05:19:44.634092',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(52,'2',2,'Gonzales, Maria',1,'{\"member_picture\": [\"member_pictures/Screenshot_753.png\", \"sample_1x10.jpg\"]}','2025-05-15 05:19:58.710418',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(53,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 10:58:04.255393',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(54,'1',1,'Loans object (1)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"salary\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"10.00\"], \"term\": [\"None\", \"4\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-15\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"1\"]}','2025-05-15 11:15:21.870414',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(55,'1',1,'Loans object (1)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-15 11:15:26.128968',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(56,'2',2,'Loans object (2)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"300000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-15\"], \"maturity_date\": [\"None\", \"2025-06-15\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"2\"]}','2025-05-15 11:49:47.527783',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(57,'2',2,'Loans object (2)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-15 11:49:56.423322',1,8,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(58,'9',9,'Personal P. Personnel',0,'{\"lastname\": [\"None\", \"Personnel\"], \"firstname\": [\"None\", \"Personal\"], \"middleinitial\": [\"None\", \"P\"], \"address\": [\"None\", \"SFC\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Personnel\"], \"username\": [\"None\", \"persona\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$dLqC1govxu4ApDIHseTSLd$5nXxkxskJpoI33KFbn3ptgoTKd7eaOvKHPtpbxLKJsI=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"9\"]}','2025-05-15 12:15:46.137115',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(59,'1',1,'Johnathan, Does',1,'{\"firstname\": [\"Doe\", \"Does\"]}','2025-05-15 12:16:26.999927',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(60,'1',1,'Johnathan, Doe',1,'{\"firstname\": [\"Does\", \"Doe\"]}','2025-05-15 12:18:18.983132',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(61,'1',1,'Johnathan, Does',1,'{\"firstname\": [\"Doe\", \"Does\"]}','2025-05-15 12:25:33.842324',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(62,'1',1,'Johnathan, Doe',1,'{\"firstname\": [\"Does\", \"Doe\"]}','2025-05-15 12:25:53.890594',1,10,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(63,'10',10,'User T. Test',0,'{\"lastname\": [\"None\", \"Test\"], \"firstname\": [\"None\", \"User\"], \"middleinitial\": [\"None\", \"T\"], \"is_superuser\": [\"None\", \"False\"], \"address\": [\"None\", \"SFC\"], \"usertype\": [\"None\", \"Admin\"], \"username\": [\"None\", \"tuser\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$Pz366VwF8h166prjp1IMC1$y0zd4Yr0PoqCiIN+b/Zbnr019AdiXuAFidEce7tGsIU=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"10\"]}','2025-05-15 12:39:09.976093',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(64,'10',10,'User T. Test',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 12:39:12.774077',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(65,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 13:36:36.709230',1,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(66,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 13:37:40.669531',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(67,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-15 13:38:32.983070',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(68,'1',1,'Michael O. Padua',1,'{\"last_login\": [\"2025-05-14 11:18:15.226503\", \"2025-05-15 13:39:31.669736\"]}','2025-05-15 13:39:31.671473',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(69,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-15 13:40:16.788748',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(70,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 13:56:49.934112',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(71,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 13:56:55.273222',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(72,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 14:00:13.976564',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(73,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 14:01:11.176897',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(74,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-15 14:02:07.405618',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(75,'9',9,'Personal P. Personnel',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-15 14:02:42.425907',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(76,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:15:56.475064',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(77,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 00:21:09.114649',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(78,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:24:10.602394',NULL,7,'127.0.0.1',NULL,NULL,NULL,'',NULL,NULL),
(79,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 00:31:31.070065',4,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(80,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 00:32:00.596179',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(81,'4',4,'JWTLog J. JWTLog',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-16 01:18:21.947127',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(82,'4',4,'JWTLog J. JWTLog',1,'{\"is_active\": [\"False\", \"True\"]}','2025-05-16 01:19:08.017895',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(83,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 01:19:22.521014',4,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(84,'3',3,'Loans object (3)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"20000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"3\"]}','2025-05-16 05:54:25.846684',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(85,'3',3,'Loans object (3)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 05:54:30.938455',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(86,'3',3,'Admestus, Rafe',0,'{\"member_picture\": [\"None\", \"member_pictures/sample_1x13.jpg\"], \"unit_assignment\": [\"None\", \"HQ\"], \"loans\": [\"None\", \"api.Loans.None\"], \"lastname\": [\"None\", \"Admestus\"], \"firstname\": [\"None\", \"Rafe\"], \"middlename\": [\"None\", \"A\"], \"id\": [\"None\", \"3\"], \"nationality\": [\"None\", \"Filipino\"], \"sex\": [\"None\", \"M\"], \"service_no\": [\"None\", \"PG-13234\"], \"office_business_address\": [\"None\", \"SFC\"], \"branch_of_service\": [\"None\", \"Philippine Coast Guard\"], \"unit_office_telephone_no\": [\"None\", \"124333\"], \"occupation_designation\": [\"None\", \"Officer\"], \"source_of_income\": [\"None\", \"Salary\"], \"member_signature\": [\"None\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAACxNJREFUeF7t3QWM7MgRBuD/wszMzMzMzHRhBRXmREGFL6wwMyvMzMxRmDkKMzP7U9q6uXmeHe94vG+gS1rNvrd2j131u7r676ryAalSNTCCBg4YYcw6ZNVAKrAqCEbRQAXWKGqtg1ZgVQyMooEKrG61HiHJzZK8P8k3RtH8hg9agdVtYKB6QfnTR5I8L8lLk/xrw/GwtNurwOpW5SmSvDPJqZP8MskJkvwhyeuTvKx4sn8uzQobOFAF1myjnjXJFwugLtV4rNMkOX+SAwvY7pfkHRuIiaXcUgXWzmp8XZJrJnlUkvtOHHqrJA9L8qUkt0vyraVYY4MGqcDa2Zi81ueS/DHJycpne8Yxkjy+AO9JSR6S5L8bhI1Bt1KBNV9970py2SQ3T/LCjsMvmeRZSf6R5DpJvj5/yM0/ogJrvo2vkuTNBTBnnHH4kZI8rcRfN0liCt1qqcCab/7DJflRkqMmOW35fdZZN03yhGYV+cwkD9xmeqICaz6wHIHTwm3dJ8mj55wiLntlkp+W+AtNsXVSgdXP5Jco3NVLkpjq5skxGw/3uOLhrprkd/NO2LS/rzKwTlSIyYsmuVCSbyd5VVni/2ePDXGYJL9pPNAXkrievoLrQk2cc9vAtcrAwnxfrsOCn0ry8iSvboz2474WXsJxaIdzNLTCbnUm5kKsXmmbwLVbJS3BPr2H4LEEzhdLcuUkeKMLliDaIH9rvMd7kxyU5JO9R138QGC+frNveNI5AXzXNyBXr9ZsaN+gidW+v/glrM+ZqwysWVq8cBJxyy2aJf5xy0HPTXK3JH8aUfWC9nuVafnjC3zPLcs13jjJ5xc4f61OWUdgTSqYNwOoayT5VZKnJ3lokn+PYAXAAGBT2tsXHB/R+trmWu+Y5MULjrEWp607sFolnyTJw8uK7fdJbl+yEJZphJYovV5ZRCw69hmaWO0NZZV5j8YL/mXRgVb5vE0BVqtjwfUTG6NdvEl56UsN9LWPGO+3ZU/wwX1PmnHcsZop1VYR0pUnlPO1UbJpwGqNc9eSfYAeEI+hCpYhXyvk51BguZYjJnlMkls3m9cPKr/vNY2yDJ10jrGpwHKzp0vy4cZwPymbyGKwoQIIcrPOM3SgifNNrc9pNrC/nOS6C6w4l3gpyxtqk4FFSycvgbZNYsTmDweqDu0h+EY5yCxdlpw9ybMLU3+XMo0va+z9Ms6mA4tSj9Mw328sIJPW8okBmhYT2fu7Q1mBDhhqn1NxdnK6BPTy632K6dZStgFYDHOUwtSfr9kSunaSDwywlsode38yS8eQy5TsCDn1CFlx4trJtgCLYQ5fAu9LN17rCk3c9dEFrYXKQG3YaB5LjlaSB8VcvBhubq1km4DFMDaTX1HoCDHXItmecrK+2exXnr58jmlw20CmRd93wz34vqXdy7YBi+LEMgLwM5esA4TqbsVKkyeRkjy22LayT8nTPrJ4L/ukKy3bCCwGOXJhvn9eeK7dGulDST7YbB09YLcnDjj+nkn8WDzYwkJPrKxsK7AYRPaEFByby0/ZpYXwWYpaxUB7Kb7zsWUB4prvX4C2l9fQ67u2GVgUxFDoBx5gNzSEAF7Vznl7aXn5B4m38F6yOW5b9h6X/y0DRtx2YFGdHC857TIP+hKoNqSf33BZxxug+6GnWkRIdkSuyraQqbqXiY87Xn8F1v/VI42F15ISoz5wnrTl9zamFwn+543f9+92FKQNifX+WrI6gG2/Ny+pwDrYhJp98Fj37mHVoxeS1Mryqz2OH/sQ1/HUhvhV9GF/FGv/6bG/dKfxK7AO1g6wtBvB8zJE6e3PZUUpPXpVRMk/D0YkJSrmWOaeZu/7rMA6pKquVaaVc/Xow8C7Sc/Bia2S8FoKOOSmIVZvM3ALa6F7q8DaV222ekwrSMmd5LPlOEH8qsmxS47XncqF3XkBSmXQPVVg7as++VYY9TMl2am5mt5Y7y6FqYOMMOLJaBE9JYjfnzHidx1i6Aqsbk1rAgI4rVG6jtJ5xlTziL0y1oLf04LLQ6JOc0hmR+9LqMDqVpVV1lubLjPnTvLrGdrUeM2+o5KwVReBvNx6KThir9GlAmu2inWMoR/Bb5fwBErnEZOrLvg23tWGtgzVJ499wRVYszWMVReg2w/8WMdhVl9Ap7p5HaSti1RzqbEJ3m40qcDaWbVaF2Hlu4onzlJWWjr6rYtYlKgKIqqX3jLWhVdg7axZU4j0GM1tp+kHhKr0GXt16yT6SFhwYOhVko8iFVjz1aorsumwyzPJfQe+dRGpQhYb4izTvMXJKFKBNV+tgGM/UHX1dNttfeD9/6pW0wCOLAjTttI1K0Kb1bIhkKcyYUeRCqx+an1N4X8w8pOCIDVNjr1fKONV5TR6Q96+H7lYvygXc6hmG8fUfNgkKpFuVNKAMPDSmL9SNtjfl+RFe5EcOBRYblQFiaIEjS42tSWi1Z9AXu7WpMjilEUwtHPMoRtW/PjFuyiGxaMp1uBp/D9gOWZSlOMDlFWe34FKtfffSwWSlSzAf3d/NB4ZCiwFnG9LcpFyx7ICuFlvbMBcr3zSfz+HFR1iBPGMPCl3L1mkNqK9EoU+T9hkFuh+I1fKvwEEKPwAgB8sOEB4y5gGIUS2hKnpe4Vzwjv9oPzb32QptO2ZnKNETDGumkk5ZB7uZfWo6KmW2YcNBVY7spcYSdNVUuWpBjSg8jQr8AS4z4ycwsHtMwCw85yLvERJreCJi9HwWAxPR1Z+8rS8gQJgxC3Ac8riNYBAl2Q/rsH3t0CZThz09grtvSUI8jDAsHGdlZcFrGnoCngBzYbu2ZJIQ/F0UaQniyEoFvB+Vpa+u31KvJlL3vnlGz4JqBi5Fa8o8T0654kvBN2eckWrpgwMNLA4z0MBUAADlF3iIQEy3tlqyn3wJo5XWGGMKhMaGAtYXUo2VYgZNOqwMlHIIJ4wzQCiJ5fRgEF67U5unZF1UeZdhgiA8DL6gvo+YJHW61O+leDYpwdDvAKAk3EkgIphPDRimypFA3sJrJ2U3jaxVaQg2Q5gxBuqlr0jcHpLxTSlcMDqiMd7T0lhMe0AApDISwdm0wwPhsMxPcoS5YGc3/etXbyvUjFxjbEmxUMCeHpnVVkxYE0bxDtrGFN3GNUzwIFLEkBLxBO3ISxtpvJ408LTaGZmI3kZoshCtoOpc9qT6tisQtmquMqKA2vSQJbaSEgLgyuWmA2H853ipZCTOinjecRRptiWDefpUAGIzHl57DuBAv9jddc19fJU+itoFFJljYA1bSxAE6tp8XOqEoRboZkCTYuoDjyQ4NyxrVjmi914sd0ku/GazlOYwDNNiz038dcy2kduDDBXJcYaqlBTFE+F5rBtIU9KjIVA7BJvmbAHOP3iAenIpuHW41l18obiK96ya0GBfcc9tVkDQ+9lI87fFGB1GQN9IP4CFp88mOkMB9WK2M1Uhvi0EOD5JkWgrvsybzSrjMqrWSw0gLBK0cAmA2uWkU2PptGrFw7MinRSeB8LBGy6tJh5bDZOzvEVWBNa3EZgTQOOt7pA6fInK3RylYnf8sYxwbnYrUsQsBqKyNCsssUea57xrSy9KfXAkinQbv4iTTUPeVMhcttxELqoEB1gqlRg9cIAglVOu2lucsvI6hNvJXCXkem4MXuS9rrYVTqoToX9raFVo64uOLVpsc1TgVVjrP5o6jhSDCZXHKVhhenh1BXQu3Gq1KmwYmBMDdSpcEztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHY/wPq8N5bopF06gAAAABJRU5ErkJggg==\"]}','2025-05-16 05:56:20.609499',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(87,'2',2,'Johnathan O. Doe',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 06:55:46.897437',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(88,'1',1,'Johnathan, Doe',1,'{\"member_picture\": [\"member_pictures/sample_1x1.jpg\", \"sample_1x1.jpg\"]}','2025-05-16 07:48:29.215183',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(89,'2',2,'Gonzales, Maria',1,'{\"member_picture\": [\"member_pictures/sample_1x10.jpg\", \"sample_1x10.jpg\"]}','2025-05-16 07:48:39.715910',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(90,'3',3,'Admestus, Rafe',1,'{\"member_picture\": [\"member_pictures/sample_1x13.jpg\", \"sample_1x12.jpg\"]}','2025-05-16 07:48:49.375750',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(91,'4',4,'Loans object (4)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"300000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"4\"]}','2025-05-16 08:32:43.766456',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(92,'4',4,'Loans object (4)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:32:54.588007',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(93,'5',5,'Loans object (5)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"5\"]}','2025-05-16 08:41:34.126687',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(94,'5',5,'Loans object (5)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:41:40.009350',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(95,'6',6,'Loans object (6)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"6\"]}','2025-05-16 08:44:40.782703',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(96,'6',6,'Loans object (6)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:44:46.822518',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(97,'7',7,'Loans object (7)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"7\"]}','2025-05-16 08:46:22.025101',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(98,'7',7,'Loans object (7)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:46:29.800820',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(99,'8',8,'Loans object (8)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"8\"]}','2025-05-16 08:47:30.739945',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(100,'8',8,'Loans object (8)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:47:37.244514',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(101,'9',9,'Loans object (9)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"9\"]}','2025-05-16 08:56:13.773964',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(102,'9',9,'Loans object (9)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 08:56:20.155868',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(103,'10',10,'Loans object (10)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"10000000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"10\"]}','2025-05-16 09:00:07.365154',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(104,'10',10,'Loans object (10)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 09:01:13.424906',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(105,'11',11,'Loans object (11)',0,'{\"member\": [\"None\", \"2\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"800000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"11\"]}','2025-05-16 09:08:58.642928',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(106,'11',11,'Loans object (11)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 09:09:03.508427',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(107,'12',12,'Loans object (12)',0,'{\"member\": [\"None\", \"3\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1500000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"12\"]}','2025-05-16 09:21:53.930673',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(108,'12',12,'Loans object (12)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 09:22:03.631481',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(109,'13',13,'Loans object (13)',0,'{\"member\": [\"None\", \"3\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1500000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-06-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"13\"]}','2025-05-16 09:25:17.051059',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(110,'13',13,'Loans object (13)',1,'{\"status\": [\"pending\", \"reject\"]}','2025-05-16 09:25:31.100623',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(111,'13',13,'Loans object (13)',1,'{\"status\": [\"pending\", \"reject\"]}','2025-05-16 09:25:31.202741',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(112,'14',14,'Loans object (14)',0,'{\"member\": [\"None\", \"3\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1500000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"14\"]}','2025-05-16 09:25:56.364913',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(113,'14',14,'Loans object (14)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 09:26:11.232506',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(114,'15',15,'Loans object (15)',0,'{\"member\": [\"None\", \"3\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"329736.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"36\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2028-04-01\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"15\"]}','2025-05-16 09:28:53.946239',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(115,'15',15,'Loans object (15)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 09:28:59.258607',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(116,'1',1,'Loans object (1)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"500000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-07-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"1\"]}','2025-05-16 10:51:46.050814',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(117,'1',1,'Loans object (1)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 10:51:51.253019',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(118,'2',2,'Loans object (2)',0,'{\"member\": [\"None\", \"3\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"50000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"2\"]}','2025-05-16 10:52:35.318855',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(119,'2',2,'Loans object (2)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 10:52:38.418190',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(120,'3',3,'Loans object (3)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"300000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"36\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2028-04-01\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"3\"]}','2025-05-16 10:55:33.786187',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(121,'3',3,'Loans object (3)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 10:55:36.547674',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(122,'1',1,'Doe, Johnathan',1,'{\"lastname\": [\"Johnathan\", \"Doe\"], \"firstname\": [\"Doe\", \"Johnathan\"]}','2025-05-16 11:05:08.514564',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(123,'1',1,'Doe, John',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 11:19:32.924444',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(124,'4',4,'Loans object (4)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"4000000.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"4\"]}','2025-05-16 11:52:52.951476',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(125,'4',4,'Loans object (4)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 11:52:55.086714',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(126,'5',5,'Loans object (5)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"23234343.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"5\"]}','2025-05-16 11:55:19.522372',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(127,'5',5,'Loans object (5)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 11:55:24.959259',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(128,'6',6,'Loans object (6)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1232243.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-05-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"6\"]}','2025-05-16 11:56:17.307964',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(129,'6',6,'Loans object (6)',1,'{\"status\": [\"pending\", \"reject\"]}','2025-05-16 11:56:20.898236',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(130,'2',2,'John O. Doe',1,'{\"firstname\": [\"Johnathan\", \"John\"]}','2025-05-16 11:59:34.040065',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(131,'11',11,'Apprentice A. Assistant',0,'{\"lastname\": [\"None\", \"Assistant\"], \"firstname\": [\"None\", \"Apprentice\"], \"middleinitial\": [\"None\", \"A\"], \"address\": [\"None\", \"SF\"], \"is_superuser\": [\"None\", \"False\"], \"usertype\": [\"None\", \"Personnel\"], \"username\": [\"None\", \"apprentice\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$QpJiXGjxvAXFtsJCaMNIXD$epA+tJp/B9zw/D6/8zuqbsFX8cm5KHZSJg6DfxhC23I=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"11\"]}','2025-05-16 12:00:46.918905',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(132,'1',1,'Doe, Johnathan',1,'{\"firstname\": [\"John\", \"Johnathan\"]}','2025-05-16 12:02:46.717455',11,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(133,'7',7,'Loans object (7)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"emergency\"], \"loan_amount\": [\"None\", \"4454687.00\"], \"interest\": [\"None\", \"15.00\"], \"term\": [\"None\", \"1\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-05-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"7\"]}','2025-05-16 12:10:42.622415',9,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(134,'4',4,'Test, Mikael',0,'{\"member_picture\": [\"None\", \"member_pictures/sample_1x14.jpg\"], \"loans\": [\"None\", \"api.Loans.None\"], \"unit_assignment\": [\"None\", \"HQ\"], \"lastname\": [\"None\", \"Test\"], \"firstname\": [\"None\", \"Mikael\"], \"id\": [\"None\", \"4\"], \"middlename\": [\"None\", \"M\"], \"nationality\": [\"None\", \"Filipino\"], \"sex\": [\"None\", \"M\"], \"service_no\": [\"None\", \"324335353\"], \"office_business_address\": [\"None\", \"SFC\"], \"branch_of_service\": [\"None\", \"Armed Forces\"], \"unit_office_telephone_no\": [\"None\", \"124333\"], \"occupation_designation\": [\"None\", \"Officer\"], \"source_of_income\": [\"None\", \"Salary\"], \"member_signature\": [\"None\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAAEY5JREFUeF7t3QV4JMcRBeDnMDMzO8zMzJw4zMwOOMxxmDlxmJmZGR12mJmZGea/dPvmRkuSdqXV7NT37SeddrD7TdWrV9Vze2WwYQQWMAJ7LeCYwyGHEcgArAEECxmBAVgLGdbhoAOwBgwsZAQGYC1kWIeDDsAaMLCQERiAtZBhHQ46AGvAwEJGYADWQoZ1OOhOBdZ9klwoyT+SHCbJv5J8LMkLkvx0mNbtH4GdCqxLJLl6krMlOV9nGJ+e5AFJfr39w7u6V7BTgdWesfMnuWaSayc5Qfnid0k+kOQtST6e5CurO8Xbc+d9AFZ75C6c5GpJzpjkkq0vvpzkzUleneSz2zPUq3XWvgGrPXsna7zVZZIA27mSnLp8+aUk7yp87IurNd1bd7d9BlZ3FI+c5FJJLlv42TFLmHxxklcm+c3WDXv/z7RKwGrPpvu+fJLrJLlKkkMkeV2SZxSw9X/mF3yHqwqs9rAeJclVk9ysSBhfTfKqJE8dvNjG0TcAa8+xO2GSGxVPdqoSIl+U5EONhPGfjQ/z6u05AGv8nB+vyBiAdrokbypAI2EMIJvyrAzAms2ZXLyADC87apLXJ3l3Uf7/nuSISQ5XAEdDO0WSvyU5fpLfNqH28+Xnt5P8ebZT7uytBmCNnz/K/u0L7zr0Bqb5500ycNwR+wHedxpO94PiBd+WxLa9sgFYo6eT/HCtzlf/TvLH4pVIE4cqXkrI/EWSYyR5T5JHJ/luku+V/Y+T5ERJ9i4/VQf8jsP5mIM/lH15NhWDA5PwhDvWBmCtnTqC6gcLgJ5U1HqFbZ7Gp21HS/L+JMduQt2+zbZnKFrZkZI8L8nLptQsyRxnTSJpOGWTJAi5PocsIq4qAU73mZ2GsAFYa2fsno0nemQSIeoKM0wocCH2Z0py/bIfjnWDAhJKv++p/bMY7+Y4zq2Dg+ncuFeSD89ygGXYZgDW2lk4IMmtmj8/qAlTD55xkqj4Tyxg0rpzl5Z3O00Jq2qXn2o6Mt7Y1DE/MuNxhU08745JVA7u0SQKj5lx323dbADW2uGnwCtk365wJWDotuDwJHgYKQKvqnaThns9NAk+duPCl9pnALI7NF7t3EUbA2KZ4jTjxd7QeL6zN9noBXZCdWAA1topfWcTei7dSAaEUcBBoqnx+M4Pk3y//P2iSe7bNBo+vHOIoxdepJ2Hx3t8IeftzQ7fgM7+wIf0v6ZIGL+cgDBammvA6cgeS20DsNZOD41KiUcPlyzN70cYM4u8Df4kK9T39dHSzWrzpxTvhHjrF6tZYvdQx2oAc+Uk1yik/bnlmKOywreW5ECm2U0klgpoA7D2nA5E/Bsly9vIRAEDr/b2olOdvgDGse7eNCI+a8pBT96ExhuWkhKy/5Ikn27t8+wkt2gSAd4QkJfWBmDtnprDlqxL7xZ7bcnkflbUdt8TPC9SvIayDr2KZyMZnHjCLP+36FVfK6EUZ6PMkxXoYWQHv+NmjvvPonW5FlKHDBVotWH7G8/4zXI+ff/2Y39qPRT+7jzCJ6/pWrfMBmDtHmqcB38hgsrAcCccqmuyxQcm0ZUKMGQGJjydtpRzeB5EHeCIoMDTtq8n+WQ5D04GTJT4aj8qvOwvBVB4mF4ypF83hpCIl7XNMYCVl2RKSTwbXY6Iy/NJSCQjC7cBWLuHWCYoIyQFXLCk9dL7rj22Ad/dGo/y8sKdpvEdoAK+M5eWab35vBuPg9hLEgBoFiOevjcJL2o/PA4Ip9k5mn1uU8KoioIW7YXaAKzdw0tC0B7DEyDbnnBZmyywXTi+a+NpHteEnf2KkLpPkQJmnShAA9zrNV7PvorXL03y/BLiJh0HIHk2IRVA8C0ejKcVuqcVuPFH25MvLJlbmA3A2j20eA5l+yzFC6jnMeHlc6XTlBzA47yiycruXDJGoWWUZ5t10hS7AYTEIbzKCjUZjmvNwZ14rJOUEwCmMC6zlJ1qUhy3KkmGK+sVHheq4g/A2nP6LcBQm1O3E2oUmwEON/lV4TgINPWc0KkmeLHSRz8rkMZthwfdu4Qs8yIsP6cjwNoXd0LuheCuuR7hEtf7ffGECH01+hd+drkk79jsBU/afwDW2tHhCehXOgwsvGBIM71KZsZb8VBKOIrVQhgCPi8DMAtub1lIP6IPZJavIfwyPMBXuJZojDP6mAW9AGgfrTnvK1zP9eqoWJgNwBo9tABFi6KcywKZBj9hipDJ8JXzFA/CywmZONO8jNKOy/EuwiJJQUFb/ZDsoZNi1oW4MlPXLgTikTJMIXVhturAQsQrl5JdUbNpRhR14FIP5JWUdqrSjeQ/otTshBNEnOxAoiCCyhrnacDwkKKf8VCaDoXnnxROplZpfaRssWv4l2xQKLeu0j1ISCzoReIPKiFx7kvfVhlYtCG8adQYCIXWG/JK+qp+XLI4NUNWe7aIjsIKxZ7JymhX35onssqxLL4FWqDgbRS7ZYO8piVs+KEkg6fllYRvD07V2SxtA1DEvxq+yHsJm+4ZscfhNm2rDCxPPd5iYPElXOacJTvTT1WB8oXytGvm06ulQ5RKLhvkBZB4pRpvvWGOg4PxZvMMNx4E1wLI+JJrlKVqRpRF/rVJNu5URN0KdNdDeZfBTssCdU7IGoGMRjdt+4ngW2VgGRhEGaHVbYDL0IeYp5wEcPOyUAK/Ee5oUADlO56D/mR/EoWeLNsBHSN6AgB+5G91rP271hRtrzhNU8LR/F5LPIDvexKC/U08gPgQOMkUhFqeiqd0fbJCxvsIjTyqN/Mg8Lo21BrbHmsUOCwMIRaTPyQsskigXZetOrAMFq6hQ9OAIut4VR1IT69OUN2b3YURJtOkK994unEvMgAPcusSdoRMKT4uQ8A0SXgO7+d8bdNBAUxqkvga8zeg8G88qRJ4Qml9s053wtUHgd1P5xLGkX7cDMhcL2CqN057l5isUtMikVjv2Cwq/67rGYD1/2kRxijZOjWFGAOPHEvrtQibYEo8cNGIqln4cN6yPZ4DpIi+jM22Ny0e5UrFC5goDXtan4XMScYD+lhC5hz2wX8A0vUCtvPzTJaiqRESbwmltTapA8J2aobm2rvDcDPHBH4hEx9zTZMIvPvB14D+YaU/beLFrzqwTAZSjFsZPGm5iROajA0PZCBNqr/xKADkKa796AbYdkLNFYs+pGSi5YV+hDBXE86AV8aJ4JMpCJgm2LXwQnQ04BYynY/V35F33kcWKNyNUueFMFmrc/Ew+uddh+5Wb0IUonlS3kqIRQGuW0IpboUb1m6JLnhk0ArzQrmfPPZIW0Vg4VXqdPqeZHAMCfbkCom8gEnzVBMpb1tA5XseAMcCChkVwNGbWJtfCRuARTuSIAhLzqsQDbx+51UqYJxfqMSx8DKAAGRekwc0iRIMgJ7F8C7CrVIPkz0qWLsvmSOJQj20be4XCD04QjbVX9Y8yrRHS2QItnrw1yQpqwQsXMciCaHNpJIOqOh0K0808jvKbCt1N5g0K50CQpSnFn/BgXCxSWY7vEdHgwQBYEgZAMXzmSR9Vsg1r6FmiIch6sDtXDzQpNbl7vl5wSeU8Cg5aZvzU+5HGS/G8xqr2oHRbulp7yP0ykRlxS9sf7EKwDLAanvcPzLrSeZJTN5GDZcStngexBr4rM7x92rA5MmXYQFJLWZry+ExcLY2rwGsJ5ewDHQnLWGZWOvagWEj5tyyW5krycIY8H6zdKB6oGSehFkej9zRNfxTePfg7l9rm30HFveO2OJPwhNlfFJ9bSMTV/fxxCr3IMJCCkPeeSCDDtBAWHmTzNMkAxePglu1GwKFIeHQQyHtx+HGcZ/NXPcs+/JuFuS6dtdhTLvGc9P0yDAH9BVYvBSRkt5E2yFq1prfLAO5kW0MvncykAUkBOqGuIeXu1G0pfpChrCn7ojAC6uuj3cDJMQch8P18C3SgGxVOJRUUM9xsc14243cW93HdfNOwCNz9hB1wS5x2a+PwOI1nlbSfSSb99CpsBUGOKQBKT9+wgPxOrI0H6KmWp3Mbb2G+NtfaBWCcUMLLny2+tXjPKzkx4MLXJT/Pbol+gQsk3i/0o8uqyJUzrsgPA0MsjEdB1J4WZfQICmQPcrQgMvTjp958jdq9kf6hVjamLAq25P1mehp6vpGz9vdj57GM/PSHl73t0uC6BOwAEmGIoTwGNv1RmTEWDiQ0ck8hTreBd/yHYIv8xJKFLg3a+aQaCu08oQAB1gqCOQAtcKZFfNNXIxI4cEmbezfF2CZRKm1tJjYuZ60fBNjOXJXirsSjoyK8EjpBiQeDD8y+UKHDA3vGpVpbeaaqOO8I55X5RGiKO5GpUcPAA6na3eXbuac7X0BbN8+AEs2gvTKuMT97rKoeQ3Yeo4j9NG2LLgwkToSeFJhUNhCxC0hI9QC36Y6CaZcmHBFyiAGC5v0MCKt8SJhUODVAiUaAEjqADgLb4V1csc4jW/cqQ/TB2DVdX60mnmElvUAaNy2vBawC0vacizzwgF5ViG7mv50IVF/vUL3Vr1sjWyghFTLR2QZvA0I/SQA0798YESNUuVBQqIyAZATPW0fgEXoM0DjlOR5AGUjx7Dg1aJVXhTI8C4ThA+137tAvSaNKO8g+8LUshhPy8MpW1WP5ydg0gOJvCQWgDMPfu7qmOgDsLhr5HQjKfwiJ9DTroPBKh5SAYEU17p/4V3tc/NWuhBICcKiULruHqhF3kzr2NpvhHSyiu4PpS5g0wbNAOugPgDLE64OZ+nUshkQEUHpT7JUfLC2L7e9FsA9qtGnnlnUe4VgxedFtDgvYozwNWFfwiJh2LsPwMJZeASeYdlM5oe041K4i/IOwVRfVPdBIEsIiTJGHE3XAJlC/XDHWR+AVV/m4alZRPq82Um1hAuodKKqseFa+KD6ZfedWUi0Qq7CL8/G4+FpWneW+n1Y3UHqA7DcE0DJComCy2bAgmtZTcODKeJK4YFKyOsa3iLT9X/7aCDEZSxg1Ta9TMR+4jj3BVhCjEIu3WgZTbgmXFrjJ7yRHnhapJ0U0TUqupfh1vvhjXkyYBQal/6/XOkLsDSmmSBhYxmNF0LeaUe41CfKsnm98K55VKWA9KDXSWdGNYDTV6XLYaFL5Dc7iH0BFmFPZ6anWlq/jGZFtTqaMGcxLICRJMglujVHmXvRvcAjV9NKQ/uSCW9V18a6x7MvwHLjirwmDZfZqur+egZcF4Bs0CJXJR3CooUWwqF2acp212xnZbNFEO13w3uQhFWcbdF9Zuu5x4O37ROw3JQnXOvKMkoP1Gr1N9eoC0CI03JMrdaG7PdRpvdK8ZiXouC3TcFdBmmRxVI9TH0DlgY09UJFVZ5g2UwnKA9jpTWgKfjqGQM0BWm9VKNMEdmqHy/W7QJIOKV5WUq2DAX4XdffN2C5J23JuJYsrC4EWBaAKXsoeWhP1m0qFArh3n8lHNK2xhWihVKLRrXajHpnqQWoAOvY014ZufDx6COw6qB5wYXORk8xsrwstTeipxKPFhYEnsZl7WHNbEfJD/WecC3eC8hGvUNUxijEUvDn3ec1KxiJv/v0GVh1IDTY4SD+izfLvizD2k4z8DJYoVpvvoyQzkVC0Jsl65t0je5B7xQ1fpTpUKX2a+yb9h8WzGMcYKh2rrr+XW/qWQVg1cGzfMkyc3zEC2AX+tbgKTPGq+BbvJbQaMEsvqVLQLuNVcjjTDi16ofUoFlwnAmNCsMU/Hm+TqmeT+KgUI4b6t+SWJBTtGMfuErAMiCWLwlFnjD8ZjvJrgWgPJUOBkIpsGhd9n6EuvR/HGh4JZmiDJOEMc4ch0cUQudRayR/8JTWFqh/WvNIY6Op7fFSkVUDVp0Ak6f2Rprw1KvfbaeZB9dAl9I2bDHIKF2rfY2a8Kw/lGVOqpHaDoiF3VlWP48aB9qgZWsSjfrKcK8nGPv2v1UFVh08oYjn0idlBY3sbKvag7sTqJdJkVlIFOZ0nk4znbPeDsMjjZMqHIO0gXcpJc1SqJdR6yPj2YU7gNdCbTX5pPdcHHy9/wNrZ6FmDPUafQAAAABJRU5ErkJggg==\"]}','2025-05-16 12:21:21.581646',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(135,'4',4,'Test, Mikael',1,'{\"member_signature\": [\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAAEY5JREFUeF7t3QV4JMcRBeDnMDMzO8zMzJw4zMwOOMxxmDlxmJmZGR12mJmZGea/dPvmRkuSdqXV7NT37SeddrD7TdWrV9Vze2WwYQQWMAJ7LeCYwyGHEcgArAEECxmBAVgLGdbhoAOwBgwsZAQGYC1kWIeDDsAaMLCQERiAtZBhHQ46AGvAwEJGYADWQoZ1OOhOBdZ9klwoyT+SHCbJv5J8LMkLkvx0mNbtH4GdCqxLJLl6krMlOV9nGJ+e5AFJfr39w7u6V7BTgdWesfMnuWaSayc5Qfnid0k+kOQtST6e5CurO8Xbc+d9AFZ75C6c5GpJzpjkkq0vvpzkzUleneSz2zPUq3XWvgGrPXsna7zVZZIA27mSnLp8+aUk7yp87IurNd1bd7d9BlZ3FI+c5FJJLlv42TFLmHxxklcm+c3WDXv/z7RKwGrPpvu+fJLrJLlKkkMkeV2SZxSw9X/mF3yHqwqs9rAeJclVk9ysSBhfTfKqJE8dvNjG0TcAa8+xO2GSGxVPdqoSIl+U5EONhPGfjQ/z6u05AGv8nB+vyBiAdrokbypAI2EMIJvyrAzAms2ZXLyADC87apLXJ3l3Uf7/nuSISQ5XAEdDO0WSvyU5fpLfNqH28+Xnt5P8ebZT7uytBmCNnz/K/u0L7zr0Bqb5500ycNwR+wHedxpO94PiBd+WxLa9sgFYo6eT/HCtzlf/TvLH4pVIE4cqXkrI/EWSYyR5T5JHJ/luku+V/Y+T5ERJ9i4/VQf8jsP5mIM/lH15NhWDA5PwhDvWBmCtnTqC6gcLgJ5U1HqFbZ7Gp21HS/L+JMduQt2+zbZnKFrZkZI8L8nLptQsyRxnTSJpOGWTJAi5PocsIq4qAU73mZ2GsAFYa2fsno0nemQSIeoKM0wocCH2Z0py/bIfjnWDAhJKv++p/bMY7+Y4zq2Dg+ncuFeSD89ygGXYZgDW2lk4IMmtmj8/qAlTD55xkqj4Tyxg0rpzl5Z3O00Jq2qXn2o6Mt7Y1DE/MuNxhU08745JVA7u0SQKj5lx323dbADW2uGnwCtk365wJWDotuDwJHgYKQKvqnaThns9NAk+duPCl9pnALI7NF7t3EUbA2KZ4jTjxd7QeL6zN9noBXZCdWAA1topfWcTei7dSAaEUcBBoqnx+M4Pk3y//P2iSe7bNBo+vHOIoxdepJ2Hx3t8IeftzQ7fgM7+wIf0v6ZIGL+cgDBammvA6cgeS20DsNZOD41KiUcPlyzN70cYM4u8Df4kK9T39dHSzWrzpxTvhHjrF6tZYvdQx2oAc+Uk1yik/bnlmKOywreW5ECm2U0klgpoA7D2nA5E/Bsly9vIRAEDr/b2olOdvgDGse7eNCI+a8pBT96ExhuWkhKy/5Ikn27t8+wkt2gSAd4QkJfWBmDtnprDlqxL7xZ7bcnkflbUdt8TPC9SvIayDr2KZyMZnHjCLP+36FVfK6EUZ6PMkxXoYWQHv+NmjvvPonW5FlKHDBVotWH7G8/4zXI+ff/2Y39qPRT+7jzCJ6/pWrfMBmDtHmqcB38hgsrAcCccqmuyxQcm0ZUKMGQGJjydtpRzeB5EHeCIoMDTtq8n+WQ5D04GTJT4aj8qvOwvBVB4mF4ypF83hpCIl7XNMYCVl2RKSTwbXY6Iy/NJSCQjC7cBWLuHWCYoIyQFXLCk9dL7rj22Ad/dGo/y8sKdpvEdoAK+M5eWab35vBuPg9hLEgBoFiOevjcJL2o/PA4Ip9k5mn1uU8KoioIW7YXaAKzdw0tC0B7DEyDbnnBZmyywXTi+a+NpHteEnf2KkLpPkQJmnShAA9zrNV7PvorXL03y/BLiJh0HIHk2IRVA8C0ejKcVuqcVuPFH25MvLJlbmA3A2j20eA5l+yzFC6jnMeHlc6XTlBzA47yiycruXDJGoWWUZ5t10hS7AYTEIbzKCjUZjmvNwZ14rJOUEwCmMC6zlJ1qUhy3KkmGK+sVHheq4g/A2nP6LcBQm1O3E2oUmwEON/lV4TgINPWc0KkmeLHSRz8rkMZthwfdu4Qs8yIsP6cjwNoXd0LuheCuuR7hEtf7ffGECH01+hd+drkk79jsBU/afwDW2tHhCehXOgwsvGBIM71KZsZb8VBKOIrVQhgCPi8DMAtub1lIP6IPZJavIfwyPMBXuJZojDP6mAW9AGgfrTnvK1zP9eqoWJgNwBo9tABFi6KcywKZBj9hipDJ8JXzFA/CywmZONO8jNKOy/EuwiJJQUFb/ZDsoZNi1oW4MlPXLgTikTJMIXVhturAQsQrl5JdUbNpRhR14FIP5JWUdqrSjeQ/otTshBNEnOxAoiCCyhrnacDwkKKf8VCaDoXnnxROplZpfaRssWv4l2xQKLeu0j1ISCzoReIPKiFx7kvfVhlYtCG8adQYCIXWG/JK+qp+XLI4NUNWe7aIjsIKxZ7JymhX35onssqxLL4FWqDgbRS7ZYO8piVs+KEkg6fllYRvD07V2SxtA1DEvxq+yHsJm+4ZscfhNm2rDCxPPd5iYPElXOacJTvTT1WB8oXytGvm06ulQ5RKLhvkBZB4pRpvvWGOg4PxZvMMNx4E1wLI+JJrlKVqRpRF/rVJNu5URN0KdNdDeZfBTssCdU7IGoGMRjdt+4ngW2VgGRhEGaHVbYDL0IeYp5wEcPOyUAK/Ee5oUADlO56D/mR/EoWeLNsBHSN6AgB+5G91rP271hRtrzhNU8LR/F5LPIDvexKC/U08gPgQOMkUhFqeiqd0fbJCxvsIjTyqN/Mg8Lo21BrbHmsUOCwMIRaTPyQsskigXZetOrAMFq6hQ9OAIut4VR1IT69OUN2b3YURJtOkK994unEvMgAPcusSdoRMKT4uQ8A0SXgO7+d8bdNBAUxqkvga8zeg8G88qRJ4Qml9s053wtUHgd1P5xLGkX7cDMhcL2CqN057l5isUtMikVjv2Cwq/67rGYD1/2kRxijZOjWFGAOPHEvrtQibYEo8cNGIqln4cN6yPZ4DpIi+jM22Ny0e5UrFC5goDXtan4XMScYD+lhC5hz2wX8A0vUCtvPzTJaiqRESbwmltTapA8J2aobm2rvDcDPHBH4hEx9zTZMIvPvB14D+YaU/beLFrzqwTAZSjFsZPGm5iROajA0PZCBNqr/xKADkKa796AbYdkLNFYs+pGSi5YV+hDBXE86AV8aJ4JMpCJgm2LXwQnQ04BYynY/V35F33kcWKNyNUueFMFmrc/Ew+uddh+5Wb0IUonlS3kqIRQGuW0IpboUb1m6JLnhk0ArzQrmfPPZIW0Vg4VXqdPqeZHAMCfbkCom8gEnzVBMpb1tA5XseAMcCChkVwNGbWJtfCRuARTuSIAhLzqsQDbx+51UqYJxfqMSx8DKAAGRekwc0iRIMgJ7F8C7CrVIPkz0qWLsvmSOJQj20be4XCD04QjbVX9Y8yrRHS2QItnrw1yQpqwQsXMciCaHNpJIOqOh0K0808jvKbCt1N5g0K50CQpSnFn/BgXCxSWY7vEdHgwQBYEgZAMXzmSR9Vsg1r6FmiIch6sDtXDzQpNbl7vl5wSeU8Cg5aZvzU+5HGS/G8xqr2oHRbulp7yP0ykRlxS9sf7EKwDLAanvcPzLrSeZJTN5GDZcStngexBr4rM7x92rA5MmXYQFJLWZry+ExcLY2rwGsJ5ewDHQnLWGZWOvagWEj5tyyW5krycIY8H6zdKB6oGSehFkej9zRNfxTePfg7l9rm30HFveO2OJPwhNlfFJ9bSMTV/fxxCr3IMJCCkPeeSCDDtBAWHmTzNMkAxePglu1GwKFIeHQQyHtx+HGcZ/NXPcs+/JuFuS6dtdhTLvGc9P0yDAH9BVYvBSRkt5E2yFq1prfLAO5kW0MvncykAUkBOqGuIeXu1G0pfpChrCn7ojAC6uuj3cDJMQch8P18C3SgGxVOJRUUM9xsc14243cW93HdfNOwCNz9hB1wS5x2a+PwOI1nlbSfSSb99CpsBUGOKQBKT9+wgPxOrI0H6KmWp3Mbb2G+NtfaBWCcUMLLny2+tXjPKzkx4MLXJT/Pbol+gQsk3i/0o8uqyJUzrsgPA0MsjEdB1J4WZfQICmQPcrQgMvTjp958jdq9kf6hVjamLAq25P1mehp6vpGz9vdj57GM/PSHl73t0uC6BOwAEmGIoTwGNv1RmTEWDiQ0ck8hTreBd/yHYIv8xJKFLg3a+aQaCu08oQAB1gqCOQAtcKZFfNNXIxI4cEmbezfF2CZRKm1tJjYuZ60fBNjOXJXirsSjoyK8EjpBiQeDD8y+UKHDA3vGpVpbeaaqOO8I55X5RGiKO5GpUcPAA6na3eXbuac7X0BbN8+AEs2gvTKuMT97rKoeQ3Yeo4j9NG2LLgwkToSeFJhUNhCxC0hI9QC36Y6CaZcmHBFyiAGC5v0MCKt8SJhUODVAiUaAEjqADgLb4V1csc4jW/cqQ/TB2DVdX60mnmElvUAaNy2vBawC0vacizzwgF5ViG7mv50IVF/vUL3Vr1sjWyghFTLR2QZvA0I/SQA0798YESNUuVBQqIyAZATPW0fgEXoM0DjlOR5AGUjx7Dg1aJVXhTI8C4ThA+137tAvSaNKO8g+8LUshhPy8MpW1WP5ydg0gOJvCQWgDMPfu7qmOgDsLhr5HQjKfwiJ9DTroPBKh5SAYEU17p/4V3tc/NWuhBICcKiULruHqhF3kzr2NpvhHSyiu4PpS5g0wbNAOugPgDLE64OZ+nUshkQEUHpT7JUfLC2L7e9FsA9qtGnnlnUe4VgxedFtDgvYozwNWFfwiJh2LsPwMJZeASeYdlM5oe041K4i/IOwVRfVPdBIEsIiTJGHE3XAJlC/XDHWR+AVV/m4alZRPq82Um1hAuodKKqseFa+KD6ZfedWUi0Qq7CL8/G4+FpWneW+n1Y3UHqA7DcE0DJComCy2bAgmtZTcODKeJK4YFKyOsa3iLT9X/7aCDEZSxg1Ta9TMR+4jj3BVhCjEIu3WgZTbgmXFrjJ7yRHnhapJ0U0TUqupfh1vvhjXkyYBQal/6/XOkLsDSmmSBhYxmNF0LeaUe41CfKsnm98K55VKWA9KDXSWdGNYDTV6XLYaFL5Dc7iH0BFmFPZ6anWlq/jGZFtTqaMGcxLICRJMglujVHmXvRvcAjV9NKQ/uSCW9V18a6x7MvwHLjirwmDZfZqur+egZcF4Bs0CJXJR3CooUWwqF2acp212xnZbNFEO13w3uQhFWcbdF9Zuu5x4O37ROw3JQnXOvKMkoP1Gr1N9eoC0CI03JMrdaG7PdRpvdK8ZiXouC3TcFdBmmRxVI9TH0DlgY09UJFVZ5g2UwnKA9jpTWgKfjqGQM0BWm9VKNMEdmqHy/W7QJIOKV5WUq2DAX4XdffN2C5J23JuJYsrC4EWBaAKXsoeWhP1m0qFArh3n8lHNK2xhWihVKLRrXajHpnqQWoAOvY014ZufDx6COw6qB5wYXORk8xsrwstTeipxKPFhYEnsZl7WHNbEfJD/WecC3eC8hGvUNUxijEUvDn3ec1KxiJv/v0GVh1IDTY4SD+izfLvizD2k4z8DJYoVpvvoyQzkVC0Jsl65t0je5B7xQ1fpTpUKX2a+yb9h8WzGMcYKh2rrr+XW/qWQVg1cGzfMkyc3zEC2AX+tbgKTPGq+BbvJbQaMEsvqVLQLuNVcjjTDi16ofUoFlwnAmNCsMU/Hm+TqmeT+KgUI4b6t+SWJBTtGMfuErAMiCWLwlFnjD8ZjvJrgWgPJUOBkIpsGhd9n6EuvR/HGh4JZmiDJOEMc4ch0cUQudRayR/8JTWFqh/WvNIY6Op7fFSkVUDVp0Ak6f2Rprw1KvfbaeZB9dAl9I2bDHIKF2rfY2a8Kw/lGVOqpHaDoiF3VlWP48aB9qgZWsSjfrKcK8nGPv2v1UFVh08oYjn0idlBY3sbKvag7sTqJdJkVlIFOZ0nk4znbPeDsMjjZMqHIO0gXcpJc1SqJdR6yPj2YU7gNdCbTX5pPdcHHy9/wNrZ6FmDPUafQAAAABJRU5ErkJggg==\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAAHV9JREFUeF7tnQfYbUdVhhdoVASl2RBRiiEaQJEIQSB0AtgolggoxVBTADGKtAAxD4QmEErAAEkAA4kGQSKCKC0qEimWRFSKNGtoQugE2W/uGu7cffc5Z5cpe5/zref5n/vf/997ZvY3+3z/zJq1vnUZky0dgcuY2e3M7Ggzu2uCh/k7M7tJgnbUhBBIjgAvu2y5CPykmb3czA7yR/iMmf2lmb3JzC4wsw+Y2Uc7Hu8GZnZVM7uumX2vmV3PzI6IrvtpM/uz5cKikW8rAiKs5c7szZqV1Xlmdlkz+wczO9HMXm9mF498pFub2Zv93oc2hPacke3oNiGQDQERVjZoszb8Ow1RnWBmnzWzx5jZi5t/vzKxx5iwnu9bzIlN6nYhkBYBEVZaPEu0dpKZPdLMPmRmh5jZJxN1GhPWU72PRE2rGSGQBgERVhocS7XCVu3ZZna+md3dzP4jYccxYT3IzH4/YdtqSggkQUCElQTGIo38hJm90bd+h5nZ+xP3+ktmdra3+cuNI/4PE7ev5oTAZAREWJMhLNIA8wRZEb5w28g5nrLzo8zsed6gVlgpkVVbyRAQYSWDMmtDrHjOMrNXmtk9MvUUbwnfYma3ydSPmhUCoxEQYY2GrtiN32Jm7/ZYqR9I7LdqP8T/+w/e0YRI3LTYE6ojIdATARFWT6AqXnY3M3uVO9sfnnkcgbDohqDS92XuT80LgUEIiLAGwVXl4teZ2Z3M7Dpm9u+ZR/DHUXrPE5u+npC5PzUvBAYhIMIaBFfxi6/lp4F/3aTb3LJA77Ef6w1OlAW6VRdCoB8CIqx+ONW66j5m9iIze6CZnVZoEKT33NH7up+ZnV6oX3UjBDYiIMLaCFHVC17oZHWoB4uWGMx9I3K80MyuX6JT9SEE+iAgwuqDUr1rXmtmP9skNn+zmV1ScBj/28Rkfbf3J19WQeDV1XoERFjzfkM+4kSFL6ukxVHv9Kv3pCT66mslAnoR5/1y/J+ZfdDMSMspbUjN4ITHpN5QGn3114mACGveLwZKDBAWQn01jP6vbGafayLtf3SFGGCNcanPHUVAhLV34smlYyuEbAuG7yZ8X+v1gKzwXR1YaQCcUB7pfT/XzI6tNA51KwQuRUCEtedFIObo8I53glM6osyRHS7p9A5DQUbmxmb2bWb2pUrvbBz9rvel0iSo2z0I6AU0u2aPCPL/9tQYiIsiDaXsDDO7p5ldzcw+XqrTVj9oxt8rWnUq+r3SRKhbERbvQBzdjSAe26DHr3k50Il6aeNXOrfAC0TgKAGj9/ZiEwW63K+LGJ//NLOr1xiE+hQCWmHteQfiD2TAhEoyrGx+b81rggQLUsI5q8ugfcWqrrb/iCIXP6ZVlkijNgLaEu6ZgdhPgw4UZIShmf706Hi/a76QEj6lSRr++wyTie/qf5oSXO+tLPcCWUFaGNHvVOyhpJhMCBRFQIS1B+6ToxOwLnlgHN8/06THUK+P79tG7T/q+r09w+xBnrcwsytNKOGVYljUOaR+IYZ6BAcVMiFQFAER1l64kW7BAX9REyj5PWtmAZnix65YdT3CzN4TrdBSTCYlvZ7ksi9/kqLBkW0gn0zoB0ZCNInRMiFQFAER1l64IZobeuxVn1QYcvx+s4O4WGU904uaUjdwqt3eHfz4sY6b2tiE+w/27SBNcGrKyaVMCBRFQIS1F+5XN6uju/h/Iay+QaOc4lEq/qdaM8dpYviaMqlXcaLAR3bnKQ0luJdT1O/3dvBj5dgCJximmthWBERYe2c2Pi0cqlDAvfh10K0ilSU2SItcvODIH/MusV3l5BI/1pfHNJDonpjUVVknEahqpj8CIqy9WFHs4dNmdjlPyxkTIElqDzFcwTkdWoesnjEhdusl7jP68aaA6j/2n97kV4JJiFFTZZ3k8KrBTQiIsPZFCP10tl2EKrCCGGP4eojhumuLuD7WpPc8bqSCJ6eTf+onmfiyallXzFqtsajfHURAhLXvpIcVBL4ZfDRTjA83sjBx8CknkPz8nwc2/INm9i+N+ucfedT7wNuTXS7CSgalGhqDgAhrX9TivEI+nG8dA2rrHraJkBY1BYOhvjCk1DzzhHLDV7z8VoJhjW7inR5QSwPI3rxrdEu6UQgMRECEtT9gb2vSYQ5r1Bv+pikPf/OBeK67PBbE4zr8XENWWpTguoOZfV/lANIQr8YzHO0HCglhUlNCYDUCIqz9sUGZAIWCz5sZQaJ/m/AFOts1t2iS074rmtkXe7b/ux6wSvIxSci1jBgsTiyxpzTjJ7BVJgSKICDC6oaZOoD4sDjGp/JySmNVhXonhpInYRBs9TYZVZ8JSMUBnzPhetM4Ljazy/tF+NTY8sqEQBEERFjdMENSZ5nZAb4tZHuYyogQJ0yBuC3sw54StKl9AlPxqZ3QVNE5cdPFmX5PJR0q6gRjm3r3TH2pWSGwHwIirO6X4pvcmUzcEz6tWyV+d3DA/0FUzZmQBVJ91hlbQVQbWGWt0+tKPNT9mouVLRSLlRtttb8PAiKs1S8EvqxTPZA0RxrKdV1+OQSZsurCib3Kp/Vdnpj9Go/xqvUqx053JUHXmoUd7VeEtXriKV76bjO7gYvokYSc2iDCc/zkj7YRBHzkik4u66eDbMkIv6hlWmHVQl79StN9wzvwMCcR0nZSxWW1u+Qk8i/8h1/zCHtkmruMgFbE9JC/wWFfw0RYNVBXn5cioBXW+hfhO73oBNs3ik8c2lInTfUa3de120N7+MzwnbWNU7lf8LJfQwJPU42TduLA0SkpTCnHpLZ2BAER1uaJvr/nFoIVqqPkG+aw5zSVcY7xhj/gwav/1ero9Y2kyx1dBqeWmJ8IK8fsq81eCIiwNsOE7+ivXO/qE2Z2HTOjhHxq+3Z3wkNIYSVzy8an9YWoI+RrkKo53lVIU4+hT3tyuvdBSddkQUCE1Q/WX/UtG454ZGJyKX9CWsFPxcie1ZDjb0RDJLL8t10YEO35GkZRjCAhzYqvtqhgDQzUZyUERFj9gacK9AO8AjOVdVKm7MSjIAqe0l5BgpjATAI0MU4QTzKzfzWzH+k/9KRXxoR1XhRLlrQTNSYEuhAQYfV/L3C8k8CMRDC5fAR/xidm/VvafOU9XDeL00l0tFBFgCj4+ZnNlpDTxO/wfMfNraW9grAKIt4xrbDSYqvWNiAgwhr2irA1fJnfwkrnUcNuH3Q1VWoQESTqnqh4+qbcF6sa7EZeoWdQowkuVlhDAhDVxDgERFjDcWOFw0oHQ4YGh3wOYwVF4Ylre+M/5/LI5B5iv+L5jjn6XtemnO6lEVd/30BAhDX8ZaAaM9VjqGaDRAwpMynKeXWNhBPJP3fSgqiIA0PID+c8ooCUGSttcdn6M5rqQsSQyYRAEQREWONgRvqYtB3sVR7MOa6lzXdRtBUtLAzH/209cBQJHLaIpY0wC0gb4+ChXd6s9HjU3w4hIMIaP9kP8ZgoHODIveRSUMCH9QrXnSIxmgj4w/20kkj8kmW/2vIy0sMa//7ozhEIiLBGgOa3XMEd8FTHwYiLogZhDiPE4QLfhn7UzK7hnVw/qsaco9+uNuV0L4W0+tkPARHWtJeChOiHuiopKqCogeayYxvCOrnV+P1Glg2bMsbY6S49rClI6t7BCIiwBkO23w2QFrpZP9xEfb+jiU266fQmO1tgrsg3PCpKWn9xE6dFrmNJo5ArkjuYCKsk8upLag2J3gEcz0FGeWiZ+yFDwNlN8nEQ/aNWYdCHH9LOlGvxo32rN0AaESs/jHQdDiMo+4X0DVtH/HsQLZr1nC6W9LdNeUbdO1MEtMJKNzFxGfec1WQIbSD2i7xGCAGiICl7ivEe4A+jvYOaxGoi7K/aKFPcxKPpqZJDIjbEQ5mxsUbSOER2iRMZ5PYRb4wDBIwiHUGSOggVolrxTxOqcY8dr+6bGQIirLQTQtgBigpYTq0oCCvUTPz5prDpa3s+BhWk7+lkxMoMIiLWiyBVCLBtEAunlBirI1Z0CAgGY0u4qdjsD5nZtaJ7UL+4cRQa0TX0D0U/hIwPif6vd7bnZG/jZZr89LMaO8dz+Xh+vTkpxH+Frcrng4AI6mS1xAf+3itI6dO+XSO+CpFCVln4qRAIZGtHHcKgbhqvIumbJHCeMbdBiqzwgum9zY34TNvXxOeZmPiDzQf6yR6xnqo3tm2sdsLKh2BS6gXesAloZcWF5MvlWp0RjU+wK74kEqnfNEJxol29uhRhcbBB/UMOHLALfQubCk+1sxAERFj5JooP2XPdQR62ThBZCuOUjm1h8Pt0tYm/ibQegjtZLRGV/tWJnRMLFhz+KFZQeqykkY4U9MFEWiWRn0lfIqy8E4HT+LeilcGQLSJyNl9yUsD5jbP9Su67wufUNmSVOal8Y+Mjos7hJxM/WjvKvS0umLi7lc3Fq7ygYlGqb/VTGQERVv4JYKUF2SBHgxObVQpOZ1ZAJFBTrJXYLUiIlRNbOX6/avWET4k2CHEIuYScvKFTRT9BzSH1k7UDV6lc/YbUnfRs72zfInJ5qW1pz6HpspwIiLByorunbYT+DvStDNWd+2DO1o0gVP5FXRR/FaXAUGoIDnAKYpzrw3+f98EH+YhMj8T28g7eNs556jR+JlNfm5qNybPWSm/TGPX7DAj0+fBk6HYrmwRLjvwJImXFRNgB26grrnnaz/vJ3Huaijkfd5KCkM731dg6oK4cbfuIU+K0j1AFEqPZFqY0trak5ASrEWHffh60wlidypeVcqZn3pYIa9gEBVJCspiYJj4wbMfYzkFQQXYlbvXfmoBHCIUTOrZzhAw8M9JkxxlOyAGrpKEWp8lwgoaTn3YgrpTyze1wBratRLzXNEg5VOMmePaimoNR32UQEGHtjzOR3AQ7oibKKgYiouAD3xPTtMoCGbGV44uVEmk0hBu0jdSWZ0eR2/i2UDEdqvbwymgLiALp0T7ue7n2e6q3KHZ0Dzk4SNV/Vzskgoe0oJxKGTmfQW0PRGDXCQsnNzFMbKOQbGHVtG4LF+DFwY1wH6snPsysasaUjodk2F6hIIqd5WJ9bHP62IObaPVT/EKE/lhxMS7SW1j9pTDSZOLg0Jy5kkPGC0YH+w2UPnvakJt17TIR2CXCghQgiNt5PhxE1ddYPSGch98EhzNJv4Gg8FNBdGwLCUMgqJPUEj5Ql3d5Y9JLcKAT2Akxkp4C9ge4xDKOcqSWMU4PyblDhplYK7aZpMUQgc73kCVlwNiS0R7bQIxK0ARXsvUkVirVKd5pLRnkuZzKoQvGgQamFVbfN3nh120zYZGOghOcGCZCC4bU8cPBzIkbaS9Ehb83mmc+JPhO7uOqBXOSCObUDmJjlfgpXxlBtmxnA/HxKBAmqTsQJl98z8/4wvfFFz4htsWhPiL3QdYhqr72q892O+QYkg/JCapsyxHYJsKixDsfLlYwx0TViTdNIYSEPjrKAaSrsEJpy6BQwBTCQ8GA6jW7bGDDIQIrSgJVUVsgnozDA7CD6MAUwsxl8aqP/kIl6lz9qd2ZILBkwmLVFHTU+fDEGf3r4CVNhZgiVk9srwgh6DpRo32+cIYTdT7U2BJymsaHly/6ZfvIao3iqGwRYy0rVghBaoWt5C+6kmnsU2OrSUwWbYetLdd2Rb4PHe+66xkrZESCNOSE74/cxHX9EmnPgQOJy/j6GDMrNJ59rDEfnIay9Q12ehMsi/KqbAcQWBph8cJCTLygIadt0zRBSJzasQKgCCm+j3VGhDmrNUIPNuXK8deddgngpCI0Hx5ilvhwjjlm59nCCo6TStqCLCEtiKmGQe48F4Uw2kZAbMCIUA98amyZWemuInkIi0MK/HC0DVbEo20ySIqVbvyH6fnubI/laDa1o98vGIElEBYfWpJe2WIgq7LOQlUZTttYyUAmQ+KRiDc6MnLmtvuiTdJi2ArhgB8irQLWkCyrFcgnEBOncBBxCgv6VaTn4MSnHw4CGHPXCpSDA1ZNweEfj4EtMnUHkWUea+hg8ZwQGL5ESCw4yuM2wZJIfnyHrMY45SS5GkN9ghNQ0pVi4zoOK7hXtiMIzJGwyI+DNNBy4kOzaauHo5mjfP5ad60C+kwlhIFfJChchnv4y82HFmc0KwMi0vlw8+Ehlio4rXFoE6lODBcywfh5+OLEj/Hj1J6ybWO1xnYSJVP6ZitJX13zB6m/xn/P6oVnIKUGIT6Ig20wPh9+HlYmPHd4dkiYvsasEDdhzXhZiUFaEBlVrQm/IKk7NkgW/DhdZQvazqvkDxF5jByM8CxD/nBsGqN+P2ME5kRY+Ioe5gm8fSAjtACSQuUTJ/BYiyVLQhu0h4+G0zWMD3BugzxY8UAUfL3O/892Nvi24jGQ6AxmVO1pzyNjf3UT6nAjX9XVqhLdFzNInq3lca6A2rUKW9cWaUngx8khByhsYWVbiMBcCCuOWl4HM9uXl/lf1LGrqbh9Kiqz3Vhn/KVfF+G+7l5INZw4QoI4zNmeIU3cXhmMXSXgO8OxTdWeTc/Btiuc5vHvVC34FB8JQhI41aW+Y3uFG7fP6hb8IGO2lvyL83/VPeBJUO9Lff7YQsoWjsAcCAu9qKeuwZG/nvgpCDlAJ50Tt1QWx/KENtlq8GHGOY/GFEQTb7+Ic0K1k+DOuVgstwI+RLwT4Nml0x7GjKP7HE+yxufFqiRsEdkih+9Z9dEOAbFsJ4nr4nu2u/gM+WJrDKmHf8GIbTTXYPgRWe2x1WNrCp70QTAv0ephJduFJyeLZzbbRlQZuuzhfhpJzB2BwetWwzwTz8J4WJ2XLpE2l/dlseOoTVj4JljCU7ElNvxFpKzwUoXyWTlA5uQJsmQLRmoH/45d6eQYX982ka2JC1Hg3MdxTQQ+kfD4iyCeWieNfZ+D6yAoVlP8UWA7jB+zr/F8bCvZJuP72mQUvqUArmwhCNQmLMIHiIeKLWe1mYVMy+BhtuVfSILmyB/D18WKEeNAgzkn/IAVDtsq8ijZVtY2Er+f7nFxU8dyBXfuo4LB8/KsXVvHB/mqfWp/ur8QArUJK45Y5i8p8VXUn5MNRyAO32grKkBYENeqPwbtsIr2lpCVCx94toRs4QiIZetFqAL+uLHGdp8cTcgVf19KQUAc9/j1eJaH+Elk2xepFdbYmat0X23CimVLbuYvbSUoFt9tjCVEEPuFwkkofxQIK8hhnPQR4EqIAiu4trHFC+k6+P/Y9k2xkImAX4owDw4xIFWc64SSbAqHUYT8FPQr3VuTsIizYoWFSTVy+gtANRmIKVjwY/F/yn4RJoHVnPMxT4nzntNACJjTQUI5pgTa4h/lhBlJGtnCEKj58sYnW0REK71i2svDhxkndQjCbEuuhC3jnDXQCcDFr8mJIitBSJcUpRTGaSYHOGjh11ZLTfE8O9lGTcICcII+Od0KxRR2chISPjSrh5Dbhy8wLitPWAihDnNaZRG1T2oSqyiSuTkASGWEdxC3xx9C4vw4DRRRpUK3Uju1CavSY29tt+Tixadh8fwSr0RCN1ZLhA8/Fw5wHPeMc1NyOWMlDo7gT3ILccp3pU9BSiG9CN8U8V2Edci2DAER1nZN6LpS8vh9+D1WwuHMCR0niGztCLNA2WGdQUw45jnR5MSQ7e2cgnO3601Z6NOIsBY6cSuG3SasxzWR3SdG1768kXahQAWWeu6JfSK9htM6FBbY6q0zSAlyIpuAlCHqL8qEwFoEUr+0grsuAg90v2AYBasUaiQGS1Vphvcm1GAkfAA1iHXOcYT8CKkImQtj9cLqoqveqyMgwpo+BfhO8KFwSlc7wRbpm7YsTOyvwhEf0qDiaPhVKEBCEBJpLviFCD7lezTtV+Upso1ja0dfnMqBCTmbMiEwGQERVn8IiZxmq8NqgtMnPrTk57WdwDh7X+Irihp5ie2EblKfiMPCiFQPycFP8hUPig34tyA74p3I76SwBgnMXRpekDPkRYI136MDBinh8A+J6v1R1ZVCYAACIqz+YLG9IhVliEFoSKKgWsC/xBkRD4WqAT9DeoafkTKCikEQBOSYn/+HcmAQJGW8IJWggMBKB9UEiCVUuoEw+Fm8DWS8nK6hdErw5ZA5Jxqd56ZPCAldd7Z2XcVhh+Cia4XAKASGvLyjOtiimyCfUPB07GMhWUNVnzlY8CsxFogzqGJAUhAfNRGRXJYJgdkgIMLqPxXovZP+gh4UAZrIoCCTTEEFtlJEmKOGsE4tkzgolEBZOW0yoryHKJ1CLpAMqy1CCk5tdXB80+8J0c9QaJii1Lpp/Pq9EEiOgAgrOaSX6qajP4XWFn6utkFanNblTkWKU58YA2W3gkaUavmln3e1WAABEVZekHFmo/HUVg5A+wlJlZxOeaSHWQV2qXnSN6eEMiGwKAREWPmnC9KirD3qFLGVIA1Weay02nYXd+Lnf3r1IAQSIiDCSgjmhqYgD+Rf2j4u/GChUEWO0cSrPJJ/iXZ/QI6O1KYQyI2ACCs3wvu2j/Y6sr1xqXXioEhpwWGe00KAa84+1LYQyIqACCsrvCsb58SRGoxxAVHkiyk5lqOAaZ2nVK9CIDECIqzEgA5ojuDOJ7fUMwl5eHDiUmYDhqRLhcC8ERBh1Z0fijs8ohUfRUQ61VxI75EJASEQISDCqv86kER8ZFNc9AWtoZzUFB59VP3haQRCYD4IiLDmMxfo2lM8NsgYMzIqXuOkV+mz+cyTRlIRARFWRfA7umaLSAVqZISDEfIAaZ01r6FqNEKgPAIirPKYb+qRPMMjPH0HdQYMvxYOetRDc8ZsbRqbfi8EqiIgwqoK/9rOyUlkVXVYdNU57pAndksmBHYOARHWvKf82u6Q5yQR3SwMfxZCgrmTp+eNjEa3kwiIsJYx7VSeoXYjVWgwSl6Rn0jxBpkQ2BkERFjLmWr0q86IJGtQIb1/oyV/5nIeQSMVAtMQEGFNw6/G3YjwUb4rGM74R9cYiPoUAqUREGGVRjxNf7/WqD68yLXgaRFRQPxcMiGw1QiIsJY7vTjkyT1Enhnje0T58G/JhMBWIiDCWva0ovn+vEiuBoma47zSzbKfTKMXAh0IiLCW/1pQDgypmmMapzzpPQSWoilPlWWZENgqBERY2zOdV29qDj7R47YuaLaKBJmiuyUTAluDgAhra6by0gchrecxLleDL+vDriVPZWaZEFg8AiKsxU9h5wMc7L4t9Nwv9O1izgo924minmp2CIiwZjclSQfElvDxXviVsAfKi8mEwGIREGEtdup6Dzyu1sMqi1PEd/W+WxcKgRkhIMKa0WRkHApbQ1Za/IvhnJdDPiPgajoPAiKsPLjOsVXIKhAX41N0/BxnSWNai4AIa/dekDt7Wg/J1HLI7978L/qJRViLnr7Rgz/UTxEPcV2t032bOLpB3SgESiAgwiqB8nz7OM3jtC4xs/NaBTDmO2qNbGcREGHt7NR/48FPdV0tfvB2l6pRzJbei1kiIMKa5bQUHxShD2d7r+83swOLj0AdCoEeCIiweoC0I5dwgvhmf1Y543dk0pf2mCKspc1Y3vHGKy16wjl/ft4u1boQ6I+ACKs/VrtyZXDEh+fVO7IrM7+A59TLuIBJqjDEd5oZIQ/BbtMEncoRX2Ei1OW+CIiw9EasQgAnPFvEYErn0btSHQERVvUpmPUATjazY6MRnmJmR816xBrcViMgwtrq6R39cNc0M75uYWbHm9kB3tLHzOwao1vVjUJgIgIirIkAbsHtB5nZ1Twx+nAz4/9XWfFcnBhycigTAlUQEGFVgb16p0jL3MpHESRnNg3qE57Gc+6mC/V7IZALARFWLmTn3S5FKq43YIgI/iH8p5PCAaDp0vQIiLDSY7qEFtcR1sVm9kUz45q3OkmJqJYwqzswRhHWDkxyxyMGrfdPmdkHzeyzETmxmuL/MiEwOwREWLObkqIDonL0RUV7VGdCYAICIqwJ4OlWISAEyiIgwiqLt3oTAkJgAgIirAng6VYhIATKIiDCKou3ehMCQmACAiKsCeDpViEgBMoiIMIqi7d6EwJCYAICIqwJ4OlWISAEyiIgwiqLt3oTAkJgAgIirAng6VYhIATKIvB1LhK50+04IvcAAAAASUVORK5CYII=\"]}','2025-05-16 12:32:45.800007',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL),
(136,'12',12,'Added U. Other',0,'{\"lastname\": [\"None\", \"Other\"], \"firstname\": [\"None\", \"Added\"], \"middleinitial\": [\"None\", \"U\"], \"is_superuser\": [\"None\", \"False\"], \"address\": [\"None\", \"SFC\"], \"usertype\": [\"None\", \"Personnel\"], \"username\": [\"None\", \"oadd\"], \"password\": [\"None\", \"pbkdf2_sha256$870000$QNqUTLEuxcO4BKcijYaWeM$fpFVJKUibQG2pcTivhp1RISA8SAyjxix6J2QHFwO5dA=\"], \"is_active\": [\"None\", \"True\"], \"is_staff\": [\"None\", \"False\"], \"id\": [\"None\", \"12\"]}','2025-05-16 12:36:22.104285',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(137,'12',12,'Added U. Oadd',1,'{\"lastname\": [\"Other\", \"Oadd\"]}','2025-05-16 12:44:40.436420',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(138,'12',12,'Added U. Oadd',1,'{\"is_active\": [\"True\", \"False\"]}','2025-05-16 12:44:58.569354',1,7,NULL,NULL,NULL,NULL,'',NULL,NULL),
(139,'7',7,'Loans object (7)',1,'{\"status\": [\"pending\", \"reject\"]}','2025-05-16 12:58:52.848799',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(140,'8',8,'Loans object (8)',0,'{\"member\": [\"None\", \"4\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"1223443.00\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"12\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2025-06-16\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"8\"]}','2025-05-16 13:08:02.134365',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(141,'8',8,'Loans object (8)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 13:16:05.577446',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(142,'9',9,'Loans object (9)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"329736.41\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"36\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-05-16\"], \"maturity_date\": [\"None\", \"2028-04-01\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"9\"]}','2025-05-16 13:17:32.881145',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(143,'9',9,'Loans object (9)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 13:17:36.873335',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(144,'10',10,'Loans object (10)',0,'{\"member\": [\"None\", \"1\"], \"loan_type\": [\"None\", \"quick\"], \"loan_amount\": [\"None\", \"329736.41\"], \"interest\": [\"None\", \"5.00\"], \"term\": [\"None\", \"36\"], \"grace\": [\"None\", \"1\"], \"payment_start_date\": [\"None\", \"2025-03-31\"], \"maturity_date\": [\"None\", \"2028-06-29\"], \"status\": [\"None\", \"pending\"], \"id\": [\"None\", \"10\"]}','2025-05-16 13:19:27.143077',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(145,'10',10,'Loans object (10)',1,'{\"status\": [\"pending\", \"released\"]}','2025-05-16 13:19:31.569072',1,8,NULL,NULL,NULL,NULL,'',NULL,NULL),
(146,'1',1,'Doe, Johnathan',1,'{\"member_signature\": [\"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAHr0lEQVR4Xu2cd6gkRRDG78z5zFlvDZgVFQUD6oHp8BRzQFEORcGcxYCYFVHwDzErHGcWTJj+EAWziDlnnwFzzlm/H/TgvvW9Zdndmu7proKPng3T0139TXdVdZg4wcU1YKCBiQZ5epaugQlOLCeBiQacWCZq9UydWM4BEw04sUzU6pk6sZwDJhpwYpmo1TN1YjkHTDTgxDJRq2fqxHIOmGjAiWWiVs/UieUcMNGAE8tErZ6pE8s5YKIBJ5aJWj1TJ5ZzwEQDTiwTtXqmTizngIkGnFgmavVMnVjOARMNOLFM1OqZOrGcAyYacGKZqNUzdWI5B0w04MQyUatn6sRyDphowIllolbP1InlHDDRgBPLRK2eqRMrLQ7Mq+IsIiwY0j+VLiMsLCwqzC/w3R/CVwFfKH1S+C6lqjix6muN2fSopYTJwhLCykIrpMsqnUv4Sfhc+FD4RoA0/4TrH8M15FteWC7ktYbSuYWThIvrq073JzmxBmuJ2XU7vQuEoUdZPKRLBvIsFhqd75GfhY+E90M6Ekj0ntJv+yzKHLrvVmF7YQvh4T7zGeptTqz/1AlBlhYWEhhy5mtLJ4XP9Bb8h3Qegd7kh0CKL5XSwwCuPxXofT4RfhH+HmrLjc6MHo9e7irhIMPn9Jx1CcSqehRsFRqAFPIw9DAk/SosIPweSMEQBBh6IAQpQ1T1/We6TsqeUXloR8pPXeglSaNKLsTCfmkJqwurCdgdpCsJGL4MNS8IrwuvCm8LbwrfC5Y9SZ2Ne58eNlXYWbijzgeP9aymEYshCKN31UAc0rUDgRiasFOeE54XXhReCYTibc5d9lcFrxHuFabFrmxsYjEcYbNg/DJMcY09g+fE8ISdw1CGYUzKbwi2S3vvwzVkwq4pVdAl9hwvH/qiN44mdRMLD+aYQJhdlNLjzNKl9hjH7wqPC8Rq8Hj4jHfl8n8NzNRX+wqbCE/EVFDdxMLtfkQgBkPspV0wiLF7sIdeFp4JwFh26U0Dx+pvFwq8tLf3dovNv+omVlWLWXWBbcRQh2tOF56ap2Wjcdtcd1T2GO57CzfaPqp77rGIFbPOYz0bF72KYeFFEo5gGP5L4DfsF3S1YkixCYl1zSnQ+xKO6BR6ZIbsj0M+xJmIeX0gMB1TxbuwhX4Ln8lnkFDBprr/UeFQ4dKYSi6NWDgIhCHWEwhF0GsSmsAxaBcaHgeB0MTXAvNzDMk0Op4nROB74lzM2yEQqNP7hKCVwwHRCIvQS+PBck1+lAPiMk2Dw8I184UQm2eSL9F6yvKSgJkwnlAXPOFThbO7/M/8p5yIRe+Bm72KQL0gA70NXhJe5oZCNbWCYiEFjURDPCvgWQJ6llSE8hLQhXyQBrQESP2WQEiFHmpEgOzUk+sLhBNiViIHYvGGHyCcLDCcdQoEIxTxmkBglLeeRun25sdsk16fvY7+uHEgGy/TPgJzl4RcnFi9arHL/27Tb0SbkQcEQhJvCAwjeJhM+JYiK6iihGNOE86MWekceiwMZEi0ZVBqTH3GfvZGKgDxK2JZ18UsTA7EYljD2EappcvuUsAtwloCtmM0yYFY2Ey48USbS5fTpYBDhHYnJYpOciDWiDTHzP7BUTSY1kOvVXGIwxU/CT2MZsFQZ47snGFk1vA83lH5rxTOj12PHHqsM6TEvQRiPETKSxU8QsIpWwsPxlZCDsSi6yeoyVBIz1WqHKeK85IR7Y++/iwHYkEkFHqgwDIcDPnShKVHROGfFqanUPlciMV0Du71/aHnSkG3dZZhNz3sZoFpK6anoksuxEKRbH0i8r6TcHd0zdZbACaoHwu9dr1PHudpORGLKjKVcaSwvjCShIbtC8HaK7Z9tQSW4iQhuRGL+tBbseyEtUm5e4nYVqzIIH51VhKMCoXIjVhUC68Ie4sdK6xLylkOU+VOEdi5NNZiw2h1z5FYKHNbgTXfWwlsxMhRWJxIQJQzGwiKJiW5Egslc0DGdgKrRaNuhTJqcdZc7SCwLit63KqzjjkTiwWAuN5PCdONGjdWthuEnhgPmA2qyUnOxELZ6wq44exlvCI57fdXoOqFYUXsrv1lYX9X7sRCg3sITPVsIyRxxM+AzXq17mdRIy9NslvmSiAW7Uh8i7k0zpB6aMCGjXk7a63OFTYTWIeWrJRCLBoAtxzgMbIbu2kyRQW+M5Sf4waSlpKIRUOwBf08gc0X9yTdMqMLh+cHmThR5qYmlLs0YtEmnGtwg3C0cFkDGomd1jgglwsMg42QEolFw2wucG4nqyE4WpFT+1IUdkZTRgKh7Btkd3QjpFRi0TjsGmZHC41HOIJ18ykJRwFAfrbYEwgd5EyH2utVMrFQNud1HS6wuZPlvEcIbHKNKexmPl7A0WBvIGVi+3yjpHRiVY3F+QiEJPYUiHkxed3v8dj9EoC2IOBJOTjO+yjh+n4zi32fE2t0C7DRkzlGljiz64doPWc/WArPYmpmPwGCsyoDz5VzwxorTqyxm47Thy8RmNwlsDqs0ASnOk8RWgKLEdcUOGuL02NmCBcJHFnUeHFijd+EnGdFSOJEgZWZBCfvEti0wJb+TuEcLIhCeAACcUgbCw2Z22NoY3saCxDZ7MHkOFu1OB6ADRCct9A4O6ob+/8Foh9CWwjDx7wAAAAASUVORK5CYII=\", \"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAAFHBJREFUeF7tnQnUfdUYxh8qkVIikgaKBo2UhGhQIolUIhQLSWIlmUrL3FpEpQGJaBXRIM2oKJEpolkIpYlERZQG+7e8R6fru9+dzrnn7Huevda3vv5f5+zhefd97t7v+CC5GQEjYAQyQeBBmczT0zQCRsAIyITlTWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQcCElY2oPFEjYARMWN4DRsAIZIOACSsbUXmiRsAImLC8B4yAEcgGARNWNqLyRI2AETBheQ8YASOQDQImrGxE5YkaASNgwvIeMAJGIBsETFjZiMoTNQJGwITlPWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQcCElY2oPFEjYARMWN4DRsAIZIOACSsbUXmiRsAImLC8B4yAEcgGARNWNqLyRI2AETBheQ8YASOQDQImrGxE5YkaASNgwvIeMAJGIBsETFjZiMoTNQJGwITlPWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQaDrhPUESb+XxG/ao+L3YvH73Gwk6YkagQ4g0CXCKshpY0lPkbSvpKUHyPhvki6RdKWkYyX9QdJDJV0h6b4O7A8v0Qi0CoGuENZWkk6tGPkbJC0g6XZJl0m6WtL1kjiVXWhCqxhtd2cEJHWFsA5PZLLLlCUOcV0r6ceSTgoym/IUPJwRmC0EukJYSO04SZeH+HaTtNQQovxzPMcp6jeS1pmA5H8V+rLzJR0t6ZohxvcjRsAIlBDoEmH1Ch5d1sqSriop3ReJExFK934K9/UkLZpIZyVJy4U+7DGSeOdpQ+6uf0mCwNCJ/Tx0ZN+UdOuQ7/sxI9BJBLpMWHUJ/KmSFi8R2TKSNpS02hAD3ivprvT+gZJOlnSnpIsl8Xc3I9B5BExY090CnMzWlsQpDaslv/nB8tivYaH8nSROYFgquaa6GYFOImDCal7syGDNOIWtIWn10JU9os/U0IGhT0OZ/1VfI5sXoGcwPQRMWNPDepSRFkxuGOtKWj65TGwvaYX4N24UvQ3y+lHSoX1S0i/tTjEKzH42NwRMWPlIbMkgrWdLerqkLeeYOtbMsyV9J0jsouQge08+S/RMjcD8CJiw8t4hWCqxTD5L0naSlu1ZDmFHOMziyHqGpJvzXq5n33UETFiztQPQf2GlfGMiqPXnUOb/SRI6MFwpjpf069lavlcz6wiYsGZbwmuFFfIVkjafY6mXSjpBEjGTX7EFcrY3wyyszoQ1C1Icbg1LhPWRU9iLJG0maaGeV0+RdFacwC4Yrls/ZQSmh4AJa3pYt20kZI/i/pmSNo3f5TnitHpkcl59r10n2ia67s7HhNVd2feu/JGSXho/xEziUlE09F4HRbjSLYbMCDSFgAmrKeTbPe7CKVD85aH32qRkfbwtQoY+Hil1nBOs3XKcudmZsGZOpLUs6FWSNpL04lLSw3MkHSPpvAgdqmVgd2oEygiYsLwfRkGAWEiSIe4Y5FW8e2LKXPEFSWeO0pmfNQKjImDCGhUxP18g8KQgrZ0joJu/E6QNeXHqOs1QGYGqETBhVY1oN/vbIPly7ZHcIbaW9LCAAPL6WGSZIO+XmxGYGAET1sQQuoMeBNB14QqxRenvX0uZWw8LL3sDZgTGRsCENTZ0fnEAAquk7BHbSHqnJAK3ab+NkKAPS7rDCBqBUREwYY2KmJ8fBwGsiztFgDbv3xSnrS+lzBOnj9Oh3+kmAiasbsq9qVWTWeJlkt4WOfCZB3m8Ph1l0pqal8fNBAETViaCmsFp7pkK0u4QWSVY3o0p/c3uYWWcweV6SVUgYMKqAkX3MQkCL5G0V6SILvohuwSKejcj8AAETFjeEG1B4CmpYtDeKUcXXvU0Ut58JK6MbZmj59EwAiashgXg4f8PAWo84haxayQgJEvqZyXtJ+mfxqvbCJiwui3/Nq/+8XHa2kcSFYQob3aEpENC39XmuXtuNSFgwqoJWHdbKQJcE3eL3PV0fGh40f+x0lHcWesRMGG1XkSeYAkBsqS+LzJH8OcPRZVs9F1uHUDAhNUBIc/gEleO2EVydkFWJ6ecXZ9PbhJXzOBavaQSAiYsb4ecEUBBT5ZUqgStF35ceM5T3sxtBhEwYc2gUDu6pNUkHZV+nphCgKgGxInryx3FYmaXbcKaWdF2dmFrSHqrpDeENRE91+GdRWPGFm7CmjGBejn/Q4CiGvumij9vTxZGCsiSDfWjLh6b9w4xYeUtP89+MALLRbD1myLg+ruR8uZng1/1E21DwITVNol4PnUhAHERo0h+rqUk/VjStklhf11dA7rf6hEwYVWPqXtsNwJYFl8TPlyLRD6u1yYLIyFAbi1HwITVcgF5erUhsETKhHpwkBeDnCHp1ZL+WtuI7nhiBExYE0PoDjJH4HmS9k/Op09NSvp7wnOeQrHELrq1DAETVssE4uk0gsACUfGHQOt1JX0vhf+gnP9AI7PxoH0RMGF5cxiB+xEgKwSxiijmr08FY68KZ1Ryz7u1AAETVguE4Cm0DgGSCVKWDGvi6pLOlfQ5Sce2bqYdm5AJq2MC93JHQmBjSe9PhMVvGictwn8gMLcGEDBhNQC6h8wOAQjrE6HfIrAa0rJ+qwExmrAaAN1DZonAk8LtgRMX7YMmrenL0YQ1fcw9Yt4IcLLaOV0PnxBXw09J+kbeS8pn9ias6cuKjX63JIqK3lbSjxCgixc2ehLnc5q+XEYd8cK4IqLPOs+nrVHhG+95E9b9uK0oiUyWxJZtIWnhFN2/UGzK2yXdmzyjl4wQjoemkI6nx7csPRQE85eSnqPoGYIi7IMcTVwrlh1CVEV//ObDcJyky4d4z49MFwEsieSap5oPsYmbTHf47o3WJcKCjIgdQ4H6aEmbh7ghnklxgFgeIumGIKw6dtJlkVHTFqo60B2vT/bSdskr/i3xOhkgyArhTBDj4TnwrUk/qAMHmOIDrGWtVDGYzJPLx2nomZKeLemayEQ5ynS4tnHs/1dKw/uL+O/7JP1SEuTByWmuq1thAi/G4t+/TpkCrkxl2NcM0iRujXchziLolpMXJ7A9Ip6N9xijt31L0o9SP4SP3DHKgvxsbQgQPP3FUu/4bEFcbhUjkCNh8SEnq2SZGFZIBMCmGbXhyUypqItSufS/ByndmsI0fp68nf8xamc1PM8a+dmoZ73FUAdIekcN47rL0RHA2fTIlCjwGaVXd7Sz6ehAzvdGDoT1WEmrJlJ5SWyGZ40IwSUpgdstcUxHF8XphIh8dA45tS1TRoH1o+DCMqWJ/zQyDdgvqB3SRA6F6wMzorLP8e2YWv6zaBthcWXaNCmZ+bZCCc7vu/pcjUD/pijtRGQ9H2I2BqlxfxdKaj7Ms9a4JnKaLH8oWKP9gtojaQKo351UB9vHlCybimTTJGFhgSOR2sMiXmsXSUTN9zaCUCEtyOfrkrDQcWqyYvO/1sPiQwFuKOTfG6fIiraIuxkTASzKJ5au8twSfjVmX34tEJg2YS0aFU22CbeA+QSBcvkHcWpCYe02NwK9VxCeAq/vBIH5OtLcziHHFvpQGnLgeug2AQLTIqyt0xz5YCHAfg0L3AkhWJTgv5lgXV179ZhkiXzVPIvGIonLBVZPTql80/Nvt/oROFsSSQJp0/q81b+qhkaoE0AKWmLa5S7fr10r6YIIJj0nrn4NQZH9sIfG1brXraLfwrhSc70uMmtyNUcGZ0VaFXSBtELBT64o5MWXCXo0/M42i2d5jr+jO+S6Xnb56LrfWNnlgUIYWKXdxkSgasLiA7BTBIk+p8+ccCXAHM8RGeudW7UIQFjotXCFIJdTWxohR/iNQZBd8txHFqyXtp51r5Ntx6oICy/yXaNo5VwzwjnyiLjyFXf6yWbut4dBACsrehMMFyjjMXRwMiIxXdONayqGFE56uJvMahwlX84Uc6WtLenipoHPefxJCYuj/+59nBfRSZ0WREV+bBwz3ZpHgKvegmG94r9fGVNCllSSwasfQnt4MpAUsZHFrPk3Vz4iCfD2Rw/GlxWN9yFEvPoXmyBE6Yfhd8fciusk5PaHODUW8ZWMiXMvJ7a/xbybR/eBM+C0y+kKPMEVH0LiDt3GRGASwuKoiy9Q77UDYkJ5ju+Jsw6MKZgZeK3QpRW/+dBClLivcKrCV6nKxl4rCIx+CRonJItQqiZcYF4YDr3FGu2LVYG0xyWsuUzpTOeTkfsaPZWbEZgPgSKOsoiZ5Pf30/WJ0ChiQLEoF2RXBcEdHWW8iOOkcTKryyDA5+ONJYOFXRoq+iyMQ1hvTYLft0cPwvXg9RmGu1QEo7uZIgJFQDgnKggNK1xBdIQvjRJTWvWphwD2d4WvYQEJnw1iX90qQGAUwmIzYMYuFIjF8HxLIfi6vq0qWKa76CACkBmuGEuX9HS9ujVuBHtVhM1WYSEvRx7QtV0ZKgKYboYlLI64CBZFbLk5sLNCYbirqSFQZMGYNGCcfjA6ELnxgp7Zk7CR2Fi3ChEYRFh8a1AtZJU5xoSsvhkm6Qqn5K6MQCsRwMfwFWFk4uSG0aCf4YB8WPs7WqN6OQ4iLEI4CrN1Mfr5kg5xyozqheEeW4cAV8j3RFof1CGDGvqqg8PwNOhZ//8xEJiPsE6XhN6qaPiR4Pz5lfB7GWM4v2IEWo0AGV9flgLHn5tuDxukL+ZHDTFbnHLJr0Y8J7nWrMsdArRxH+lHWJyq+LbAb4ZWtTVl3Pn6PSNQJQJ415PTf9tIEElKmPkaX9r4duEI/e3wzjdBVSmRAX31Iyz0VuXUuyslC8jVU5yXhzICdSFAzn+cV9HBljO39huPbAvUHYSY+BJ3axCBuQiL+LOyYA5M9fP2bHCOHtoITIJAUSkJHRSWPAhrvkbGiTMjawVqkX9PMrjfrRaBuQir7MVO3nPu8m5GICcEUJaTzRarXr+sIcV6uOJxguK6d2qpilFO6+3MXOciLO7nRUiE/aw6sxWyXiiFSijxRnAxwfjoXgnk7m1YvVGSc73D2o2ag6Bqt0wQ6CUsAlQpmU4j1opy6k44lokwOzZNgoux5r1Z0uI9ayerBHubGESyrP4kLHg3dgyjmVtuL2GVsyO6GOTMiTvbBaGH4npHUkIK42IE6m2/lURqGmoDQlS3ZbtaT7wvAr2EVdZf2ZXBG6dJBNBDUQtgnz6Kcq52nJw+E8VK2lD4tkm8OjF2L2GVy0a9LiVlI62tmxGYFgLbSaJaMiepXp8okvSRcx79E8px656mJZUWjdNLWIclHdZuMT8r3FskqBmcCoHBpGum2g+qiKLoRXmpGIBOjhMUuii3jiMw35Vwc0k4zbkZgSoQIHiY09OLIkHf4+bolHznZKvFD8oEVQXqM9bHfFdCJ8yfMWE3sBycNanJx5ffXJkNKJZL/B3pjDlNuRmBeRGY74S1iQM5vXtGQIAICTJrctXDj2/Dnnex2qGDwnucIrmQlJsRGAmBuRxHCU0gDS2mYZL2ObhzJEg78/CTIxUw1ZF2SNY6nDeLhosBJbw4PZG+uIkiEJ0RRJcWOhdh8e24X+gZwIJEZCjjbZXp0s544FopAMoPYS4rpkrdVPWGoHAqxmOcNCx8sRHKhauBS7p1d6/UuvJ+2RpwzMMPCwvOvZIeHNlFKT5hZWitImm0cyIdNg3Pca5466c4u3UkUcaeenqEspwS1zoiIqhB6GYEpobAoIyjbFoyLhJIWjSKo5LkzFHsUxNTLQNhpeO0RJLGVSVxxSvnIL8ornTE31Gt+woHBtciB3c6AgKDCKvoCgXq3unIT/wWDa9iSp8T5X7tCOP50WYQQBkOKZGYEYLCArxoaSqcliAkiAmdE+4sDm1pRlYedR4EhiWsMnEdEFka+RupOY5NOo2jYsMb7OYQQK+0cLK+Yd2lSCmkBFGtIAkfqKJBRGTLJOcZynAU5Jc3N22PbASGR2BUwip6RgGLYh59xwLxx5tCp0GV26+Wsj4MPxs/OQgBiAiZofBGAc7J9574DWGVGwpxyAid43UpBTBXPMq2k3/czQhkicC4hFUslg8Q+ixCKygvXm5XppxEB0VYBd/mmL/dBiOAxQ1DB7F0lGuHkCi39vxQfheFEbDE4YLCdQ73gbviOsdpyWlUBuPsJzJEYFLCKi+Z3ER8sPBu5oNWbvjknJWIjfLiVN7pekOfROwcVzZ0SXiBc1Ll5ApRkYCO2ndkwcTREusdGEJGtyT94Z1BVl3H0evvGAJVElYZOpL7U42EKwvB1OQzujXM5Sjs8dXBZwffHYiME0WuDfIBR1w/Fop1UyGbNXHqZO13BymRMqU3CwFpUnAP4MTESemkyIrJSQqPcDcjYAQCgboIqxdgKkdjRseva+f4YJef+UFcbVACc6q4JBT60xJUUZiAk8vyUb6JFLuk3eVUiHsHCm1M/5x88EviRAT58N/ztSIE5aogojuCsG+QhMuAmxEwAkMiMC3CKk+HMbn64FFPYCxWLdKM9DasWZxM+OGkwQeekwu6GnQ3y4aVCwIo9GOQCtcpfopTD8TCD6cbnCB5lj6LWDfGLpv4i3lwEiTVLlcy/JNw32AsTkKcpria0TA24BJQNPzTIGA3I2AEKkagCcKaawmcVDDDo8vhJFZE9mP54sTT2yCIQeWa5oOKUxxX1JslXRpEhEWNPPYYCyA1rnQQlpsRMAItQaAthDUqHPgVETbCSWfYhnnfMW7DouXnjEALEciVsFoIpadkBIxA3QiYsOpG2P0bASNQGQImrMqgdEdGwAjUjYAJq26E3b8RMAKVIWDCqgxKd2QEjEDdCJiw6kbY/RsBI1AZAiasyqB0R0bACNSNgAmrboTdvxEwApUhYMKqDEp3ZASMQN0ImLDqRtj9GwEjUBkC/wF42tO1gdnfhwAAAABJRU5ErkJggg==\"]}','2025-05-16 14:40:37.518536',1,10,NULL,NULL,NULL,NULL,'',NULL,NULL);
/*!40000 ALTER TABLE `auditlog_logentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add content type',4,'add_contenttype'),
(14,'Can change content type',4,'change_contenttype'),
(15,'Can delete content type',4,'delete_contenttype'),
(16,'Can view content type',4,'view_contenttype'),
(17,'Can add session',5,'add_session'),
(18,'Can change session',5,'change_session'),
(19,'Can delete session',5,'delete_session'),
(20,'Can view session',5,'view_session'),
(21,'Can add log entry',6,'add_logentry'),
(22,'Can change log entry',6,'change_logentry'),
(23,'Can delete log entry',6,'delete_logentry'),
(24,'Can view log entry',6,'view_logentry'),
(25,'Can add user',7,'add_user'),
(26,'Can change user',7,'change_user'),
(27,'Can delete user',7,'delete_user'),
(28,'Can view user',7,'view_user'),
(29,'Can add loans',8,'add_loans'),
(30,'Can change loans',8,'change_loans'),
(31,'Can delete loans',8,'delete_loans'),
(32,'Can view loans',8,'view_loans'),
(33,'Can add amortization',9,'add_amortization'),
(34,'Can change amortization',9,'change_amortization'),
(35,'Can delete amortization',9,'delete_amortization'),
(36,'Can view amortization',9,'view_amortization'),
(37,'Can add member',10,'add_member'),
(38,'Can change member',10,'change_member'),
(39,'Can delete member',10,'delete_member'),
(40,'Can view member',10,'view_member'),
(41,'Can add backup log',11,'add_backuplog'),
(42,'Can change backup log',11,'change_backuplog'),
(43,'Can delete backup log',11,'delete_backuplog'),
(44,'Can view backup log',11,'view_backuplog');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_tblUser_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES
(1,'2025-05-12 22:42:53.228817','2','John . Doe',1,'[{\"added\": {}}]',7,1),
(2,'2025-05-12 22:43:09.516543','2','John O. Doe',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(3,'2025-05-12 23:29:07.248768','4','JWTLog . JWTLog',1,'[{\"added\": {}}]',7,1),
(4,'2025-05-12 23:29:14.915766','4','JWTLog J. JWTLog',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(5,'2025-05-12 23:34:13.061070','1','Michael O. Padua',2,'[{\"changed\": {\"fields\": [\"Middleinitial\", \"Address\"]}}]',7,1),
(6,'2025-05-15 13:36:36.713820','2','Johnathan O. Doe',2,'[{\"changed\": {\"fields\": [\"Firstname\"]}}]',7,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES
(1,'admin','logentry'),
(9,'api','amortization'),
(11,'api','backuplog'),
(8,'api','loans'),
(10,'api','member'),
(7,'api','user'),
(6,'auditlog','logentry'),
(3,'auth','group'),
(2,'auth','permission'),
(4,'contenttypes','contenttype'),
(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES
(1,'contenttypes','0001_initial','2025-05-12 22:38:58.849213'),
(2,'contenttypes','0002_remove_content_type_name','2025-05-12 22:39:00.006073'),
(3,'auth','0001_initial','2025-05-12 22:39:03.345559'),
(4,'auth','0002_alter_permission_name_max_length','2025-05-12 22:39:03.914384'),
(5,'auth','0003_alter_user_email_max_length','2025-05-12 22:39:03.960370'),
(6,'auth','0004_alter_user_username_opts','2025-05-12 22:39:03.983444'),
(7,'auth','0005_alter_user_last_login_null','2025-05-12 22:39:04.021373'),
(8,'auth','0006_require_contenttypes_0002','2025-05-12 22:39:04.037021'),
(9,'auth','0007_alter_validators_add_error_messages','2025-05-12 22:39:04.073182'),
(10,'auth','0008_alter_user_username_max_length','2025-05-12 22:39:04.100447'),
(11,'auth','0009_alter_user_last_name_max_length','2025-05-12 22:39:04.117752'),
(12,'auth','0010_alter_group_name_max_length','2025-05-12 22:39:04.785661'),
(13,'auth','0011_update_proxy_permissions','2025-05-12 22:39:04.815744'),
(14,'auth','0012_alter_user_first_name_max_length','2025-05-12 22:39:04.849683'),
(15,'api','0001_initial','2025-05-12 22:39:09.413294'),
(16,'admin','0001_initial','2025-05-12 22:39:11.202804'),
(17,'admin','0002_logentry_remove_auto_add','2025-05-12 22:39:11.235602'),
(18,'admin','0003_logentry_add_action_flag_choices','2025-05-12 22:39:11.262914'),
(19,'auditlog','0001_initial','2025-05-12 22:39:13.124960'),
(20,'auditlog','0002_auto_support_long_primary_keys','2025-05-12 22:39:17.237237'),
(21,'auditlog','0003_logentry_remote_addr','2025-05-12 22:39:17.675895'),
(22,'auditlog','0004_logentry_detailed_object_repr','2025-05-12 22:39:18.276190'),
(23,'auditlog','0005_logentry_additional_data_verbose_name','2025-05-12 22:39:18.328474'),
(24,'auditlog','0006_object_pk_index','2025-05-12 22:39:19.899650'),
(25,'auditlog','0007_object_pk_type','2025-05-12 22:39:19.952982'),
(26,'auditlog','0008_action_index','2025-05-12 22:39:20.518539'),
(27,'auditlog','0009_alter_logentry_additional_data','2025-05-12 22:39:20.541727'),
(28,'auditlog','0010_alter_logentry_timestamp','2025-05-12 22:39:21.295629'),
(29,'auditlog','0011_logentry_serialized_data','2025-05-12 22:39:21.735008'),
(30,'auditlog','0012_add_logentry_action_access','2025-05-12 22:39:21.785807'),
(31,'auditlog','0013_alter_logentry_timestamp','2025-05-12 22:39:21.807031'),
(32,'auditlog','0014_logentry_cid','2025-05-12 22:39:22.675752'),
(33,'auditlog','0015_alter_logentry_changes','2025-05-12 22:39:24.554735'),
(34,'auditlog','0016_logentry_remote_port','2025-05-12 22:39:24.961486'),
(35,'auditlog','0017_add_actor_email','2025-05-12 22:39:25.379702'),
(36,'sessions','0001_initial','2025-05-12 22:39:26.102457'),
(37,'api','0002_loans_member_amortization_loans_member','2025-05-12 23:14:58.748573'),
(38,'api','0003_backuplog','2025-05-16 06:16:47.726098'),
(39,'api','0004_restorelog','2025-05-16 10:48:36.931786');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES
('7unvm665gmmbsyp0uz3nzn12ejpgh2vz','.eJxVjEEOwiAQRe_C2hCmpQVcuvcMZAZmpGpoUtqV8e7apAvd_vfef6mI21ri1niJU1ZnBer0uxGmB9cd5DvW26zTXNdlIr0r-qBNX-fMz8vh_h0UbOVbsxfTCXQkbgQ2hqzn5Nmb5G2gzvUjCbkw9CABENgC2mF01qBwEhD1_gDjKzgD:1uEbpO:6SzUrbtqbU_gRybT2uUSgfb1fFtXH6y9UVZPnbUuyPw','2025-05-26 22:40:54.135868'),
('xp3s50yoe34zykg7u3774eslckyza7mh','.eJxVjEEOwiAQRe_C2hCmpQVcuvcMZAZmpGpoUtqV8e7apAvd_vfef6mI21ri1niJU1ZnBer0uxGmB9cd5DvW26zTXNdlIr0r-qBNX-fMz8vh_h0UbOVbsxfTCXQkbgQ2hqzn5Nmb5G2gzvUjCbkw9CABENgC2mF01qBwEhD1_gDjKzgD:1uFA7r:tvaLWhtG1AOoG6wwIbgDT-M5rO6tWNDUP5o34-inMDE','2025-05-28 11:18:15.261041');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblamortization`
--

DROP TABLE IF EXISTS `tblamortization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblamortization` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `seq` int(10) unsigned NOT NULL CHECK (`seq` >= 0),
  `due_date` date NOT NULL,
  `amortization` decimal(12,2) NOT NULL,
  `principal` decimal(12,2) NOT NULL,
  `interest` decimal(12,2) NOT NULL,
  `remaining_balance` decimal(12,2) NOT NULL,
  `loan_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tblAmortization_loan_id_17751303_fk_tblLoans_id` (`loan_id`),
  CONSTRAINT `tblAmortization_loan_id_17751303_fk_tblLoans_id` FOREIGN KEY (`loan_id`) REFERENCES `tblloans` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=151 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblamortization`
--

LOCK TABLES `tblamortization` WRITE;
/*!40000 ALTER TABLE `tblamortization` DISABLE KEYS */;
INSERT INTO `tblamortization` VALUES
(1,1,'2025-05-16',4000.00,1916.67,2083.33,498083.33,1),
(2,2,'2025-06-15',4000.00,1924.65,2075.35,496158.68,1),
(3,3,'2025-07-15',4000.00,1932.67,2067.33,494226.01,1),
(4,4,'2025-08-14',4000.00,1940.72,2059.28,492285.29,1),
(5,5,'2025-09-13',4000.00,1948.81,2051.19,490336.48,1),
(6,6,'2025-10-13',4000.00,1956.93,2043.07,488379.55,1),
(7,7,'2025-11-12',4000.00,1965.09,2034.91,486414.46,1),
(8,8,'2025-12-12',4000.00,1973.27,2026.73,484441.19,1),
(9,9,'2026-01-11',4000.00,1981.50,2018.50,482459.69,1),
(10,10,'2026-02-10',4000.00,1989.75,2010.25,480469.94,1),
(11,11,'2026-03-12',4000.00,1998.04,2001.96,478471.90,1),
(12,12,'2026-04-11',4000.00,2006.37,1993.63,476465.53,1),
(13,1,'2025-05-16',4000.00,3791.67,208.33,46208.33,2),
(14,2,'2025-06-15',4000.00,3807.47,192.53,42400.86,2),
(15,3,'2025-07-15',4000.00,3823.33,176.67,38577.53,2),
(16,4,'2025-08-14',4000.00,3839.26,160.74,34738.27,2),
(17,5,'2025-09-13',4000.00,3855.26,144.74,30883.01,2),
(18,6,'2025-10-13',4000.00,3871.32,128.68,27011.69,2),
(19,7,'2025-11-12',4000.00,3887.45,112.55,23124.24,2),
(20,8,'2025-12-12',4000.00,3903.65,96.35,19220.59,2),
(21,9,'2026-01-11',4000.00,3919.91,80.09,15300.68,2),
(22,10,'2026-02-10',4000.00,3936.25,63.75,11364.43,2),
(23,11,'2026-03-12',4000.00,3952.65,47.35,7411.78,2),
(24,12,'2026-04-11',4000.00,3969.12,30.88,3442.66,2),
(25,1,'2025-05-16',10242.32,8992.32,1250.00,291007.68,3),
(26,2,'2025-06-15',10242.32,9029.79,1212.53,281977.89,3),
(27,3,'2025-07-15',10242.32,9067.41,1174.91,272910.48,3),
(28,4,'2025-08-14',10242.32,9105.19,1137.13,263805.29,3),
(29,5,'2025-09-13',10242.32,9143.13,1099.19,254662.16,3),
(30,6,'2025-10-13',10242.32,9181.23,1061.09,245480.93,3),
(31,7,'2025-11-12',10242.32,9219.48,1022.84,236261.45,3),
(32,8,'2025-12-12',10242.32,9257.90,984.42,227003.55,3),
(33,9,'2026-01-11',10242.32,9296.47,945.85,217707.08,3),
(34,10,'2026-02-10',10242.32,9335.21,907.11,208371.87,3),
(35,11,'2026-03-12',10242.32,9374.10,868.22,198997.77,3),
(36,12,'2026-04-11',10242.32,9413.16,829.16,189584.61,3),
(37,13,'2026-05-11',10242.32,9452.38,789.94,180132.23,3),
(38,14,'2026-06-10',10242.32,9491.77,750.55,170640.46,3),
(39,15,'2026-07-10',10242.32,9531.32,711.00,161109.14,3),
(40,16,'2026-08-09',10242.32,9571.03,671.29,151538.11,3),
(41,17,'2026-09-08',10242.32,9610.91,631.41,141927.20,3),
(42,18,'2026-10-08',10242.32,9650.96,591.36,132276.24,3),
(43,19,'2026-11-07',10242.32,9691.17,551.15,122585.07,3),
(44,20,'2026-12-07',10242.32,9731.55,510.77,112853.52,3),
(45,21,'2027-01-06',10242.32,9772.10,470.22,103081.42,3),
(46,22,'2027-02-05',10242.32,9812.81,429.51,93268.61,3),
(47,23,'2027-03-07',10242.32,9853.70,388.62,83414.91,3),
(48,24,'2027-04-06',10242.32,9894.76,347.56,73520.15,3),
(49,25,'2027-05-06',10242.32,9935.99,306.33,63584.16,3),
(50,26,'2027-06-05',10242.32,9977.39,264.93,53606.77,3),
(51,27,'2027-07-05',10242.32,10018.96,223.36,43587.81,3),
(52,28,'2027-08-04',10242.32,10060.70,181.62,33527.11,3),
(53,29,'2027-09-03',10242.32,10102.62,139.70,23424.49,3),
(54,30,'2027-10-03',10242.32,10144.72,97.60,13279.77,3),
(55,31,'2027-11-02',10242.32,10186.99,55.33,3092.78,3),
(56,32,'2027-12-02',3105.67,3092.78,12.89,0.00,3),
(57,1,'2025-05-16',40000.00,23333.33,16666.67,3976666.67,4),
(58,2,'2025-06-15',40000.00,23430.56,16569.44,3953236.11,4),
(59,3,'2025-07-15',40000.00,23528.18,16471.82,3929707.93,4),
(60,4,'2025-08-14',40000.00,23626.22,16373.78,3906081.71,4),
(61,5,'2025-09-13',40000.00,23724.66,16275.34,3882357.05,4),
(62,6,'2025-10-13',40000.00,23823.51,16176.49,3858533.54,4),
(63,7,'2025-11-12',40000.00,23922.78,16077.22,3834610.76,4),
(64,8,'2025-12-12',40000.00,24022.46,15977.54,3810588.30,4),
(65,9,'2026-01-11',40000.00,24122.55,15877.45,3786465.75,4),
(66,10,'2026-02-10',40000.00,24223.06,15776.94,3762242.69,4),
(67,11,'2026-03-12',40000.00,24323.99,15676.01,3737918.70,4),
(68,12,'2026-04-11',40000.00,24425.34,15574.66,3713493.36,4),
(69,1,'2025-05-16',3000.00,-2097.68,5097.68,1225540.68,8),
(70,2,'2025-06-15',3000.00,-2106.42,5106.42,1227647.10,8),
(71,3,'2025-07-15',3000.00,-2115.20,5115.20,1229762.30,8),
(72,4,'2025-08-14',3000.00,-2124.01,5124.01,1231886.31,8),
(73,5,'2025-09-13',3000.00,-2132.86,5132.86,1234019.17,8),
(74,6,'2025-10-13',3000.00,-2141.75,5141.75,1236160.92,8),
(75,7,'2025-11-12',3000.00,-2150.67,5150.67,1238311.59,8),
(76,8,'2025-12-12',3000.00,-2159.63,5159.63,1240471.22,8),
(77,9,'2026-01-11',3000.00,-2168.63,5168.63,1242639.85,8),
(78,10,'2026-02-10',3000.00,-2177.67,5177.67,1244817.52,8),
(79,11,'2026-03-12',3000.00,-2186.74,5186.74,1247004.26,8),
(80,12,'2026-04-11',3000.00,-2195.85,5195.85,1249200.11,8),
(81,1,'2025-05-16',10242.32,8868.42,1373.90,320867.99,9),
(82,2,'2025-06-15',10242.32,8905.37,1336.95,311962.62,9),
(83,3,'2025-07-15',10242.32,8942.48,1299.84,303020.14,9),
(84,4,'2025-08-14',10242.32,8979.74,1262.58,294040.40,9),
(85,5,'2025-09-13',10242.32,9017.15,1225.17,285023.25,9),
(86,6,'2025-10-13',10242.32,9054.72,1187.60,275968.53,9),
(87,7,'2025-11-12',10242.32,9092.45,1149.87,266876.08,9),
(88,8,'2025-12-12',10242.32,9130.34,1111.98,257745.74,9),
(89,9,'2026-01-11',10242.32,9168.38,1073.94,248577.36,9),
(90,10,'2026-02-10',10242.32,9206.58,1035.74,239370.78,9),
(91,11,'2026-03-12',10242.32,9244.94,997.38,230125.84,9),
(92,12,'2026-04-11',10242.32,9283.46,958.86,220842.38,9),
(93,13,'2026-05-11',10242.32,9322.14,920.18,211520.24,9),
(94,14,'2026-06-10',10242.32,9360.99,881.33,202159.25,9),
(95,15,'2026-07-10',10242.32,9399.99,842.33,192759.26,9),
(96,16,'2026-08-09',10242.32,9439.16,803.16,183320.10,9),
(97,17,'2026-09-08',10242.32,9478.49,763.83,173841.61,9),
(98,18,'2026-10-08',10242.32,9517.98,724.34,164323.63,9),
(99,19,'2026-11-07',10242.32,9557.64,684.68,154765.99,9),
(100,20,'2026-12-07',10242.32,9597.46,644.86,145168.53,9),
(101,21,'2027-01-06',10242.32,9637.45,604.87,135531.08,9),
(102,22,'2027-02-05',10242.32,9677.61,564.71,125853.47,9),
(103,23,'2027-03-07',10242.32,9717.93,524.39,116135.54,9),
(104,24,'2027-04-06',10242.32,9758.42,483.90,106377.12,9),
(105,25,'2027-05-06',10242.32,9799.08,443.24,96578.04,9),
(106,26,'2027-06-05',10242.32,9839.91,402.41,86738.13,9),
(107,27,'2027-07-05',10242.32,9880.91,361.41,76857.22,9),
(108,28,'2027-08-04',10242.32,9922.08,320.24,66935.14,9),
(109,29,'2027-09-03',10242.32,9963.42,278.90,56971.72,9),
(110,30,'2027-10-03',10242.32,10004.94,237.38,46966.78,9),
(111,31,'2027-11-02',10242.32,10046.63,195.69,36920.15,9),
(112,32,'2027-12-02',10242.32,10088.49,153.83,26831.66,9),
(113,33,'2028-01-01',10242.32,10130.52,111.80,16701.14,9),
(114,34,'2028-01-31',10242.32,10172.73,69.59,6528.41,9),
(115,35,'2028-03-01',6555.61,6528.41,27.20,0.00,9),
(116,1,'2025-03-31',10242.32,8868.42,1373.90,320867.99,10),
(117,2,'2025-04-30',10242.32,8905.37,1336.95,311962.62,10),
(118,3,'2025-05-30',10242.32,8942.48,1299.84,303020.14,10),
(119,4,'2025-06-29',10242.32,8979.74,1262.58,294040.40,10),
(120,5,'2025-07-29',10242.32,9017.15,1225.17,285023.25,10),
(121,6,'2025-08-28',10242.32,9054.72,1187.60,275968.53,10),
(122,7,'2025-09-27',10242.32,9092.45,1149.87,266876.08,10),
(123,8,'2025-10-27',10242.32,9130.34,1111.98,257745.74,10),
(124,9,'2025-11-26',10242.32,9168.38,1073.94,248577.36,10),
(125,10,'2025-12-26',10242.32,9206.58,1035.74,239370.78,10),
(126,11,'2026-01-25',10242.32,9244.94,997.38,230125.84,10),
(127,12,'2026-02-24',10242.32,9283.46,958.86,220842.38,10),
(128,13,'2026-03-26',10242.32,9322.14,920.18,211520.24,10),
(129,14,'2026-04-25',10242.32,9360.99,881.33,202159.25,10),
(130,15,'2026-05-25',10242.32,9399.99,842.33,192759.26,10),
(131,16,'2026-06-24',10242.32,9439.16,803.16,183320.10,10),
(132,17,'2026-07-24',10242.32,9478.49,763.83,173841.61,10),
(133,18,'2026-08-23',10242.32,9517.98,724.34,164323.63,10),
(134,19,'2026-09-22',10242.32,9557.64,684.68,154765.99,10),
(135,20,'2026-10-22',10242.32,9597.46,644.86,145168.53,10),
(136,21,'2026-11-21',10242.32,9637.45,604.87,135531.08,10),
(137,22,'2026-12-21',10242.32,9677.61,564.71,125853.47,10),
(138,23,'2027-01-20',10242.32,9717.93,524.39,116135.54,10),
(139,24,'2027-02-19',10242.32,9758.42,483.90,106377.12,10),
(140,25,'2027-03-21',10242.32,9799.08,443.24,96578.04,10),
(141,26,'2027-04-20',10242.32,9839.91,402.41,86738.13,10),
(142,27,'2027-05-20',10242.32,9880.91,361.41,76857.22,10),
(143,28,'2027-06-19',10242.32,9922.08,320.24,66935.14,10),
(144,29,'2027-07-19',10242.32,9963.42,278.90,56971.72,10),
(145,30,'2027-08-18',10242.32,10004.94,237.38,46966.78,10),
(146,31,'2027-09-17',10242.32,10046.63,195.69,36920.15,10),
(147,32,'2027-10-17',10242.32,10088.49,153.83,26831.66,10),
(148,33,'2027-11-16',10242.32,10130.52,111.80,16701.14,10),
(149,34,'2027-12-16',10242.32,10172.73,69.59,6528.41,10),
(150,35,'2028-01-15',6555.61,6528.41,27.20,0.00,10);
/*!40000 ALTER TABLE `tblamortization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblloans`
--

DROP TABLE IF EXISTS `tblloans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblloans` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `loan_type` varchar(20) NOT NULL,
  `loan_amount` decimal(10,2) NOT NULL,
  `interest` decimal(5,2) NOT NULL,
  `term` int(11) NOT NULL,
  `grace` int(11) NOT NULL,
  `payment_start_date` date NOT NULL,
  `maturity_date` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tblLoans_member_id_2c49732e_fk_tblMember_id` (`member_id`),
  CONSTRAINT `tblLoans_member_id_2c49732e_fk_tblMember_id` FOREIGN KEY (`member_id`) REFERENCES `tblmember` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblloans`
--

LOCK TABLES `tblloans` WRITE;
/*!40000 ALTER TABLE `tblloans` DISABLE KEYS */;
INSERT INTO `tblloans` VALUES
(1,'quick',500000.00,5.00,12,1,'2025-05-16','2025-07-16','released',1),
(2,'quick',50000.00,5.00,12,1,'2025-05-16','2025-06-16','released',3),
(3,'quick',300000.00,5.00,36,1,'2025-05-16','2028-04-01','released',1),
(4,'quick',4000000.00,5.00,12,1,'2025-05-16','2025-06-16','released',1),
(5,'quick',23234343.00,5.00,12,1,'2025-05-16','2025-06-16','released',1),
(6,'quick',1232243.00,5.00,12,1,'2025-05-16','2025-05-16','reject',1),
(7,'emergency',4454687.00,15.00,1,1,'2025-05-16','2025-05-16','reject',1),
(8,'quick',1223443.00,5.00,12,1,'2025-05-16','2025-06-16','released',4),
(9,'quick',329736.41,5.00,36,1,'2025-05-16','2028-04-01','released',1),
(10,'quick',329736.41,5.00,36,1,'2025-03-31','2028-06-29','released',1);
/*!40000 ALTER TABLE `tblloans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblmember`
--

DROP TABLE IF EXISTS `tblmember`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tblmember` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `nationality` varchar(50) NOT NULL,
  `sex` varchar(1) NOT NULL,
  `branch_of_service` varchar(100) NOT NULL,
  `service_no` varchar(50) NOT NULL,
  `office_business_address` longtext NOT NULL,
  `unit_assignment` varchar(255) NOT NULL,
  `unit_office_telephone_no` varchar(20) NOT NULL,
  `occupation_designation` varchar(100) NOT NULL,
  `source_of_income` varchar(100) NOT NULL,
  `member_signature` longtext DEFAULT NULL,
  `member_picture` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_no` (`service_no`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblmember`
--

LOCK TABLES `tblmember` WRITE;
/*!40000 ALTER TABLE `tblmember` DISABLE KEYS */;
INSERT INTO `tblmember` VALUES
(1,'Doe','Johnathan','J','Filipino','M','Armed Forces','1234','SFC','HQ','123456','Officer','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAAFHBJREFUeF7tnQnUfdUYxh8qkVIikgaKBo2UhGhQIolUIhQLSWIlmUrL3FpEpQGJaBXRIM2oKJEpolkIpYlERZQG+7e8R6fru9+dzrnn7Huevda3vv5f5+zhefd97t7v+CC5GQEjYAQyQeBBmczT0zQCRsAIyITlTWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQcCElY2oPFEjYARMWN4DRsAIZIOACSsbUXmiRsAImLC8B4yAEcgGARNWNqLyRI2AETBheQ8YASOQDQImrGxE5YkaASNgwvIeMAJGIBsETFjZiMoTNQJGwITlPWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQcCElY2oPFEjYARMWN4DRsAIZIOACSsbUXmiRsAImLC8B4yAEcgGARNWNqLyRI2AETBheQ8YASOQDQImrGxE5YkaASNgwvIeMAJGIBsETFjZiMoTNQJGwITlPWAEjEA2CJiwshGVJ2oEjIAJy3vACBiBbBAwYWUjKk/UCBgBE5b3gBEwAtkgYMLKRlSeqBEwAiYs7wEjYASyQaDrhPUESb+XxG/ao+L3YvH73Gwk6YkagQ4g0CXCKshpY0lPkbSvpKUHyPhvki6RdKWkYyX9QdJDJV0h6b4O7A8v0Qi0CoGuENZWkk6tGPkbJC0g6XZJl0m6WtL1kjiVXWhCqxhtd2cEJHWFsA5PZLLLlCUOcV0r6ceSTgoym/IUPJwRmC0EukJYSO04SZeH+HaTtNQQovxzPMcp6jeS1pmA5H8V+rLzJR0t6ZohxvcjRsAIlBDoEmH1Ch5d1sqSriop3ReJExFK934K9/UkLZpIZyVJy4U+7DGSeOdpQ+6uf0mCwNCJ/Tx0ZN+UdOuQ7/sxI9BJBLpMWHUJ/KmSFi8R2TKSNpS02hAD3ivprvT+gZJOlnSnpIsl8Xc3I9B5BExY090CnMzWlsQpDaslv/nB8tivYaH8nSROYFgquaa6GYFOImDCal7syGDNOIWtIWn10JU9os/U0IGhT0OZ/1VfI5sXoGcwPQRMWNPDepSRFkxuGOtKWj65TGwvaYX4N24UvQ3y+lHSoX1S0i/tTjEKzH42NwRMWPlIbMkgrWdLerqkLeeYOtbMsyV9J0jsouQge08+S/RMjcD8CJiw8t4hWCqxTD5L0naSlu1ZDmFHOMziyHqGpJvzXq5n33UETFiztQPQf2GlfGMiqPXnUOb/SRI6MFwpjpf069lavlcz6wiYsGZbwmuFFfIVkjafY6mXSjpBEjGTX7EFcrY3wyyszoQ1C1Icbg1LhPWRU9iLJG0maaGeV0+RdFacwC4Yrls/ZQSmh4AJa3pYt20kZI/i/pmSNo3f5TnitHpkcl59r10n2ia67s7HhNVd2feu/JGSXho/xEziUlE09F4HRbjSLYbMCDSFgAmrKeTbPe7CKVD85aH32qRkfbwtQoY+Hil1nBOs3XKcudmZsGZOpLUs6FWSNpL04lLSw3MkHSPpvAgdqmVgd2oEygiYsLwfRkGAWEiSIe4Y5FW8e2LKXPEFSWeO0pmfNQKjImDCGhUxP18g8KQgrZ0joJu/E6QNeXHqOs1QGYGqETBhVY1oN/vbIPly7ZHcIbaW9LCAAPL6WGSZIO+XmxGYGAET1sQQuoMeBNB14QqxRenvX0uZWw8LL3sDZgTGRsCENTZ0fnEAAquk7BHbSHqnJAK3ab+NkKAPS7rDCBqBUREwYY2KmJ8fBwGsiztFgDbv3xSnrS+lzBOnj9Oh3+kmAiasbsq9qVWTWeJlkt4WOfCZB3m8Ph1l0pqal8fNBAETViaCmsFp7pkK0u4QWSVY3o0p/c3uYWWcweV6SVUgYMKqAkX3MQkCL5G0V6SILvohuwSKejcj8AAETFjeEG1B4CmpYtDeKUcXXvU0Ut58JK6MbZmj59EwAiashgXg4f8PAWo84haxayQgJEvqZyXtJ+mfxqvbCJiwui3/Nq/+8XHa2kcSFYQob3aEpENC39XmuXtuNSFgwqoJWHdbKQJcE3eL3PV0fGh40f+x0lHcWesRMGG1XkSeYAkBsqS+LzJH8OcPRZVs9F1uHUDAhNUBIc/gEleO2EVydkFWJ6ecXZ9PbhJXzOBavaQSAiYsb4ecEUBBT5ZUqgStF35ceM5T3sxtBhEwYc2gUDu6pNUkHZV+nphCgKgGxInryx3FYmaXbcKaWdF2dmFrSHqrpDeENRE91+GdRWPGFm7CmjGBejn/Q4CiGvumij9vTxZGCsiSDfWjLh6b9w4xYeUtP89+MALLRbD1myLg+ruR8uZng1/1E21DwITVNol4PnUhAHERo0h+rqUk/VjStklhf11dA7rf6hEwYVWPqXtsNwJYFl8TPlyLRD6u1yYLIyFAbi1HwITVcgF5erUhsETKhHpwkBeDnCHp1ZL+WtuI7nhiBExYE0PoDjJH4HmS9k/Op09NSvp7wnOeQrHELrq1DAETVssE4uk0gsACUfGHQOt1JX0vhf+gnP9AI7PxoH0RMGF5cxiB+xEgKwSxiijmr08FY68KZ1Ryz7u1AAETVguE4Cm0DgGSCVKWDGvi6pLOlfQ5Sce2bqYdm5AJq2MC93JHQmBjSe9PhMVvGictwn8gMLcGEDBhNQC6h8wOAQjrE6HfIrAa0rJ+qwExmrAaAN1DZonAk8LtgRMX7YMmrenL0YQ1fcw9Yt4IcLLaOV0PnxBXw09J+kbeS8pn9ias6cuKjX63JIqK3lbSjxCgixc2ehLnc5q+XEYd8cK4IqLPOs+nrVHhG+95E9b9uK0oiUyWxJZtIWnhFN2/UGzK2yXdmzyjl4wQjoemkI6nx7csPRQE85eSnqPoGYIi7IMcTVwrlh1CVEV//ObDcJyky4d4z49MFwEsieSap5oPsYmbTHf47o3WJcKCjIgdQ4H6aEmbh7ghnklxgFgeIumGIKw6dtJlkVHTFqo60B2vT/bSdskr/i3xOhkgyArhTBDj4TnwrUk/qAMHmOIDrGWtVDGYzJPLx2nomZKeLemayEQ5ynS4tnHs/1dKw/uL+O/7JP1SEuTByWmuq1thAi/G4t+/TpkCrkxl2NcM0iRujXchziLolpMXJ7A9Ip6N9xijt31L0o9SP4SP3DHKgvxsbQgQPP3FUu/4bEFcbhUjkCNh8SEnq2SZGFZIBMCmGbXhyUypqItSufS/ByndmsI0fp68nf8xamc1PM8a+dmoZ73FUAdIekcN47rL0RHA2fTIlCjwGaVXd7Sz6ehAzvdGDoT1WEmrJlJ5SWyGZ40IwSUpgdstcUxHF8XphIh8dA45tS1TRoH1o+DCMqWJ/zQyDdgvqB3SRA6F6wMzorLP8e2YWv6zaBthcWXaNCmZ+bZCCc7vu/pcjUD/pijtRGQ9H2I2BqlxfxdKaj7Ms9a4JnKaLH8oWKP9gtojaQKo351UB9vHlCybimTTJGFhgSOR2sMiXmsXSUTN9zaCUCEtyOfrkrDQcWqyYvO/1sPiQwFuKOTfG6fIiraIuxkTASzKJ5au8twSfjVmX34tEJg2YS0aFU22CbeA+QSBcvkHcWpCYe02NwK9VxCeAq/vBIH5OtLcziHHFvpQGnLgeug2AQLTIqyt0xz5YCHAfg0L3AkhWJTgv5lgXV179ZhkiXzVPIvGIonLBVZPTql80/Nvt/oROFsSSQJp0/q81b+qhkaoE0AKWmLa5S7fr10r6YIIJj0nrn4NQZH9sIfG1brXraLfwrhSc70uMmtyNUcGZ0VaFXSBtELBT64o5MWXCXo0/M42i2d5jr+jO+S6Xnb56LrfWNnlgUIYWKXdxkSgasLiA7BTBIk+p8+ccCXAHM8RGeudW7UIQFjotXCFIJdTWxohR/iNQZBd8txHFqyXtp51r5Ntx6oICy/yXaNo5VwzwjnyiLjyFXf6yWbut4dBACsrehMMFyjjMXRwMiIxXdONayqGFE56uJvMahwlX84Uc6WtLenipoHPefxJCYuj/+59nBfRSZ0WREV+bBwz3ZpHgKvegmG94r9fGVNCllSSwasfQnt4MpAUsZHFrPk3Vz4iCfD2Rw/GlxWN9yFEvPoXmyBE6Yfhd8fciusk5PaHODUW8ZWMiXMvJ7a/xbybR/eBM+C0y+kKPMEVH0LiDt3GRGASwuKoiy9Q77UDYkJ5ju+Jsw6MKZgZeK3QpRW/+dBClLivcKrCV6nKxl4rCIx+CRonJItQqiZcYF4YDr3FGu2LVYG0xyWsuUzpTOeTkfsaPZWbEZgPgSKOsoiZ5Pf30/WJ0ChiQLEoF2RXBcEdHWW8iOOkcTKryyDA5+ONJYOFXRoq+iyMQ1hvTYLft0cPwvXg9RmGu1QEo7uZIgJFQDgnKggNK1xBdIQvjRJTWvWphwD2d4WvYQEJnw1iX90qQGAUwmIzYMYuFIjF8HxLIfi6vq0qWKa76CACkBmuGEuX9HS9ujVuBHtVhM1WYSEvRx7QtV0ZKgKYboYlLI64CBZFbLk5sLNCYbirqSFQZMGYNGCcfjA6ELnxgp7Zk7CR2Fi3ChEYRFh8a1AtZJU5xoSsvhkm6Qqn5K6MQCsRwMfwFWFk4uSG0aCf4YB8WPs7WqN6OQ4iLEI4CrN1Mfr5kg5xyozqheEeW4cAV8j3RFof1CGDGvqqg8PwNOhZ//8xEJiPsE6XhN6qaPiR4Pz5lfB7GWM4v2IEWo0AGV9flgLHn5tuDxukL+ZHDTFbnHLJr0Y8J7nWrMsdArRxH+lHWJyq+LbAb4ZWtTVl3Pn6PSNQJQJ415PTf9tIEElKmPkaX9r4duEI/e3wzjdBVSmRAX31Iyz0VuXUuyslC8jVU5yXhzICdSFAzn+cV9HBljO39huPbAvUHYSY+BJ3axCBuQiL+LOyYA5M9fP2bHCOHtoITIJAUSkJHRSWPAhrvkbGiTMjawVqkX9PMrjfrRaBuQir7MVO3nPu8m5GICcEUJaTzRarXr+sIcV6uOJxguK6d2qpilFO6+3MXOciLO7nRUiE/aw6sxWyXiiFSijxRnAxwfjoXgnk7m1YvVGSc73D2o2ag6Bqt0wQ6CUsAlQpmU4j1opy6k44lokwOzZNgoux5r1Z0uI9ayerBHubGESyrP4kLHg3dgyjmVtuL2GVsyO6GOTMiTvbBaGH4npHUkIK42IE6m2/lURqGmoDQlS3ZbtaT7wvAr2EVdZf2ZXBG6dJBNBDUQtgnz6Kcq52nJw+E8VK2lD4tkm8OjF2L2GVy0a9LiVlI62tmxGYFgLbSaJaMiepXp8okvSRcx79E8px656mJZUWjdNLWIclHdZuMT8r3FskqBmcCoHBpGum2g+qiKLoRXmpGIBOjhMUuii3jiMw35Vwc0k4zbkZgSoQIHiY09OLIkHf4+bolHznZKvFD8oEVQXqM9bHfFdCJ8yfMWE3sBycNanJx5ffXJkNKJZL/B3pjDlNuRmBeRGY74S1iQM5vXtGQIAICTJrctXDj2/Dnnex2qGDwnucIrmQlJsRGAmBuRxHCU0gDS2mYZL2ObhzJEg78/CTIxUw1ZF2SNY6nDeLhosBJbw4PZG+uIkiEJ0RRJcWOhdh8e24X+gZwIJEZCjjbZXp0s544FopAMoPYS4rpkrdVPWGoHAqxmOcNCx8sRHKhauBS7p1d6/UuvJ+2RpwzMMPCwvOvZIeHNlFKT5hZWitImm0cyIdNg3Pca5466c4u3UkUcaeenqEspwS1zoiIqhB6GYEpobAoIyjbFoyLhJIWjSKo5LkzFHsUxNTLQNhpeO0RJLGVSVxxSvnIL8ornTE31Gt+woHBtciB3c6AgKDCKvoCgXq3unIT/wWDa9iSp8T5X7tCOP50WYQQBkOKZGYEYLCArxoaSqcliAkiAmdE+4sDm1pRlYedR4EhiWsMnEdEFka+RupOY5NOo2jYsMb7OYQQK+0cLK+Yd2lSCmkBFGtIAkfqKJBRGTLJOcZynAU5Jc3N22PbASGR2BUwip6RgGLYh59xwLxx5tCp0GV26+Wsj4MPxs/OQgBiAiZofBGAc7J9574DWGVGwpxyAid43UpBTBXPMq2k3/czQhkicC4hFUslg8Q+ixCKygvXm5XppxEB0VYBd/mmL/dBiOAxQ1DB7F0lGuHkCi39vxQfheFEbDE4YLCdQ73gbviOsdpyWlUBuPsJzJEYFLCKi+Z3ER8sPBu5oNWbvjknJWIjfLiVN7pekOfROwcVzZ0SXiBc1Ll5ApRkYCO2ndkwcTREusdGEJGtyT94Z1BVl3H0evvGAJVElYZOpL7U42EKwvB1OQzujXM5Sjs8dXBZwffHYiME0WuDfIBR1w/Fop1UyGbNXHqZO13BymRMqU3CwFpUnAP4MTESemkyIrJSQqPcDcjYAQCgboIqxdgKkdjRseva+f4YJef+UFcbVACc6q4JBT60xJUUZiAk8vyUb6JFLuk3eVUiHsHCm1M/5x88EviRAT58N/ztSIE5aogojuCsG+QhMuAmxEwAkMiMC3CKk+HMbn64FFPYCxWLdKM9DasWZxM+OGkwQeekwu6GnQ3y4aVCwIo9GOQCtcpfopTD8TCD6cbnCB5lj6LWDfGLpv4i3lwEiTVLlcy/JNw32AsTkKcpria0TA24BJQNPzTIGA3I2AEKkagCcKaawmcVDDDo8vhJFZE9mP54sTT2yCIQeWa5oOKUxxX1JslXRpEhEWNPPYYCyA1rnQQlpsRMAItQaAthDUqHPgVETbCSWfYhnnfMW7DouXnjEALEciVsFoIpadkBIxA3QiYsOpG2P0bASNQGQImrMqgdEdGwAjUjYAJq26E3b8RMAKVIWDCqgxKd2QEjEDdCJiw6kbY/RsBI1AZAiasyqB0R0bACNSNgAmrboTdvxEwApUhYMKqDEp3ZASMQN0ImLDqRtj9GwEjUBkC/wF42tO1gdnfhwAAAABJRU5ErkJggg==','member_pictures/sample_1x1.jpg'),
(2,'Gonzales','Maria','Luna','Filipino','F','Philippine Coast Guard','PCG-234567','Port Area, Manila','Marine Environmental Protection Unit','2345678','Lieutenant','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAR/ElEQVR4Xu2dB4x1RRmGRcSuiCB2XUVFRRRjxYpIAtgVVOzEGmtiNMbE3o0tlojEBpYYjQ07iuVHUVFEFAuioItix4qiENv76Bk9bnb/vXv37rln7jyTvLnnnj1l5v3Offeb73wzs8OFLDIgAzJQCQM7VFJPqykDMiADF1KwfAhkQAaqYUDBqsZUVlQGZEDB8hmQARmohgEFqxpTWVEZkAEFy2dABmSgGgYUrGpMZUVlQAYULJ8BGZCBahhQsKoxlRWVARlQsHwGZEAGqmFAwarGVFZUBmRAwfIZkAEZqIYBBasaU1lRGZABBctnQAZkoBoGFKxqTGVFZUAGFCyfARmQgWoYULCqMZUVlQEZULB8BmRABqphQMGqxlRWVAZkQMHyGZABGaiGAQWrGlNZURmQAQXLZ0AGZKAaBhSsakxlRWVABhQsnwEZkIFqGFCwqjGVFZUBGVCwfAZkQAaqYUDBqsZUVlQGZEDB8hmQARmohgEFqxpTWVEZkAEFy2dABmSgGgYWUbAuEvYvF1wtuFJQvmOUv/ZwdrZ/Efy+GmtZURlonIFaBWupE6Xr5PMmwW6dQPEdobr0BuyKYJ3RiRcCdmbwvU7IEDuE7U/BxbttRM8iAzIwBwZqECxE40bBrYObBfcMrrDFXP0j17/wKvf4WydeiBYixncED/C9bLP/D9334sWVv5/T7d/iJnh5GVg8BsYqWHhJBwSHdEKFBzVEQYjwpJa7m9GlRHzYh3DOqiBe3Iv79Lump+c7AgfYj7hZZEAGOgbGJFjXT50ODRCpfTZpIUSGHzs/ekSBbfDT7nM1zwgBQZRKnKtUoXQvES+2ES9AnAwhZd+u3Sf7CthfwHGcs9FS2kCXFZwVIGZ0WUtXdaPX9HgZqJaBeQoWP+yDgtt2n8SfJi3n5cDTgp90P1ziTsVTWc42P/SxxZqKwPVFrYjgVVPfss0n4LjtiRyii4h9uxOx7+STtvMdLiwysHAMDC1YeFDEoeju4UWt1c1CbE7sfnyIET9Mfozs58c4NjHaigcD76yIXHnjyb49OkFbyieeG58rC/zAGVzx+c3gGwFdUT2zrbCW1xyEgSEFC5E6bjutQqA+GWwL2G5BlGZlZDwyhAtBKx7aztnGawUIGx4ZoOt9RHBBd+z7OyHjn0fpenKcRQZGx8CQgnXztP6kHgOIEuJ0fCdQ5kNt7eNRYm8I2D+DnQLeuJ4f4LVhH4St2KEE/pezDw+t/yJAW22trbz6GgwMKVhUgR8FXoAe1DgfydINxUujG3qroHhvfU+NGCFCBngRULbpdipm47TtQtRqaMFaCNIabgRe2lJAt5LPa3afpevJ3xGzfvyMGCSC9jXFrOEnZ0ZNV7BmRKSX+TcDeGWIF2K2Z0DCbxE3YmR0KxEv3mTSzUTY8MrYb5GBdRlQsNalyANmwABdTcQMAUPQSONgG/AmlBcs5JYhXsQ0EbDyZngGt/cSi8KAgrUolqy3HQT6i3jRxSxeGp4Z5ZiAVAxGAZwQOLSpXltvuuYK1qYp9AJbxABeWYmNIV6kaTCeFIHD+ypDm0iFQcTwziwLzoCCteAGXsDmEQvDC0PE8MyKkOGFERdD6IiRleC/8bEFeggUrAUypk3598gJPDBSMRA0ph76ZeeRlfGfiBneGMeS+W+piAEFqyJjWdWpGShDwJZyBXIByRXDE7tr8PruqmT3L3d/m/pGnri1DChYW8uvVx8/A2U2DoaO4YXRtcQ7K1n/vL0sEzo6XGzO9lSw5mwAbz9aBvDK8MgAwX+GL5XpgnhjSSJsSb1w7OVAZlSwBiLa2ywMA2XYEm8smRqpJMTyWbL6iZMhZgrZjM2uYM2YUC/XJAOI1e0C4mPkktG9JCG2rBfwlWyXSRcRM4P9Uz4mCtaUxHmaDKzDADEwYmHlbSUpGEsd3prPS3aChpiVecv41CvbDrEKlr87GRiWAbqS5I5dKziwEzBiZMTHCOqTN0baxXLATBh4ZnQv2d+8Z6ZgDfuwejcZWI2Bso4mXUoGjeOJMSNvGZ7EOUXMELIyi2zJKcMra0LMFCx/QDIwXgbKdD54YAjYXgEeGoH/Mt//j7NN9xLRYp45MvxLegZJs0Xo+Fv1Wf8K1ngfVmsmA2sxQJAfESPQX+YkI9BPIXZWEmVXnv+27Di8ZloVrJqtZ91l4P8ZKF7XUnYDhItu5mEBXU3KvgHeVpVFwarSbFZaBjbEwOty9BO6Mw7O57EbOntEBytYIzKGVZGBGTKAd3VQ8IKgLExMsH7voNohRgrWDJ8QLyUDc2agJLDevxOrpV59GEp032B5znXc1O0VrE3R58kyMHcGiif1iNRk/+CyK2pEusMrg1cH1a9opGDN/XmzAjKwIQYIrNPF4w3hnYP9ghJsX3mhV2THixZBqErDFKwNPSseLAODMkBCKXlXgLd8ZajPWgJF5YhPHRm8JlgetLYD3EzBGoBkbyEDG2CAfCo8p7t1ArVWTtXKSzIO8eiACQmrTxBdiy8FawNPkofKwBYx8NBcly4eKQfMVz9JIbOdoTkfDT4UMP5w4QdOK1iTPBoeIwOzZWD3XO5+AW/t7rDOpcsUNXhNbJ/ciRMCVX0QfaO0KlgbZczjZWA6Bi6W0x4fPCroD2ouVzs3G98KvtqJErM04EFVmzM1HU3bP0vB2gpWvaYM/IeBHYNDg/t0WC0edXT+9vGA9RX/KHEKls+ADAzNwC654T2Dhwe3X+XmDEI+KvhC8I+hK1fz/fSwaraedR8bAwTMn9R5VUzQ1y+fype3B8cEfx5bxWupj4JVi6Ws55gZQJyeHjx6RSXPy/f3B68KCJJbNsmAgrVJAj29aQYemdY/JFj5pu/U7HtT8Ibg700zNOPGK1gzJtTLLTwDZJ+T2PnE4I4rWvvGfKfL94mFZ2FODVSw5kS8t62OgaXU+DHBA4Nr9Gp/XLbfFRBI/2d1raqswgpWZQazuoMzwBCZlwQs09Uvr82X5wW/HbxGDd9QwWrY+DZ9TQYunL8Qn3py0E/yZA1BhsEwg2cTq9SM7RlRsMZmEeszTwYukZszXIaZDohVlXJKNngLSGqCZY4MKFhzJN9bj4YBFjZ9UED6AUNoKOcHHwmeEXx/NDVtvCIKVuMPQOPNZ32/lwUPCPrDZo7O95cH322cn9E1X8EanUms0AAM3DT3YBUZhs6UwmwI7+mE6qcD1MFbTMGAgjUFaZ5SLQOHp+ZMGXyVXgt+mG0mvXtH8OtqW9ZIxRWsRgzdcDOZGO8pwW2DK/R4+GwnVEyAd0HD/FTVdAWrKnNZ2QkZYBl3stBJ9LxF75wfZ5uYFdO5/GjCa3nYiBhQsEZkDKuyKQZ2y9n7BY/tRIogOmkKTIB3RMB8U6YlbIri+Z+sYM3fBtZgcwzcKqczi+e9gl27S/0gn3T5iEt9cXOX9+wxMaBgjcka1mUSBi6Tg24T3CVg7qlSmK1zW8CQmc9MciGPqY8BBas+m7VY40un0WXR0Ltne48eCXhQHwiYd+qsFslpqc0KVkvWrq+tLCDK4GNmSOjP4Pn5fP905039ob5mWeNpGVCwpmXO87aKAeZCBwhVPw2BfKk3B8SmGIRsaZABBatBo4+wyQjUIQGBc2JUpZyRjY8F5ErhUVkaZ0DBavwBmGPzCZqzBNa9g/7MCKzFx4R4HwxYm88iA/9lQMHyYRiSAcTpHh0u37sxg4xJQXhvcOaQFfJedTGgYE1vrxvm1L8FDKTlrdXFAyZ1Y4I3AsEMpm297BkCDggODHi71y+n5QuDjd8dnN46UbZ/MgYUrMl44ijeUj2uEyhesa9X/pIDyLI+J2AYCJnX/DDxII4MFnFtumunXbcMGBazf3C9HkkIOUNiWIrdJa/We3r8+6oMKFirPxjk/dwkIM5y1wBPAQ9qloWVVVgK6stBrd4YQ1+uGzDAmBWOD+sRRH7U8QHB8s/Nkjiv1S4DCtb/bH/lbJJBjReFdzBUYanyFwbPGeqGm7zPJXM+eVE36HjaJ58sGMqy618KTuy28TAtMjBTBloWLJYVf2r3o8ODuuiUzJ6b8xi7xo/1igFzLXHtqwb9WSzXuzyC9fz1DprD31mQYSm4U8AULZcNSEF4X4AHRXY5bf/NHOrmLRtjoCXB2im2Jd+HV+l8TtPFY4I3Xru/Lfhw8LsJnpcdcwxTnHA/fvh4JA8L+q/yuQwxrRsHJEjOszCn+X4Bcaibd0Ckfh68NCAGRbvJkbLIwKAM1CxYeC90S5hWZO+A74gCXg4BcuIrtI9saUbxs38jHg+G+E6AMDGY9oSAhQlmVVjn7sXBwb16vTrbLC01ZEEk4Y94Hd3i/Trezs4nGeWM0zspwIu0yMBcGahFsBCgZwZ4RgTESSe41IyZ+1Wux6KY2wLmTSJozL6tLnQFn9u7CSsJE9NivBwCe4eAgDae2u8D3rCxH9vRJeNN5GoFzjgHESLtAs+JFYuXArw8FmBA1AGFWBr3RqBoP16U4/TWINfd82FgzILFj+0hAevBEWMaqrDcOGLx94BAMt1APK1Tg61Y5ZcYEfcjPjRtYdEExIU8MLqf1J3CvjJHVLk2aRXsZzoWPEfiT+xzpoNp2fe8wRgYo2AhVLype3ZAd28rCt4EQrHRQoD96wHidUzws2AWw0eunuscFayX34WHBfAy1+OGt3XUFcFd7oA4OX/5Rq3u8aNhYEyCtRRWnhYwe+RGY0103cj3IXsaT4HcppVBYYSQ6UoIvv8kQCQo1wzIuUIEWJac1AaOnbSQFMr0u3hmeGTEurj+NIWsed7A8caSQDf5WSziSc7WJAH+ae7pOTJQDQNjESxe5z9rA6whRssBXRpAUHiWBcHcN2C8GyICT4jdUtDP3l7rnrxR420ib9QQUrpsBq1naSGv1SQDYxEsYkO7rGOBb+bvzIXEnEjzXpEXMWMICoJGUJwUgLW45M1iWf6cjG+6dHhPBPURNdpCjMwiAzKwDgNjESxenyMApdC9Wg7eGZCgSMyohkLCKEtMlU+SR8m34jse2vYK3hhiVuJkxJvggTgU+ywy0DwDYxGsnWOJtwRkieNBHR0QGF+0wgwPdClJK8BLo927B6QgbK8waJo4HUF+3ujhkeKZIXDE6ywy0AQDYxGsJshep5EIGEmc5E2RG4VHRndz0nJsDuSlAzYlUE8c7WsBCaAWGVgIBhSsOsyIZ7YU0G0m4ZO3meRXkS0/SeElBW9PScFguhtiZ3hrdDstMlANAwpWNaZas6IIF0NrGHrEUCWEDbCvP6vn9lp6Sv7IMu5k0Zf0DNI1XM69/udjoVqgYC2UOVdtDDEzYoPkl5HfxYBmcs54EdBf328tJoiVkTlP8J9tupvEzX65+NTZwrExoGCNzSLD14fJ98g7Y/gT8TMGi+8VMMSHua+2V7blj+SYESsjNYPteaecDM+gdxyMAQVrMKqrvRFeGKMCeKNJEi2CVlI1VnspwDhF3l4ykPrkgKA/XhmwyMCmGFCwNkWfJ4eBknNWup683aTLycwQZfhTIYrE3209ESO/zhwzH6OJGVCwJqbKA6dgAK+MrH5GApBQi4DhlbFNwRNjBAPDlphSGY+MKXOWp7iXpzTAgILVgJFH2kRmmyD3jJWeGZbFNvN+0eUkh4xhTMTF6FIS5DefbKSGHLJaCtaQbHuvSRkg6I9nRqoG84QhZKRekEvGuEzSL7YFzKqxFXOUTVpPjxuYAQVrYMK93dQMlJwyupXEyZiAEO+MLuaDp76qJ1bFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFgIJVlbmsrAy0zYCC1bb9bb0MVMWAglWVuaysDLTNgILVtv1tvQxUxYCCVZW5rKwMtM2AgtW2/W29DFTFwL8AKEiYtRbEYcwAAAAASUVORK5CYII=','member_pictures/sample_1x10.jpg'),
(3,'Admestus','Rafe','A','Filipino','M','Philippine Coast Guard','PG-13234','SFC','HQ','124333','Officer','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJYAAABLCAYAAACSoX4TAAAAAXNSR0IArs4c6QAACxNJREFUeF7t3QWM7MgRBuD/wszMzMzMzHRhBRXmREGFL6wwMyvMzMxRmDkKMzP7U9q6uXmeHe94vG+gS1rNvrd2j131u7r676ryAalSNTCCBg4YYcw6ZNVAKrAqCEbRQAXWKGqtg1ZgVQyMooEKrG61HiHJzZK8P8k3RtH8hg9agdVtYKB6QfnTR5I8L8lLk/xrw/GwtNurwOpW5SmSvDPJqZP8MskJkvwhyeuTvKx4sn8uzQobOFAF1myjnjXJFwugLtV4rNMkOX+SAwvY7pfkHRuIiaXcUgXWzmp8XZJrJnlUkvtOHHqrJA9L8qUkt0vyraVYY4MGqcDa2Zi81ueS/DHJycpne8Yxkjy+AO9JSR6S5L8bhI1Bt1KBNV9970py2SQ3T/LCjsMvmeRZSf6R5DpJvj5/yM0/ogJrvo2vkuTNBTBnnHH4kZI8rcRfN0liCt1qqcCab/7DJflRkqMmOW35fdZZN03yhGYV+cwkD9xmeqICaz6wHIHTwm3dJ8mj55wiLntlkp+W+AtNsXVSgdXP5Jco3NVLkpjq5skxGw/3uOLhrprkd/NO2LS/rzKwTlSIyYsmuVCSbyd5VVni/2ePDXGYJL9pPNAXkrievoLrQk2cc9vAtcrAwnxfrsOCn0ry8iSvboz2474WXsJxaIdzNLTCbnUm5kKsXmmbwLVbJS3BPr2H4LEEzhdLcuUkeKMLliDaIH9rvMd7kxyU5JO9R138QGC+frNveNI5AXzXNyBXr9ZsaN+gidW+v/glrM+ZqwysWVq8cBJxyy2aJf5xy0HPTXK3JH8aUfWC9nuVafnjC3zPLcs13jjJ5xc4f61OWUdgTSqYNwOoayT5VZKnJ3lokn+PYAXAAGBT2tsXHB/R+trmWu+Y5MULjrEWp607sFolnyTJw8uK7fdJbl+yEJZphJYovV5ZRCw69hmaWO0NZZV5j8YL/mXRgVb5vE0BVqtjwfUTG6NdvEl56UsN9LWPGO+3ZU/wwX1PmnHcsZop1VYR0pUnlPO1UbJpwGqNc9eSfYAeEI+hCpYhXyvk51BguZYjJnlMkls3m9cPKr/vNY2yDJ10jrGpwHKzp0vy4cZwPymbyGKwoQIIcrPOM3SgifNNrc9pNrC/nOS6C6w4l3gpyxtqk4FFSycvgbZNYsTmDweqDu0h+EY5yCxdlpw9ybMLU3+XMo0va+z9Ms6mA4tSj9Mw328sIJPW8okBmhYT2fu7Q1mBDhhqn1NxdnK6BPTy632K6dZStgFYDHOUwtSfr9kSunaSDwywlsode38yS8eQy5TsCDn1CFlx4trJtgCLYQ5fAu9LN17rCk3c9dEFrYXKQG3YaB5LjlaSB8VcvBhubq1km4DFMDaTX1HoCDHXItmecrK+2exXnr58jmlw20CmRd93wz34vqXdy7YBi+LEMgLwM5esA4TqbsVKkyeRkjy22LayT8nTPrJ4L/ukKy3bCCwGOXJhvn9eeK7dGulDST7YbB09YLcnDjj+nkn8WDzYwkJPrKxsK7AYRPaEFByby0/ZpYXwWYpaxUB7Kb7zsWUB4prvX4C2l9fQ67u2GVgUxFDoBx5gNzSEAF7Vznl7aXn5B4m38F6yOW5b9h6X/y0DRtx2YFGdHC857TIP+hKoNqSf33BZxxug+6GnWkRIdkSuyraQqbqXiY87Xn8F1v/VI42F15ISoz5wnrTl9zamFwn+543f9+92FKQNifX+WrI6gG2/Ny+pwDrYhJp98Fj37mHVoxeS1Mryqz2OH/sQ1/HUhvhV9GF/FGv/6bG/dKfxK7AO1g6wtBvB8zJE6e3PZUUpPXpVRMk/D0YkJSrmWOaeZu/7rMA6pKquVaaVc/Xow8C7Sc/Bia2S8FoKOOSmIVZvM3ALa6F7q8DaV222ekwrSMmd5LPlOEH8qsmxS47XncqF3XkBSmXQPVVg7as++VYY9TMl2am5mt5Y7y6FqYOMMOLJaBE9JYjfnzHidx1i6Aqsbk1rAgI4rVG6jtJ5xlTziL0y1oLf04LLQ6JOc0hmR+9LqMDqVpVV1lubLjPnTvLrGdrUeM2+o5KwVReBvNx6KThir9GlAmu2inWMoR/Bb5fwBErnEZOrLvg23tWGtgzVJ499wRVYszWMVReg2w/8WMdhVl9Ap7p5HaSti1RzqbEJ3m40qcDaWbVaF2Hlu4onzlJWWjr6rYtYlKgKIqqX3jLWhVdg7axZU4j0GM1tp+kHhKr0GXt16yT6SFhwYOhVko8iFVjz1aorsumwyzPJfQe+dRGpQhYb4izTvMXJKFKBNV+tgGM/UHX1dNttfeD9/6pW0wCOLAjTttI1K0Kb1bIhkKcyYUeRCqx+an1N4X8w8pOCIDVNjr1fKONV5TR6Q96+H7lYvygXc6hmG8fUfNgkKpFuVNKAMPDSmL9SNtjfl+RFe5EcOBRYblQFiaIEjS42tSWi1Z9AXu7WpMjilEUwtHPMoRtW/PjFuyiGxaMp1uBp/D9gOWZSlOMDlFWe34FKtfffSwWSlSzAf3d/NB4ZCiwFnG9LcpFyx7ICuFlvbMBcr3zSfz+HFR1iBPGMPCl3L1mkNqK9EoU+T9hkFuh+I1fKvwEEKPwAgB8sOEB4y5gGIUS2hKnpe4Vzwjv9oPzb32QptO2ZnKNETDGumkk5ZB7uZfWo6KmW2YcNBVY7spcYSdNVUuWpBjSg8jQr8AS4z4ycwsHtMwCw85yLvERJreCJi9HwWAxPR1Z+8rS8gQJgxC3Ac8riNYBAl2Q/rsH3t0CZThz09grtvSUI8jDAsHGdlZcFrGnoCngBzYbu2ZJIQ/F0UaQniyEoFvB+Vpa+u31KvJlL3vnlGz4JqBi5Fa8o8T0654kvBN2eckWrpgwMNLA4z0MBUAADlF3iIQEy3tlqyn3wJo5XWGGMKhMaGAtYXUo2VYgZNOqwMlHIIJ4wzQCiJ5fRgEF67U5unZF1UeZdhgiA8DL6gvo+YJHW61O+leDYpwdDvAKAk3EkgIphPDRimypFA3sJrJ2U3jaxVaQg2Q5gxBuqlr0jcHpLxTSlcMDqiMd7T0lhMe0AApDISwdm0wwPhsMxPcoS5YGc3/etXbyvUjFxjbEmxUMCeHpnVVkxYE0bxDtrGFN3GNUzwIFLEkBLxBO3ISxtpvJ408LTaGZmI3kZoshCtoOpc9qT6tisQtmquMqKA2vSQJbaSEgLgyuWmA2H853ipZCTOinjecRRptiWDefpUAGIzHl57DuBAv9jddc19fJU+itoFFJljYA1bSxAE6tp8XOqEoRboZkCTYuoDjyQ4NyxrVjmi914sd0ku/GazlOYwDNNiz038dcy2kduDDBXJcYaqlBTFE+F5rBtIU9KjIVA7BJvmbAHOP3iAenIpuHW41l18obiK96ya0GBfcc9tVkDQ+9lI87fFGB1GQN9IP4CFp88mOkMB9WK2M1Uhvi0EOD5JkWgrvsybzSrjMqrWSw0gLBK0cAmA2uWkU2PptGrFw7MinRSeB8LBGy6tJh5bDZOzvEVWBNa3EZgTQOOt7pA6fInK3RylYnf8sYxwbnYrUsQsBqKyNCsssUea57xrSy9KfXAkinQbv4iTTUPeVMhcttxELqoEB1gqlRg9cIAglVOu2lucsvI6hNvJXCXkem4MXuS9rrYVTqoToX9raFVo64uOLVpsc1TgVVjrP5o6jhSDCZXHKVhhenh1BXQu3Gq1KmwYmBMDdSpcEztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHYFVhbbPwxb70Ca0ztbvHY/wPq8N5bopF06gAAAABJRU5ErkJggg==','member_pictures/sample_1x12.jpg'),
(4,'Test','Mikael','M','Filipino','M','Armed Forces','324335353','SFC','HQ','124333','Officer','Salary','data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAAXNSR0IArs4c6QAAHV9JREFUeF7tnQfYbUdVhhdoVASl2RBRiiEaQJEIQSB0AtgolggoxVBTADGKtAAxD4QmEErAAEkAA4kGQSKCKC0qEimWRFSKNGtoQugE2W/uGu7cffc5Z5cpe5/zref5n/vf/997ZvY3+3z/zJq1vnUZky0dgcuY2e3M7Ggzu2uCh/k7M7tJgnbUhBBIjgAvu2y5CPykmb3czA7yR/iMmf2lmb3JzC4wsw+Y2Uc7Hu8GZnZVM7uumX2vmV3PzI6IrvtpM/uz5cKikW8rAiKs5c7szZqV1Xlmdlkz+wczO9HMXm9mF498pFub2Zv93oc2hPacke3oNiGQDQERVjZoszb8Ow1RnWBmnzWzx5jZi5t/vzKxx5iwnu9bzIlN6nYhkBYBEVZaPEu0dpKZPdLMPmRmh5jZJxN1GhPWU72PRE2rGSGQBgERVhocS7XCVu3ZZna+md3dzP4jYccxYT3IzH4/YdtqSggkQUCElQTGIo38hJm90bd+h5nZ+xP3+ktmdra3+cuNI/4PE7ev5oTAZAREWJMhLNIA8wRZEb5w28g5nrLzo8zsed6gVlgpkVVbyRAQYSWDMmtDrHjOMrNXmtk9MvUUbwnfYma3ydSPmhUCoxEQYY2GrtiN32Jm7/ZYqR9I7LdqP8T/+w/e0YRI3LTYE6ojIdATARFWT6AqXnY3M3uVO9sfnnkcgbDohqDS92XuT80LgUEIiLAGwVXl4teZ2Z3M7Dpm9u+ZR/DHUXrPE5u+npC5PzUvBAYhIMIaBFfxi6/lp4F/3aTb3LJA77Ef6w1OlAW6VRdCoB8CIqx+ONW66j5m9iIze6CZnVZoEKT33NH7up+ZnV6oX3UjBDYiIMLaCFHVC17oZHWoB4uWGMx9I3K80MyuX6JT9SEE+iAgwuqDUr1rXmtmP9skNn+zmV1ScBj/28Rkfbf3J19WQeDV1XoERFjzfkM+4kSFL6ukxVHv9Kv3pCT66mslAnoR5/1y/J+ZfdDMSMspbUjN4ITHpN5QGn3114mACGveLwZKDBAWQn01jP6vbGafayLtf3SFGGCNcanPHUVAhLV34smlYyuEbAuG7yZ8X+v1gKzwXR1YaQCcUB7pfT/XzI6tNA51KwQuRUCEtedFIObo8I53glM6osyRHS7p9A5DQUbmxmb2bWb2pUrvbBz9rvel0iSo2z0I6AU0u2aPCPL/9tQYiIsiDaXsDDO7p5ldzcw+XqrTVj9oxt8rWnUq+r3SRKhbERbvQBzdjSAe26DHr3k50Il6aeNXOrfAC0TgKAGj9/ZiEwW63K+LGJ//NLOr1xiE+hQCWmHteQfiD2TAhEoyrGx+b81rggQLUsI5q8ugfcWqrrb/iCIXP6ZVlkijNgLaEu6ZgdhPgw4UZIShmf706Hi/a76QEj6lSRr++wyTie/qf5oSXO+tLPcCWUFaGNHvVOyhpJhMCBRFQIS1B+6ToxOwLnlgHN8/06THUK+P79tG7T/q+r09w+xBnrcwsytNKOGVYljUOaR+IYZ6BAcVMiFQFAER1l64kW7BAX9REyj5PWtmAZnix65YdT3CzN4TrdBSTCYlvZ7ksi9/kqLBkW0gn0zoB0ZCNInRMiFQFAER1l64IZobeuxVn1QYcvx+s4O4WGU904uaUjdwqt3eHfz4sY6b2tiE+w/27SBNcGrKyaVMCBRFQIS1F+5XN6uju/h/Iay+QaOc4lEq/qdaM8dpYviaMqlXcaLAR3bnKQ0luJdT1O/3dvBj5dgCJximmthWBERYe2c2Pi0cqlDAvfh10K0ilSU2SItcvODIH/MusV3l5BI/1pfHNJDonpjUVVknEahqpj8CIqy9WFHs4dNmdjlPyxkTIElqDzFcwTkdWoesnjEhdusl7jP68aaA6j/2n97kV4JJiFFTZZ3k8KrBTQiIsPZFCP10tl2EKrCCGGP4eojhumuLuD7WpPc8bqSCJ6eTf+onmfiyallXzFqtsajfHURAhLXvpIcVBL4ZfDRTjA83sjBx8CknkPz8nwc2/INm9i+N+ucfedT7wNuTXS7CSgalGhqDgAhrX9TivEI+nG8dA2rrHraJkBY1BYOhvjCk1DzzhHLDV7z8VoJhjW7inR5QSwPI3rxrdEu6UQgMRECEtT9gb2vSYQ5r1Bv+pikPf/OBeK67PBbE4zr8XENWWpTguoOZfV/lANIQr8YzHO0HCglhUlNCYDUCIqz9sUGZAIWCz5sZQaJ/m/AFOts1t2iS074rmtkXe7b/ux6wSvIxSci1jBgsTiyxpzTjJ7BVJgSKICDC6oaZOoD4sDjGp/JySmNVhXonhpInYRBs9TYZVZ8JSMUBnzPhetM4Ljazy/tF+NTY8sqEQBEERFjdMENSZ5nZAb4tZHuYyogQJ0yBuC3sw54StKl9AlPxqZ3QVNE5cdPFmX5PJR0q6gRjm3r3TH2pWSGwHwIirO6X4pvcmUzcEz6tWyV+d3DA/0FUzZmQBVJ91hlbQVQbWGWt0+tKPNT9mouVLRSLlRtttb8PAiKs1S8EvqxTPZA0RxrKdV1+OQSZsurCib3Kp/Vdnpj9Go/xqvUqx053JUHXmoUd7VeEtXriKV76bjO7gYvokYSc2iDCc/zkj7YRBHzkik4u66eDbMkIv6hlWmHVQl79StN9wzvwMCcR0nZSxWW1u+Qk8i/8h1/zCHtkmruMgFbE9JC/wWFfw0RYNVBXn5cioBXW+hfhO73oBNs3ik8c2lInTfUa3de120N7+MzwnbWNU7lf8LJfQwJPU42TduLA0SkpTCnHpLZ2BAER1uaJvr/nFoIVqqPkG+aw5zSVcY7xhj/gwav/1ero9Y2kyx1dBqeWmJ8IK8fsq81eCIiwNsOE7+ivXO/qE2Z2HTOjhHxq+3Z3wkNIYSVzy8an9YWoI+RrkKo53lVIU4+hT3tyuvdBSddkQUCE1Q/WX/UtG454ZGJyKX9CWsFPxcie1ZDjb0RDJLL8t10YEO35GkZRjCAhzYqvtqhgDQzUZyUERFj9gacK9AO8AjOVdVKm7MSjIAqe0l5BgpjATAI0MU4QTzKzfzWzH+k/9KRXxoR1XhRLlrQTNSYEuhAQYfV/L3C8k8CMRDC5fAR/xidm/VvafOU9XDeL00l0tFBFgCj4+ZnNlpDTxO/wfMfNraW9grAKIt4xrbDSYqvWNiAgwhr2irA1fJnfwkrnUcNuH3Q1VWoQESTqnqh4+qbcF6sa7EZeoWdQowkuVlhDAhDVxDgERFjDcWOFw0oHQ4YGh3wOYwVF4Ylre+M/5/LI5B5iv+L5jjn6XtemnO6lEVd/30BAhDX8ZaAaM9VjqGaDRAwpMynKeXWNhBPJP3fSgqiIA0PID+c8ooCUGSttcdn6M5rqQsSQyYRAEQREWONgRvqYtB3sVR7MOa6lzXdRtBUtLAzH/209cBQJHLaIpY0wC0gb4+ChXd6s9HjU3w4hIMIaP9kP8ZgoHODIveRSUMCH9QrXnSIxmgj4w/20kkj8kmW/2vIy0sMa//7ozhEIiLBGgOa3XMEd8FTHwYiLogZhDiPE4QLfhn7UzK7hnVw/qsaco9+uNuV0L4W0+tkPARHWtJeChOiHuiopKqCogeayYxvCOrnV+P1Glg2bMsbY6S49rClI6t7BCIiwBkO23w2QFrpZP9xEfb+jiU266fQmO1tgrsg3PCpKWn9xE6dFrmNJo5ArkjuYCKsk8upLag2J3gEcz0FGeWiZ+yFDwNlN8nEQ/aNWYdCHH9LOlGvxo32rN0AaESs/jHQdDiMo+4X0DVtH/HsQLZr1nC6W9LdNeUbdO1MEtMJKNzFxGfec1WQIbSD2i7xGCAGiICl7ivEe4A+jvYOaxGoi7K/aKFPcxKPpqZJDIjbEQ5mxsUbSOER2iRMZ5PYRb4wDBIwiHUGSOggVolrxTxOqcY8dr+6bGQIirLQTQtgBigpYTq0oCCvUTPz5prDpa3s+BhWk7+lkxMoMIiLWiyBVCLBtEAunlBirI1Z0CAgGY0u4qdjsD5nZtaJ7UL+4cRQa0TX0D0U/hIwPif6vd7bnZG/jZZr89LMaO8dz+Xh+vTkpxH+Frcrng4AI6mS1xAf+3itI6dO+XSO+CpFCVln4qRAIZGtHHcKgbhqvIumbJHCeMbdBiqzwgum9zY34TNvXxOeZmPiDzQf6yR6xnqo3tm2sdsLKh2BS6gXesAloZcWF5MvlWp0RjU+wK74kEqnfNEJxol29uhRhcbBB/UMOHLALfQubCk+1sxAERFj5JooP2XPdQR62ThBZCuOUjm1h8Pt0tYm/ibQegjtZLRGV/tWJnRMLFhz+KFZQeqykkY4U9MFEWiWRn0lfIqy8E4HT+LeilcGQLSJyNl9yUsD5jbP9Su67wufUNmSVOal8Y+Mjos7hJxM/WjvKvS0umLi7lc3Fq7ygYlGqb/VTGQERVv4JYKUF2SBHgxObVQpOZ1ZAJFBTrJXYLUiIlRNbOX6/avWET4k2CHEIuYScvKFTRT9BzSH1k7UDV6lc/YbUnfRs72zfInJ5qW1pz6HpspwIiLByorunbYT+DvStDNWd+2DO1o0gVP5FXRR/FaXAUGoIDnAKYpzrw3+f98EH+YhMj8T28g7eNs556jR+JlNfm5qNybPWSm/TGPX7DAj0+fBk6HYrmwRLjvwJImXFRNgB26grrnnaz/vJ3Huaijkfd5KCkM731dg6oK4cbfuIU+K0j1AFEqPZFqY0trak5ASrEWHffh60wlidypeVcqZn3pYIa9gEBVJCspiYJj4wbMfYzkFQQXYlbvXfmoBHCIUTOrZzhAw8M9JkxxlOyAGrpKEWp8lwgoaTn3YgrpTyze1wBratRLzXNEg5VOMmePaimoNR32UQEGHtjzOR3AQ7oibKKgYiouAD3xPTtMoCGbGV44uVEmk0hBu0jdSWZ0eR2/i2UDEdqvbwymgLiALp0T7ue7n2e6q3KHZ0Dzk4SNV/Vzskgoe0oJxKGTmfQW0PRGDXCQsnNzFMbKOQbGHVtG4LF+DFwY1wH6snPsysasaUjodk2F6hIIqd5WJ9bHP62IObaPVT/EKE/lhxMS7SW1j9pTDSZOLg0Jy5kkPGC0YH+w2UPnvakJt17TIR2CXCghQgiNt5PhxE1ddYPSGch98EhzNJv4Gg8FNBdGwLCUMgqJPUEj5Ql3d5Y9JLcKAT2Akxkp4C9ge4xDKOcqSWMU4PyblDhplYK7aZpMUQgc73kCVlwNiS0R7bQIxK0ARXsvUkVirVKd5pLRnkuZzKoQvGgQamFVbfN3nh120zYZGOghOcGCZCC4bU8cPBzIkbaS9Ehb83mmc+JPhO7uOqBXOSCObUDmJjlfgpXxlBtmxnA/HxKBAmqTsQJl98z8/4wvfFFz4htsWhPiL3QdYhqr72q892O+QYkg/JCapsyxHYJsKixDsfLlYwx0TViTdNIYSEPjrKAaSrsEJpy6BQwBTCQ8GA6jW7bGDDIQIrSgJVUVsgnozDA7CD6MAUwsxl8aqP/kIl6lz9qd2ZILBkwmLVFHTU+fDEGf3r4CVNhZgiVk9srwgh6DpRo32+cIYTdT7U2BJymsaHly/6ZfvIao3iqGwRYy0rVghBaoWt5C+6kmnsU2OrSUwWbYetLdd2Rb4PHe+66xkrZESCNOSE74/cxHX9EmnPgQOJy/j6GDMrNJ59rDEfnIay9Q12ehMsi/KqbAcQWBph8cJCTLygIadt0zRBSJzasQKgCCm+j3VGhDmrNUIPNuXK8deddgngpCI0Hx5ilvhwjjlm59nCCo6TStqCLCEtiKmGQe48F4Uw2kZAbMCIUA98amyZWemuInkIi0MK/HC0DVbEo20ySIqVbvyH6fnubI/laDa1o98vGIElEBYfWpJe2WIgq7LOQlUZTttYyUAmQ+KRiDc6MnLmtvuiTdJi2ArhgB8irQLWkCyrFcgnEBOncBBxCgv6VaTn4MSnHw4CGHPXCpSDA1ZNweEfj4EtMnUHkWUea+hg8ZwQGL5ESCw4yuM2wZJIfnyHrMY45SS5GkN9ghNQ0pVi4zoOK7hXtiMIzJGwyI+DNNBy4kOzaauHo5mjfP5ad60C+kwlhIFfJChchnv4y82HFmc0KwMi0vlw8+Ehlio4rXFoE6lODBcywfh5+OLEj/Hj1J6ybWO1xnYSJVP6ZitJX13zB6m/xn/P6oVnIKUGIT6Ig20wPh9+HlYmPHd4dkiYvsasEDdhzXhZiUFaEBlVrQm/IKk7NkgW/DhdZQvazqvkDxF5jByM8CxD/nBsGqN+P2ME5kRY+Ioe5gm8fSAjtACSQuUTJ/BYiyVLQhu0h4+G0zWMD3BugzxY8UAUfL3O/892Nvi24jGQ6AxmVO1pzyNjf3UT6nAjX9XVqhLdFzNInq3lca6A2rUKW9cWaUngx8khByhsYWVbiMBcCCuOWl4HM9uXl/lf1LGrqbh9Kiqz3Vhn/KVfF+G+7l5INZw4QoI4zNmeIU3cXhmMXSXgO8OxTdWeTc/Btiuc5vHvVC34FB8JQhI41aW+Y3uFG7fP6hb8IGO2lvyL83/VPeBJUO9Lff7YQsoWjsAcCAu9qKeuwZG/nvgpCDlAJ50Tt1QWx/KENtlq8GHGOY/GFEQTb7+Ic0K1k+DOuVgstwI+RLwT4Nml0x7GjKP7HE+yxufFqiRsEdkih+9Z9dEOAbFsJ4nr4nu2u/gM+WJrDKmHf8GIbTTXYPgRWe2x1WNrCp70QTAv0ephJduFJyeLZzbbRlQZuuzhfhpJzB2BwetWwzwTz8J4WJ2XLpE2l/dlseOoTVj4JljCU7ElNvxFpKzwUoXyWTlA5uQJsmQLRmoH/45d6eQYX982ka2JC1Hg3MdxTQQ+kfD4iyCeWieNfZ+D6yAoVlP8UWA7jB+zr/F8bCvZJuP72mQUvqUArmwhCNQmLMIHiIeKLWe1mYVMy+BhtuVfSILmyB/D18WKEeNAgzkn/IAVDtsq8ijZVtY2Er+f7nFxU8dyBXfuo4LB8/KsXVvHB/mqfWp/ur8QArUJK45Y5i8p8VXUn5MNRyAO32grKkBYENeqPwbtsIr2lpCVCx94toRs4QiIZetFqAL+uLHGdp8cTcgVf19KQUAc9/j1eJaH+Elk2xepFdbYmat0X23CimVLbuYvbSUoFt9tjCVEEPuFwkkofxQIK8hhnPQR4EqIAiu4trHFC+k6+P/Y9k2xkImAX4owDw4xIFWc64SSbAqHUYT8FPQr3VuTsIizYoWFSTVy+gtANRmIKVjwY/F/yn4RJoHVnPMxT4nzntNACJjTQUI5pgTa4h/lhBlJGtnCEKj58sYnW0REK71i2svDhxkndQjCbEuuhC3jnDXQCcDFr8mJIitBSJcUpRTGaSYHOGjh11ZLTfE8O9lGTcICcII+Od0KxRR2chISPjSrh5Dbhy8wLitPWAihDnNaZRG1T2oSqyiSuTkASGWEdxC3xx9C4vw4DRRRpUK3Uju1CavSY29tt+Tixadh8fwSr0RCN1ZLhA8/Fw5wHPeMc1NyOWMlDo7gT3ILccp3pU9BSiG9CN8U8V2Edci2DAER1nZN6LpS8vh9+D1WwuHMCR0niGztCLNA2WGdQUw45jnR5MSQ7e2cgnO3601Z6NOIsBY6cSuG3SasxzWR3SdG1768kXahQAWWeu6JfSK9htM6FBbY6q0zSAlyIpuAlCHqL8qEwFoEUr+0grsuAg90v2AYBasUaiQGS1Vphvcm1GAkfAA1iHXOcYT8CKkImQtj9cLqoqveqyMgwpo+BfhO8KFwSlc7wRbpm7YsTOyvwhEf0qDiaPhVKEBCEBJpLviFCD7lezTtV+Upso1ja0dfnMqBCTmbMiEwGQERVn8IiZxmq8NqgtMnPrTk57WdwDh7X+Irihp5ie2EblKfiMPCiFQPycFP8hUPig34tyA74p3I76SwBgnMXRpekDPkRYI136MDBinh8A+J6v1R1ZVCYAACIqz+YLG9IhVliEFoSKKgWsC/xBkRD4WqAT9DeoafkTKCikEQBOSYn/+HcmAQJGW8IJWggMBKB9UEiCVUuoEw+Fm8DWS8nK6hdErw5ZA5Jxqd56ZPCAldd7Z2XcVhh+Cia4XAKASGvLyjOtiimyCfUPB07GMhWUNVnzlY8CsxFogzqGJAUhAfNRGRXJYJgdkgIMLqPxXovZP+gh4UAZrIoCCTTEEFtlJEmKOGsE4tkzgolEBZOW0yoryHKJ1CLpAMqy1CCk5tdXB80+8J0c9QaJii1Lpp/Pq9EEiOgAgrOaSX6qajP4XWFn6utkFanNblTkWKU58YA2W3gkaUavmln3e1WAABEVZekHFmo/HUVg5A+wlJlZxOeaSHWQV2qXnSN6eEMiGwKAREWPmnC9KirD3qFLGVIA1Weay02nYXd+Lnf3r1IAQSIiDCSgjmhqYgD+Rf2j4u/GChUEWO0cSrPJJ/iXZ/QI6O1KYQyI2ACCs3wvu2j/Y6sr1xqXXioEhpwWGe00KAa84+1LYQyIqACCsrvCsb58SRGoxxAVHkiyk5lqOAaZ2nVK9CIDECIqzEgA5ojuDOJ7fUMwl5eHDiUmYDhqRLhcC8ERBh1Z0fijs8ohUfRUQ61VxI75EJASEQISDCqv86kER8ZFNc9AWtoZzUFB59VP3haQRCYD4IiLDmMxfo2lM8NsgYMzIqXuOkV+mz+cyTRlIRARFWRfA7umaLSAVqZISDEfIAaZ01r6FqNEKgPAIirPKYb+qRPMMjPH0HdQYMvxYOetRDc8ZsbRqbfi8EqiIgwqoK/9rOyUlkVXVYdNU57pAndksmBHYOARHWvKf82u6Q5yQR3SwMfxZCgrmTp+eNjEa3kwiIsJYx7VSeoXYjVWgwSl6Rn0jxBpkQ2BkERFjLmWr0q86IJGtQIb1/oyV/5nIeQSMVAtMQEGFNw6/G3YjwUb4rGM74R9cYiPoUAqUREGGVRjxNf7/WqD68yLXgaRFRQPxcMiGw1QiIsJY7vTjkyT1Enhnje0T58G/JhMBWIiDCWva0ovn+vEiuBoma47zSzbKfTKMXAh0IiLCW/1pQDgypmmMapzzpPQSWoilPlWWZENgqBERY2zOdV29qDj7R47YuaLaKBJmiuyUTAluDgAhra6by0gchrecxLleDL+vDriVPZWaZEFg8AiKsxU9h5wMc7L4t9Nwv9O1izgo924minmp2CIiwZjclSQfElvDxXviVsAfKi8mEwGIREGEtdup6Dzyu1sMqi1PEd/W+WxcKgRkhIMKa0WRkHApbQ1Za/IvhnJdDPiPgajoPAiKsPLjOsVXIKhAX41N0/BxnSWNai4AIa/dekDt7Wg/J1HLI7978L/qJRViLnr7Rgz/UTxEPcV2t032bOLpB3SgESiAgwiqB8nz7OM3jtC4xs/NaBTDmO2qNbGcREGHt7NR/48FPdV0tfvB2l6pRzJbei1kiIMKa5bQUHxShD2d7r+83swOLj0AdCoEeCIiweoC0I5dwgvhmf1Y543dk0pf2mCKspc1Y3vHGKy16wjl/ft4u1boQ6I+ACKs/VrtyZXDEh+fVO7IrM7+A59TLuIBJqjDEd5oZIQ/BbtMEncoRX2Ei1OW+CIiw9EasQgAnPFvEYErn0btSHQERVvUpmPUATjazY6MRnmJmR816xBrcViMgwtrq6R39cNc0M75uYWbHm9kB3tLHzOwao1vVjUJgIgIirIkAbsHtB5nZ1Twx+nAz4/9XWfFcnBhycigTAlUQEGFVgb16p0jL3MpHESRnNg3qE57Gc+6mC/V7IZALARFWLmTn3S5FKq43YIgI/iH8p5PCAaDp0vQIiLDSY7qEFtcR1sVm9kUz45q3OkmJqJYwqzswRhHWDkxyxyMGrfdPmdkHzeyzETmxmuL/MiEwOwREWLObkqIDonL0RUV7VGdCYAICIqwJ4OlWISAEyiIgwiqLt3oTAkJgAgIirAng6VYhIATKIiDCKou3ehMCQmACAiKsCeDpViEgBMoiIMIqi7d6EwJCYAICIqwJ4OlWISAEyiIgwiqLt3oTAkJgAgIirAng6VYhIATKIvB1LhK50+04IvcAAAAASUVORK5CYII=','member_pictures/sample_1x14.jpg');
/*!40000 ALTER TABLE `tblmember` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middleinitial` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `usertype` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser`
--

LOCK TABLES `tbluser` WRITE;
/*!40000 ALTER TABLE `tbluser` DISABLE KEYS */;
INSERT INTO `tbluser` VALUES
(1,'2025-05-15 13:39:31.669736',1,'Padua','Michael','O','SFC','Admin','mpadua','pbkdf2_sha256$870000$Q1gO4tel2t4LNTxpWv0cXU$xFoWzavh19tNqUf3fiRDaFQggFahCidLQ0iWJz2UAdQ=',1,1),
(2,NULL,0,'Doe','John','O','SFC','Admin','jdoe','pbkdf2_sha256$870000$bN4T33a33wZeLtPe5j7CH4$lFmjV+C7wvRFUOt7GjWeMpTQmKObR1nZzys8EIxnhrk=',1,0),
(3,NULL,0,'Doe','Jane','J','SFC','Admin','janedoe','pbkdf2_sha256$870000$nod4CiLTi7q4JHGDBgAdpC$QJTa2vbd89jPx1z0lwNlsfjg2iuLPBhvBO37Vn58m5E=',1,0),
(4,NULL,0,'JWTLog','JWTLog','J','SFC','Admin','JWTLog','pbkdf2_sha256$870000$1Vga0T7F78nivS2dAdeUpC$h9I1yYwfQFeCRYe3BHra/xt3u+JXZOaU5w1k3zkFVv4=',1,0),
(5,NULL,0,'Johnathan','Wickleston','J','SFC','Admin','jwick','pbkdf2_sha256$870000$Ng2wGxjCfWS8QAlzVtXAjl$QW/vU9mtQ8I2DwoLFiciFHLI5hcx42T9SB/jIulXZ9s=',1,0),
(6,NULL,0,'Another','Tester','T','SFC','Admin','atester','pbkdf2_sha256$870000$s2DmZr2Rlvpx52wPHx8FLa$2SID9anKcf3PwhQGMIAEGGY+gP0eMpznlwSRtK1ct1M=',0,0),
(7,NULL,0,'Middle','Tester','A','SFC','Admin','mtester','pbkdf2_sha256$870000$MK5oIZPfVbhC09atwTQSEE$3hdWaoJiikcqwCIUPFsyQEdmd6xbSzmPZGMUnoNgkqA=',0,0),
(8,NULL,0,'Padua','Myko','O','SFC','Admin','myko','pbkdf2_sha256$870000$MJQnfrNq8pebwZuzqDiuFU$mLQS/oN8qhgMCMznMA+ZVy88EG0afVBB8d8A2ZpjwN8=',1,0),
(9,NULL,0,'Personnel','Personal','P','SFC','Personnel','persona','pbkdf2_sha256$870000$dLqC1govxu4ApDIHseTSLd$5nXxkxskJpoI33KFbn3ptgoTKd7eaOvKHPtpbxLKJsI=',1,0),
(10,NULL,0,'Test','User','T','SFC','Admin','tuser','pbkdf2_sha256$870000$Pz366VwF8h166prjp1IMC1$y0zd4Yr0PoqCiIN+b/Zbnr019AdiXuAFidEce7tGsIU=',0,0),
(11,NULL,0,'Assistant','Apprentice','A','SF','Personnel','apprentice','pbkdf2_sha256$870000$QpJiXGjxvAXFtsJCaMNIXD$epA+tJp/B9zw/D6/8zuqbsFX8cm5KHZSJg6DfxhC23I=',1,0),
(12,NULL,0,'Oadd','Added','U','SFC','Personnel','oadd','pbkdf2_sha256$870000$QNqUTLEuxcO4BKcijYaWeM$fpFVJKUibQG2pcTivhp1RISA8SAyjxix6J2QHFwO5dA=',0,0);
/*!40000 ALTER TABLE `tbluser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_groups`
--

DROP TABLE IF EXISTS `tbluser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tblUser_groups_user_id_group_id_f8fbd21a_uniq` (`user_id`,`group_id`),
  KEY `tblUser_groups_group_id_1ded9716_fk_auth_group_id` (`group_id`),
  CONSTRAINT `tblUser_groups_group_id_1ded9716_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `tblUser_groups_user_id_503104bb_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_groups`
--

LOCK TABLES `tbluser_groups` WRITE;
/*!40000 ALTER TABLE `tbluser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbluser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbluser_user_permissions`
--

DROP TABLE IF EXISTS `tbluser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbluser_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tblUser_user_permissions_user_id_permission_id_4e213e2b_uniq` (`user_id`,`permission_id`),
  KEY `tblUser_user_permiss_permission_id_87cb63a0_fk_auth_perm` (`permission_id`),
  CONSTRAINT `tblUser_user_permiss_permission_id_87cb63a0_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `tblUser_user_permissions_user_id_0af774d9_fk_tblUser_id` FOREIGN KEY (`user_id`) REFERENCES `tbluser` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_uca1400_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbluser_user_permissions`
--

LOCK TABLES `tbluser_user_permissions` WRITE;
/*!40000 ALTER TABLE `tbluser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tbluser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-05-16 22:47:14
